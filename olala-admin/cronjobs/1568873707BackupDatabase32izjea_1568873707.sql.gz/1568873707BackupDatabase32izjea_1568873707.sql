-- [MySQL -  Database Backup] Created time: 19/09/2019 - 13:15:07

-- Host: localhost
-- Server version: 5.5.5-10.2.14-MariaDB
-- Collation: latin1_swedish_ci
-- Time zone: +07

-- Database: xeo_vii


CREATE TABLE `olala3w_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `block` int(11) NOT NULL DEFAULT 0,
  `flat` int(11) NOT NULL DEFAULT 0,
  `open_sale` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `upload_id` bigint(20) NOT NULL DEFAULT 0,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=971 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article VALUES('960','480','Bánh Xèo Miền Trung','banh-xeo-mien-trung','','','','banh-xeo-mien-trung-1556680847.jpg','','','0','0','0','0','0','2012','Chiếc Bánh Xèo lớn nhất Việt Nam có đường kính 3,68m, được làm từ 139 kg bột gạo xay, 50 kg tôm đất, 50 kg thịt heo, 100 kg tôm hùm, 20 kg giá đỗ, 50kg mực ống,...','','0','0','10','1552387920','1568860781','1');
INSERT INTO olala3w_article VALUES('961','480','Đà Nẵng Xác Lập Kỷ Lục Bánh Xèo Lớn Nhất VN','da-nang-xac-lap-ky-luc-banh-xeo-lon-nhat-vn','BÁNH XÈO LỚN NHẤT VIỆT NAM ĐẠT KỶ LỤC GUINESS','chiếc bánh xèo lớn nhât việt nam được Ẩm Thực Xèo xác lập kỷ lục , Ẩm Thực Xèo tự hào là nhà hàng ẩm thực địa phương , nhà hàng bánh xèo lớn nhất cả nước','banhxeo,banhxeodanang,dacsandiaphuong,kylucginess,nhahangbanhxeo,banhxeongon,dacsanngon,dacsandiaphuongngon','xac-lap-ky-luc-banh-xeo-lon-nhat-vn-1553051194.jpg','','','0','0','0','0','0','2013','Chiếc Bánh Xèo lớn nhất Việt Nam có đường kính 3,68m, được làm từ 139 kg bột gạo xay, 50 kg tôm đất, 50 kg thịt heo, 100 kg tôm hùm, 20 kg giá đỗ, 50kg mực ống,...','<p>Tối 1.5, tại nhà hàng <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a> (đường Võ Văn Kiệt, Q.Sơn Trà, TP.Đà Nẵng), T.Ư Hội LHTN VN, Hội LHTN VN TP.Đà Nẵng, Cổng tri thức Thánh Gióng tổ chức chương trình Giao lưu thanh niên công nhân - Xác lập kỷ lục bánh xèo lớn nhất VN.</p>\r\n\r\n<p>Chiếc <a href=\"https://amthucxeo.com/banh-xeo\">bánh xèo</a> kỷ lục VN là phiên bản phóng lớn của <a href=\"https://amthucxeo.com/banh-xeo\">bánh xèo</a> truyền thống với đường kính 3,68 m (ảnh), được làm từ 139 kg bột gạo xay, 50 kg tôm đất, 50 kg thịt heo, 100 kg tôm hùm, 20 kg giá đỗ, 50 kg mực ống, 20 kg chả bò, 20 lít dầu phụng, 80 kg rau sống các loại. Kèm theo bánh xèo kỷ lục là 100 kg bánh tráng gạo, 100 lít nước xốt tương đậu... Nguyên liệu làm bánh được lấy từ các làng nghề truyền thống Quảng Nam.<br />\r\nĐể làm chiếc bánh xèo kỷ lục, ban tổ chức huy động 30 đầu bếp, chuẩn bị trong 5 tháng và chế biến trong 5 giờ. Khuôn đúc bánh xèo được đặt làm tại làng đúc đồng Phước Kiều (TX.Điện Bàn, Quảng Nam) thi công trong 3 tháng.<br />\r\nNắp chảo có họa tiết trống đồng Đông Sơn, do các nghệ nhân làng thủ công mỹ nghệ kim hoàn Đồng Xâm, xã Hồng Thái, H.Kiến Xương (Thái Bình) chế tác. Tổng trọng lượng của bộ chảo và nắp là 668 kg. <a href=\"https://amthucxeo.com/banh-xeo\">Bánh xèo</a> lớn nhất VN phục vụ khoảng 200 suất ăn.<br />\r\nDịp này, ban tổ chức trao công trình nhà nhân ái trị giá 50 triệu đồng cho gia đình công nhân và 20 suất quà (500.000 đồng/suất) dành cho công nhân có hoàn cảnh đặc biệt khó khăn.</p>\r\n\r\n<div class=\"video-container\" style=\"position:relative;padding-bottom:49.5%;padding-top:30px;height:0;overflow:hidden;\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"480\" src=\"//www.youtube.com/embed/qD7fr-IniEs?rel=0\" style=\"position: absolute;top: 0;left: 0;width: 100%;height: 100%;\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n','1','1','960','1552665480','1568860743','1');
INSERT INTO olala3w_article VALUES('962','480','Ẩm Thực Xèo Tri Ân Khách Hàng','am-thuc-xeo-tri-an-khach-hang','','','','am-thuc-xeo-tri-an-khach-hang-1552752087.jpg','','','0','0','0','0','0','2014','Chiếc Bánh Xèo lớn nhất Việt Nam có đường kính 3,68m, được làm từ 139 kg bột gạo xay, 50 kg tôm đất, 50 kg thịt heo, 100 kg tôm hùm, 20 kg giá đỗ, 50kg mực ống,...','','1','0','72','1552752000','1568860041','1');
INSERT INTO olala3w_article VALUES('959','479','Ẩm Thực Xèo - Niềm Tự Hào Của Người Đà Nẵng','hanh-trinh-cua-tinh-hoa-am-thuc-viet','','Hành trình mang lại tinh hoa ẩm thực cho Ẩm Thực Xèo','amthucxeo,tinhhoaamthuc','no','','','0','0','0','0','0','1980','','<p><span><img alt=\"\" src=\"/uploads/images/1_a.jpg\" style=\"float: right;max-width:440px;padding-left:15px;padding-bottom:10px;\" /></span></p>\r\n\r\n<h3 dir=\"ltr\">Ẩm Thực Xèo - Niềm Tự Hào Của Người Đà Nẵng</h3>\r\n\r\n<p dir=\"ltr\">&nbsp; &nbsp; Phải mất đến 2 năm , người sáng lập <strong>Ẩm Thực Xèo</strong> đã phải đi và thưởng thức , chắc lọc những tinh hoa của ẩm thực truyền thống cũng như mang theo hương vị của từng địa phương&nbsp;đi qua, trước khi bắt tay vào thành lập chuỗi nhà hàng <strong>Ẩm Thực Xèo</strong>.</p>\r\n\r\n<p dir=\"ltr\">&nbsp; &nbsp; Nghe nơi đâu có bánh xèo ngon, anh cũng tạm gác lại mọi công việc để sắp xếp đến “thăm kiến” cho bằng được. Nói rằng, chưa có chỗ nào trên đất Việt chưa in dấu chân anh có lẽ cũng không ngoa, vì hiện giờ trên menu của nhà hàng hầu như đã là trọn bộ các chủng loại Bánh Xèo của dân tộc.</p>\r\n\r\n<p dir=\"ltr\">Từ nếp gạo ta được xay nhuyễn, cho đến từng lá cải mơn mởn xanh, rồi từng con tôm, lát cá, con mực, miếng bánh tráng… anh đều tự tay chọn lựa.</p>\r\n\r\n<p dir=\"ltr\">Những nguồn cung nơi cấp, những nguyên liệu sạch và ngon lành nhất. Món bánh xèo của nhà hàng vì thế không chỉ tròn vẹn về phần hương vị, mà nó còn chứa đựng cả một tấm lòng hiếu thảo của người con đất Quảng với quê hương mình.</p>\r\n\r\n<p dir=\"ltr\">Niềm tự hào Kỷ Lục Bánh Xèo Lớn Nhất Việt Nam chính là một thành quả xứng đáng cho anh và đội ngũ nhân viên chỉ sau 3 năm đưa nhà hàng vào hoạt động.</p>\r\n\r\n<p dir=\"ltr\">Giải thưởng này cũng chính thức đem <strong>Ẩm Thực Xèo</strong> cùng đứa con tinh thần của mình ghi danh trên bàn ăn Ẩm Thực Thế Giới.</p>\r\n\r\n<p dir=\"ltr\">Một chiếc bánh tròn thơm thảo, là tuổi thơ, là hoài niệm, và là tinh hoà được đúc kết của cả dân tộc.</p>\r\n\r\n<p dir=\"ltr\">Về miền Trung, ăn mỳ Quảng.</p>\r\n\r\n<p dir=\"ltr\">Nhưng ghé Đà Nẵng, chớ quên <strong>ẨM THỰC XÈO</strong>.</p>\r\n\r\n<div>&nbsp;</div>\r\n','1','0','2005','1552464600','1568690253','1');
INSERT INTO olala3w_article VALUES('964','480','Đến Đà Nẵng Đừng Quên Ghé Ẩm Thực Xèo','den-da-nang-dung-quen-ghe-am-thuc-xeo','ĐẾN ĐÀ NẴNG PHẢI ĐẾN ẨM THỰC XÈO','Ẩm thực Xèo - Tinh Hoa Xứ Quảng','amthucxeo ,xeo,banhxeo,monandiaphuong','den-da-nang-dung-quen-ghe-am-thuc-xeo-1556681251.jpg','','','0','0','0','0','0','2096','Bạn sẽ có một trải nghiệm hoàn toàn khác biệt khi đến với nhà #Xèo. Với các món ăn mang đậm hương vị xứ Quảng trong không gian ấm áp, sang trọng mang hồn của Hội An thu nhỏ.','<p>Trải nghiệm những món ăn đặc sản địa phương, chắc chắn rằng bạn sẽ cảm nhận được những dư vị ngọt ngào của thành phố đáng sống này.🤪🤪</p>\r\n\r\n<div>\r\n<p>☎️HOTLINE: 0941 750075 Hoặc 1900 0375 (Đặt bàn nhanh - gọn chỉ 1 phút)</p>\r\n</div>\r\n','1','0','181','1556681160','1568860010','1');
INSERT INTO olala3w_article VALUES('965','480','Khám Phá Miền Ẩm Thực Phong Phú Đà Nẵng','kham-pha-mien-am-thuc-phong-phu-da-nang','','','','kham-pha-mien-am-thuc-phong-phu-da-nang-1556681696.jpg','','','0','0','0','0','0','2097','Không chỉ được mệnh danh là “thành phố đáng sống” có nhiều cây cầu độc đáo, những điểm tham quan thú vị, mà Đà Nẵng còn hấp dẫn du khách nhờ một nền ẩm thực vô cùng phong phú, đa dạng.','<p>Trải nghiệm văn hóa địa phương với không gian ấm áp mang hồn của Hội An thu nhỏ và thưởng thức vô vàn những món ăn đặc sản địa phương khi đến với nhà hàng&nbsp;<a data-ft=\"{\" href=\"https://www.facebook.com/hashtag/%E1%BA%A9m_th%E1%BB%B1c_x%C3%A8o?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARC76eZHfd5Dm_Hi_B0ME_1F97dFfif2HqSuh3fYe2MGlBfn2U76XXldRp40nAoe0E9lf24sDr1fSUuFjwbTWGQ-f4K4dewRtEHxh1uikazG3cHvCbUCHqO8RGkbZ3WD3FphbNRnrZL1lTgpbAzEdjScGBnkx4D8KpWd2iqlikTI9lFq2en8RAtoUtfVaZaaP9809Qf0koVfBhDHZmCvzgEEQ8hXn5Th9aatKxGlJYpdXo7rYSG8fM611kU7vnf4skvog60zHhNhAc8B-BgesTtVPd8s8PbLdXYsfXJhOEQfoD7djkL1e47oH7WOmsp_9EcKc1zjzUzzF5HoA0VSIYbmqA&amp;__tn__=%2ANK-R\">#Ẩm_Thực_Xèo</a>&nbsp;chắc chắn sẽ là những TRẢI NGHIỆM KHÁC BIỆT và đầy HỨNG THÚ.</p>\r\n\r\n<div>\r\n<p>🍽🍽🥢Với sứ mệnh mang đến sự trải nghiệm ẩm thực lý thú cho Quý thực khách, từng bước định vị thương hiệu <a href=\"https://amthucxeo.com/banh-xeo\">BÁNH XÈO</a> HÀNG ĐẦU MIỀN TRUNG, cũng như giới thiệu đến đông đảo bạn bè quốc tế, <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a> mong muốn tiếp tục nhận được sự tin tưởng và đồng hành cùng Quý khách hàng.<br />\r\n☎️HOTLINE: 0941 750075 Hoặc 1900 0375 (Đặt bàn nhanh - gọn chỉ 1 phút)</p>\r\n</div>\r\n','1','1','173','1556681520','1568859994','1');
INSERT INTO olala3w_article VALUES('966','480','Giới Thiệu Các Món Ăn Dân Dã Xứ Quảng Đến Với Đầu Bếp Quốc Tế','gioi-thieu-cac-mon-an-dan-da-xu-quang-den-voi-dau-bep-quoc-te','Lễ Hội Ẩm Thực Quốc Tế - Ẩm Thực Xèo','Hân hạnh chào đón đầu bếp quốc tế tham dự Lễ Hội Quốc Tế tại Đà Nẵng - DIFF','dacsandanang,amthucxeo,lehoiamthucquocte,diff','gioi-thieu-cac-mon-an-dan-da-xu-quang-den-voi-dau-bep-quoc-te-1559379546.jpg','','','0','0','0','0','0','2102','Những món ăn đặc trưng chỉ có ở địa phương đã được sở Du lịch Đà Nẵng chọn làm thực đơn khai tiệc giao lưu đầu tiên, với 14 đầu bếp quốc tế vừa đến tham gia Lễ hội Ẩm thực quốc tế Đà Nẵng 2019.','<p>Bữa tiệc đã diễn ra trưa 31.05 tại hệ thống nhà hàng <a href=\"https://amthucxeo.com/\">Ẩm thực Xèo</a> (Đà Nẵng), sau khi các đầu bếp được hướng dẫn tham quan các khu chợ lớn ở Đà Nẵng. Theo đó, các đầu bếp quốc tế đã theo dõi, cùng tham gia chế biến và thưởng thức những món ăn đặc sản đất Quảng, như gỏi cuốn Tam Hữu, <a href=\"https://amthucxeo.com/banh-xeo\">bánh xèo</a> Hội An, phở sắn Đại Lộc, mì Quảng, nước mát Cù Lao…<br />\r\nBà Huỳnh Thị Hương Lan, Phó giám đốc Trung tâm Xúc tiến Du lịch sở Du lịch Đà Nẵng chia sẻ, việc chọn lựa chuỗi nhà hàng Ẩm thực Xèo làm đại diện đầu tiên cho Lễ hội Ẩm thực quốc tế Đà Nẵng 2019 nhằm tôn vinh giá trị văn hóa ẩm thực bản địa, trong mục tiêu giới thiệu rộng rãi những món ăn, hương vị truyền thống đất Quảng, miền Trung đến với các đầu bếp và du khách gần xa.Ông Nguyễn Tấn Vũ, chủ chuỗi nhà hàng Ẩm thực Xèo cho biết, các món ăn được nhà hàng ông tuyển chọn đều là đặc sản dân dã địa phương, nhưng đã được thiết kế, trình bày theo tiêu chuẩn nâng tầm văn hóa ẩm thực, bảo đảm mang lại trải nghiệm thú vị cho các vị đầu bếp quốc tế. Tất cả nguyên liệu, cách thức chế biến và cách thưởng thức của các món ăn đều thuần thuộc phong cách và chất liệu địa phương.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/am-thuc-xeo.jpg\" /></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size:13px;\"><em>Các đầu bếp quốc tế cùng tham gia chế biến và thưởng thức những món ăn đặc sản đất Quảng</em></span></p>\r\n\r\n<p>Dự kiến, Lễ hội <a href=\"https://amthucxeo.com/thuc-don\">Ẩm thực</a> quốc tế Đà Nẵng sẽ khai mạc vào tối 02.06 và kết thúc ngày 06.06, với nhiều hoạt động giao lưu, trình diễn, quảng bá văn hóa ẩm thực các nước và Việt Nam, như trải nghiệm khu trình diễn ẩm thực Big Dish, tổ chức các bàn tiệc ngoài trời dành cho du khách và người dân Đà Nẵng thưởng thức những món ăn đại diện các quốc gia tham gia lễ hội, do chính các đầu bếp thực hiện trên nền tảng nguyên liệu nông nghiệp Việt Nam.Các đầu bếp đều đánh giá rất cao những giá trị ẩm thực họ trải nghiệm được từ ngay bữa tiệc đầu tiên, và tin tưởng Lễ hội Ẩm thực quốc tế Đà Nẵng 2019 sẽ là cơ hội quý để họ giao lưu, học hỏi các món ăn văn hóa các nước, đặc biệt là các món ăn tinh túy đậm màu sắc nông thôn của Việt Nam.</p>\r\n','1','1','162','1559379120','1568859882','1');
INSERT INTO olala3w_article VALUES('967','480','Lễ Hội Ẩm Thực Quốc Tế - DNIFF Tại Đà Nẵng - Ẩm Thực Xèo','le-hoi-am-thuc-quoc-te-dniff-tai-da-nang-am-thuc-xeo','Ẩm Thực Xèo - Đà Nẵng - DNIFF - DIFF','Truyền hình antv đưa tin về Lễ Hội Ẩm Thực tại Đà Nẵng','amthucxeo,dacsandiaphuong,dniff,diff,lehoiamthucqucote,lehoiamthuc,amthucdiaphuong,antv','le-hoi-am-thuc-quoc-te-dniff-tai-da-nang-am-thuc-xeo-1559624095.jpg','','','0','0','0','0','0','2112','Ẩm Thực Xèo hân hạnh là đơn vị tài trợ vàng lễ hội , cảm ơn các ban ngành , cơ quan tổ chức đã tạo điều kiện để món ăn của Ẩm Thực Xèo mang đặc sản địa phương đến với bạn bè quốc tế . \r\n#amthucxeo #dniff #dansandiaphuong','<h2 style=\"text-align: center;\"><strong>Lễ hội ẩm thực quốc tế Đà Nẵng 2019 - Ẩm Thực Xèo</strong></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div>\r\n<p><strong>(ANTV) -&nbsp;Diễn ra từ ngày mùng&nbsp; 2 đến ngày mùng&nbsp; 6/6, với sự tham dự của Chủ tịch Hiệp hội đầu bếp thế giới cùng 13 đầu bếp danh tiếng đến từ các nước, lễ hội ẩm thực quốc tế Đà Nẵng 2019, lần đầu tiên được tổ chức đã tạo cơ hội để các đầu bếp giao lưu, đồng thời quảng bá ẩm thực Việt Nam nói chung và Đà Nẵng nói riêng</strong>.</p>\r\n\r\n<p>Chủ đề của lễ hội ẩm thực quốc tế Đà Nẵng 2019 là “hương vị quê hương”. Tại đây, cùng với những đầu bếp của chủ nhà Việt Nam, những chuyên&nbsp; gia ẩm thực, những đầu bếp danh tiếng đến từ 13 nước sẽ tạo ra những món ăn đặc trưng của quốc gia mình trên nền tảng những gia vị và nguyên liệu của địa phương.</p>\r\n\r\n<p>Đến với lễ hội, du khách được trải nghiệm đồ ăn của các nước trên thế giới đồng thời thưởng thức những tinh hoa ẩm thực Việt Nam, những món ăn đặc trưng của miền Trung.</p>\r\n\r\n<p><a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a>&nbsp;đến với lễ hội mang theo món ăn vô cùng đặc biệt , một sản phẩm của đặc sản địa phương , sản phẩm của vùng đất miền trung bão lũ.&nbsp;<a href=\"https://amthucxeo.com/banh-xeo\">Bánh Xèo</a><strong> -&nbsp;</strong>vâng , bạn đó chính là món ăn mang hương vị quê hương , được <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a><b>&nbsp;</b>chế biến theo cách mới nhưng vẫn mang hương vị truyền thống của Việt Nam . Đồng hành cùng <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a><b>&nbsp;</b>là một đầu bếp đến từ đất nước Mexico , ông&nbsp;<strong>Ray Mccue .&nbsp;</strong>Một đầu bếp vô cùng tài năng đến từ Mexico !!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div class=\"col-lg-5 col-md-12 col-sm-12\" style=\"box-sizing: inherit; position: relative; width: 516.656px; min-height: 1px; padding-right: 15px; padding-left: 15px; flex: 0 0 41.6667%; max-width: 41.6667%; color: rgb(0, 0, 0); font-family: dniff-body-font, sans-serif; font-size: 18px; text-align: start;\">\r\n<div class=\"single-speaker-img\" style=\"box-sizing: inherit;\"><img alt=\"\" class=\"attachment-eventalk-size4 size-eventalk-size4 wp-post-image\" height=\"400\" sizes=\"(max-width: 400px) 100vw, 400px\" src=\"https://dniff.com/wp-content/uploads/2019/04/Ray-McCue-Photo-NESA-mexico-400x400.jpg\" srcset=\"//dniff.com/wp-content/uploads/2019/04/Ray-McCue-Photo-NESA-mexico-400x400.jpg 400w, //dniff.com/wp-content/uploads/2019/04/Ray-McCue-Photo-NESA-mexico-150x150.jpg 150w\" style=\"box-sizing: inherit; height: auto; width: 486.656px;\" width=\"400\" /></div>\r\n</div>\r\n\r\n<div>\r\n<div style=\"text-align: center;\"><em>Bếp trưởng Ray McCue được sinh ra ở New York, sống tại đảo Rhode và giữ vai trò là Phó Giáo sư tại Đại học Johnson &amp; Wales.</em></div>\r\n\r\n<div style=\"text-align: center;\"><em>Ông có bằng thạc sĩ về sư phạm. Ông giảng dạy các môn học như Bảo quản thực phẩm, Quản trị cơ sở..</em></div>\r\n</div>\r\n\r\n<p><strong><img alt=\"\" src=\"fb.com/xeo75\" /></strong></p>\r\n\r\n<ul>\r\n	<li>Bếp trưởng Ray McCue được sinh ra ở New York, sống tại đảo Rhode và giữ vai trò là Phó Giáo sư tại Đại học Johnson &amp; Wales.</li>\r\n	<li>Ông có bằng thạc sĩ về sư phạm. Ông giảng dạy các môn học như Bảo quản thực phẩm, Quản trị cơ sở.</li>\r\n	<li>Trước khi dạy tại trường Đại học Johnson &amp; Wales, ông đã làm việc tại Ritz-Carlton ở New York và nhà hàng 2West. Năm 2003, ông nhận được giải thưởngxuất sắc về ẩm thực của Barcadi USA. Năm 2005, ông đã chiến thắng giải Món bánh ngọt ngon nhất tại cuộc thi Academie Culinaire của Pháp. Ông cũng đã xuất hiện trên chương trình The Today Show của đài NBC cùng với nhân vật truyền hình nổi tiếng Albert Rocker để giới thiệu những món ăn hấp dẫn trong mùa hè.</li>\r\n	<li>Ông đã nhận được nhiều giải thưởng và huy chương tại triển lãm Nhà hàng và Khách sạn do Hiệp hội ẩm thực Philanthropique tổ chức.</li>\r\n	<li>Ông cũng nhận được chứng chỉ Master Chef của Hiệp hội Đầu bếp thế giới (W.C.M.C.), chứng chỉ Bếp trưởng điều hành của Liên đoàn ẩm thực Mỹ (C.E.C) và chứng chỉ Kỹ năng sư phạm chuyên ngành Nhà hàng – Khách sạn (C.H.E) .&nbsp; &nbsp;</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div style=\"text-align: center;\">\r\n<video controls=\"controls\" height=\"300\" id=\"video201954115234\" poster=\"\" width=\"400\"><source src=\"/uploads/files/am%20thuc.mp4\" type=\"video/mp4\" />Your browser doesn\'t support video.<br />\r\nPlease download the file: <a href=\"/uploads/files/am%20thuc.mp4\">video/mp4</a></video>\r\n</div>\r\n\r\n<div style=\"text-align: center;\">Lễ Hội Ẩm Thực Quốc Tế DNIFF - Đà Nẵng 2019&nbsp;&nbsp;</div>\r\n\r\n<div style=\"text-align: center;\">Nguồn : ANTV</div>\r\n</div>\r\n','1','1','161','1559621520','1568859956','1');
INSERT INTO olala3w_article VALUES('968','480','Sự Kiện “Các Đầu Bếp Quốc Tế Giao Lưu Làm Bánh Xèo Việt Nam”','su-kien-cac-dau-bep-quoc-te-giao-luu-lam-banh-xeo-viet-nam','Sự kiện “Các đầu bếp quốc tế giao lưu làm Bánh Xèo Việt Nam”','Bánh Xèo kỷ lục guiness Việt Nam , Bánh xèo lớn nhất thế giới được đầu bếp thế giới chung tay đúc nên','amthucxeo,banhxeovietnam,banhxeodanang,wordchef,dniff,dacsanxeo','su-kien-cac-dau-bep-quoc-te-giao-luu-lam-banh-xeo-viet-nam-1559878061.jpg','','','0','0','0','0','0','2113','Nằm trong chuỗi sự kiện Lễ Hội Văn Hóa Ẩm Thực Đà Nẵng 2019 DNIFF , Ẩm Thực Xèo vinh dự được mang món ăn đặc sản của Ẩm Thực Xèo nói riêng và miền trung Việt Nam nói chung đến với bạn bè quốc tế , đặc biệt là những vị khách vô cùng thú vị , các đầu bếp nổi tiếng trên thế giới ','<p style=\"margin-right: 0px; margin-bottom: 6px; margin-left: 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">Sự kiện “Các đầu bếp quốc tế giao lưu làm bánh xèo Việt Nam” là sự kiện nằm trong chuỗi sự kiện bế mạc Lễ hội ẩm thực quốc tế Đà Nẵng 2019.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">Do Sở Du lịch TP và thương hiệu <a href=\"https://amthucxeo.com/\">Ẩm thực Xèo</a> tổ chức đổ chiếc <a href=\"https://amthucxeo.com/banh-xeo\">bánh xèo</a> có đường kính 3,68 m, nặng 150 kg với sự tham gia của 13 đầu bếp quốc tế đến từ các nước: Đức, Mexico, Úc, Ấn Độ, Trung Quốc, Sri Lanka, Li Băng, Thụy Điển, Mỹ, Thổ Nhĩ Kỳ, Hy Lạp, Malaysia và Singapore.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFVnOJGIvSSrEeEBXxH_5K86H3uRszvrHdXPXmXpi0ExLHvtB7DN37T74p7x19-1org6RitA1dqxC77gEUPEAUUlHsXToTCJCFuCxYkfRsrMQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t58=\"\" v9=\"\">🤩</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFVnOJGIvSSrEeEBXxH_5K86H3uRszvrHdXPXmXpi0ExLHvtB7DN37T74p7x19-1org6RitA1dqxC77gEUPEAUUlHsXToTCJCFuCxYkfRsrMQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t58=\"\" v9=\"\">🤩</span></span>Trong buổi tiệc có sự tham gia của các đầu bếp đến từ các quốc&nbsp;<span class=\"text_exposed_show\" style=\"display: inline; font-family: inherit;\">gia: Mỹ, Đức, Malaysia, Sri Lanka, Singapore, Úc, Mexico, Thụy Điển, Lebanon, Ấn Độ, Hy Lạp, Trung Quốc, Thổ Nhĩ Kỳ là những chuyên gia <a href=\"https://amthucxeo.com/thuc-don\">ẩm thực</a>, thành viên danh dự của các Hiệp hội đầu bếp thế giới, bếp trưởng của các nhà hàng – khách sạn nước sở tại.</span></p>\r\n\r\n<div class=\"text_exposed_show\" style=\"display: inline; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">\r\n<p style=\"margin-right: 0px; margin-bottom: 6px; margin-left: 0px; font-family: inherit;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeEOjbK-usA_K0oV_9PpscDLTX83iT9jpU9yDFU4NbPz8lEabVMbg1k6v95qeKf2TxR9X7SeBz8aKjgo_XdchK5IykMuYcI4mcKItDcoAy1-1g\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t66=\"\" v9=\"\">💓</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeEOjbK-usA_K0oV_9PpscDLTX83iT9jpU9yDFU4NbPz8lEabVMbg1k6v95qeKf2TxR9X7SeBz8aKjgo_XdchK5IykMuYcI4mcKItDcoAy1-1g\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t66=\"\" v9=\"\">💓</span></span>Đặc biệt, đầu bếp Thomas Andreas Gugler – Chủ tịch Hiệp hội Đầu bếp thế giới, là đồng sáng lập và là thành viên HĐQT Hiệp hội Đầu bếp Các Tiểu Vương quốc Ả Rập.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: inherit;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeHiuCcVmuLIDaI9vSb9f_OI_eANalHhJH_K9f4KycjY1Bvs05aI-dwFYDTxx7xtUWXPBsVW8qg4CvnS6lmhZy4dlzyWC1oRZqfR2j0GevcrJQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t99=\"\" v9=\"\">🌺</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeHiuCcVmuLIDaI9vSb9f_OI_eANalHhJH_K9f4KycjY1Bvs05aI-dwFYDTxx7xtUWXPBsVW8qg4CvnS6lmhZy4dlzyWC1oRZqfR2j0GevcrJQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t99=\"\" v9=\"\">🌺</span></span>Và sự quan tâm có mặt của Sở Du Lịch Thành phố Đà Nẵng.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: inherit;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeHiuCcVmuLIDaI9vSb9f_OI_eANalHhJH_K9f4KycjY1Bvs05aI-dwFYDTxx7xtUWXPBsVW8qg4CvnS6lmhZy4dlzyWC1oRZqfR2j0GevcrJQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t99=\"\" v9=\"\">🌺</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeHiuCcVmuLIDaI9vSb9f_OI_eANalHhJH_K9f4KycjY1Bvs05aI-dwFYDTxx7xtUWXPBsVW8qg4CvnS6lmhZy4dlzyWC1oRZqfR2j0GevcrJQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t99=\"\" v9=\"\">🌺</span></span>Sự quan tâm có mặt và đưa tin của các đơn vị báo chí.</p>\r\n\r\n<div class=\"file-preview-thumbnails\" font-size:=\"\" helvetica=\"\" style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" text-align:=\"\">\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_0\" id=\"preview-1559886866368-init_0\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886723_2113_2c835e6d10476ae4aab8d79acbc60968.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886723_2113_2c835e6d10476ae4aab8d79acbc60968.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886723\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886723_2113_2c835e6d10476ae4aab8d79acbc60968.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_1\" id=\"preview-1559886866368-init_1\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886726_2113_a0b42d810b358a609dd2bb787b408f2a.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886726_2113_a0b42d810b358a609dd2bb787b408f2a.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886726\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886726_2113_a0b42d810b358a609dd2bb787b408f2a.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_2\" id=\"preview-1559886866368-init_2\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886730_2113_dfffe1482013871c9a4355efab34bc68.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886730_2113_dfffe1482013871c9a4355efab34bc68.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886730\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886730_2113_dfffe1482013871c9a4355efab34bc68.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_3\" id=\"preview-1559886866368-init_3\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886734_2113_812550d36be730da62dc5a6b406aebfa.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886734_2113_812550d36be730da62dc5a6b406aebfa.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886734\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886734_2113_812550d36be730da62dc5a6b406aebfa.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_4\" id=\"preview-1559886866368-init_4\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886737_2113_0ac4db201139bce75dca50bc8d9aed77.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886737_2113_0ac4db201139bce75dca50bc8d9aed77.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886737\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886737_2113_0ac4db201139bce75dca50bc8d9aed77.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_5\" id=\"preview-1559886866368-init_5\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886741_2113_a85663d6a440ba5befed973120c766c2.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886741_2113_a85663d6a440ba5befed973120c766c2.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886741\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886741_2113_a85663d6a440ba5befed973120c766c2.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_6\" id=\"preview-1559886866368-init_6\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886746_2113_3dfd46d1136aa019100a0ec8740074c9.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886746_2113_3dfd46d1136aa019100a0ec8740074c9.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886746\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886746_2113_3dfd46d1136aa019100a0ec8740074c9.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_7\" id=\"preview-1559886866368-init_7\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886753_2113_85334e8d8e6b61ccd11e35172c3d7b48.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886753_2113_85334e8d8e6b61ccd11e35172c3d7b48.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886753\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886753_2113_85334e8d8e6b61ccd11e35172c3d7b48.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_8\" id=\"preview-1559886866368-init_8\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886757_2113_1bbd757109e00cda12189ad6fdca2969.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886757_2113_1bbd757109e00cda12189ad6fdca2969.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886757\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886757_2113_1bbd757109e00cda12189ad6fdca2969.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_9\" id=\"preview-1559886866368-init_9\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886760_2113_c838d4cfeb1a498870ecb6116bfee3b0.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886760_2113_c838d4cfeb1a498870ecb6116bfee3b0.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886760\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886760_2113_c838d4cfeb1a498870ecb6116bfee3b0.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_10\" id=\"preview-1559886866368-init_10\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886764_2113_dabc72b70df669b843b67c4a4d1b1ac6.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886764_2113_dabc72b70df669b843b67c4a4d1b1ac6.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886764\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886764_2113_dabc72b70df669b843b67c4a4d1b1ac6.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_11\" id=\"preview-1559886866368-init_11\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886790_2113_2e12905126048ceb1992fef21af5f5e2.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886790_2113_2e12905126048ceb1992fef21af5f5e2.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886790\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886790_2113_2e12905126048ceb1992fef21af5f5e2.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_12\" id=\"preview-1559886866368-init_12\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886796_2113_774eba86b6a048c7f53f97703cf2ce9e.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886796_2113_774eba86b6a048c7f53f97703cf2ce9e.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886796\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886796_2113_774eba86b6a048c7f53f97703cf2ce9e.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_13\" id=\"preview-1559886866368-init_13\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886799_2113_ea6aa8bf6b346b1c03cd56e9edd12530.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886799_2113_ea6aa8bf6b346b1c03cd56e9edd12530.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886799\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886799_2113_ea6aa8bf6b346b1c03cd56e9edd12530.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_14\" id=\"preview-1559886866368-init_14\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886805_2113_716e230787048099981992055de54ffa.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886805_2113_716e230787048099981992055de54ffa.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886805\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886805_2113_716e230787048099981992055de54ffa.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_15\" id=\"preview-1559886866368-init_15\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886808_2113_01e1ca4d03d6d57ba878e2e8c9fc9df4.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886808_2113_01e1ca4d03d6d57ba878e2e8c9fc9df4.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886808\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886808_2113_01e1ca4d03d6d57ba878e2e8c9fc9df4.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_16\" id=\"preview-1559886866368-init_16\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886812_2113_2653a075777a50d733fb5174d11b9876.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886812_2113_2653a075777a50d733fb5174d11b9876.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886812\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886812_2113_2653a075777a50d733fb5174d11b9876.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_17\" id=\"preview-1559886866368-init_17\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886815_2113_72e9e9dae38ce052110e9912a90472e0.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886815_2113_72e9e9dae38ce052110e9912a90472e0.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886815\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886815_2113_72e9e9dae38ce052110e9912a90472e0.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_18\" id=\"preview-1559886866368-init_18\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886818_2113_74e44402f7489a6d786c0b18d9ba37a8.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886818_2113_74e44402f7489a6d786c0b18d9ba37a8.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886818\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886818_2113_74e44402f7489a6d786c0b18d9ba37a8.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_19\" id=\"preview-1559886866368-init_19\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886822_2113_80d130fab2efcbf4605487ec725cdff4.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886822_2113_80d130fab2efcbf4605487ec725cdff4.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886822\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886822_2113_80d130fab2efcbf4605487ec725cdff4.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_20\" id=\"preview-1559886866368-init_20\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886826_2113_1685fe6ad9c002463adfed153c13d387.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886826_2113_1685fe6ad9c002463adfed153c13d387.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886826\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886826_2113_1685fe6ad9c002463adfed153c13d387.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_21\" id=\"preview-1559886866368-init_21\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886830_2113_1cab01e653120da98785fb10d2fbef2f.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886830_2113_1cab01e653120da98785fb10d2fbef2f.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886830\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886830_2113_1cab01e653120da98785fb10d2fbef2f.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_22\" id=\"preview-1559886866368-init_22\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886834_2113_cea287bdba8f3eea9cc2e620ca4b6f15.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886834_2113_cea287bdba8f3eea9cc2e620ca4b6f15.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886834\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886834_2113_cea287bdba8f3eea9cc2e620ca4b6f15.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_23\" id=\"preview-1559886866368-init_23\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886838_2113_9ce4d83ef3f2205aba7685277e75d90d.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886838_2113_9ce4d83ef3f2205aba7685277e75d90d.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886838\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886838_2113_9ce4d83ef3f2205aba7685277e75d90d.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_24\" id=\"preview-1559886866368-init_24\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886841_2113_b7d8dee6e93ed78b200725fae3e7d3b4.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886841_2113_b7d8dee6e93ed78b200725fae3e7d3b4.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886841\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886841_2113_b7d8dee6e93ed78b200725fae3e7d3b4.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"file-preview-frame file-preview-initial\" data-fileindex=\"init_25\" id=\"preview-1559886866368-init_25\" style=\"box-sizing: border-box; margin: 3px; padding: 3px; display: table; height: 80px; border: 1px solid rgb(221, 221, 221); box-shadow: rgb(199, 199, 199) 0px 0px 8px; float: left; vertical-align: middle;\"><a data-gallery=\"\" href=\"https://amthucxeo.com/uploads/photos/1559886844_2113_97bd728d485fa2f9992600bc586061c3.jpg\" style=\"box-sizing: border-box; background: transparent; color: rgb(29, 146, 175);\"><img class=\"file-preview-image\" src=\"https://amthucxeo.com/uploads/photos/1559886844_2113_97bd728d485fa2f9992600bc586061c3.jpg\" style=\"box-sizing: border-box; margin: 0px auto; padding: 0px; border-width: 0px; border-style: initial; max-width: 190px; max-height: 120px; overflow: hidden;\" /></a>\r\n\r\n<div class=\"file-thumbnail-footer\" style=\"box-sizing: border-box;\">\r\n<div class=\"file-caption-name\" style=\"box-sizing: border-box; padding-top: 4px; padding-right: 10px; display: inline-block; overflow: hidden; max-height: 20px; word-break: break-all; font-size: 11px; color: rgb(119, 119, 119);\">&nbsp;</div>\r\n\r\n<div class=\"file-actions\" style=\"box-sizing: border-box; text-align: left;\">\r\n<div class=\"file-footer-buttons\" style=\"box-sizing: border-box; float: right;\"><button class=\"kv-file-remove btn btn-xs btn-default\" data-key=\"1559886844\" data-url=\"/uploads/upload.php?type=2&amp;id=2113&amp;item=1559886844_2113_97bd728d485fa2f9992600bc586061c3.jpg&amp;lang=vi\" style=\"margin-right: 0px; margin-left: 0px; padding: 2px 5px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 12px; line-height: 1; font-family: inherit; color: rgb(51, 51, 51); overflow: visible; cursor: pointer; min-width: 0px; white-space: nowrap; vertical-align: middle; user-select: none; background-image: none; border-width: 1px; border-style: solid; border-color: rgb(204, 204, 204); border-radius: 0px; transition: background 0.3s ease 0s; background-color: rgb(255, 255, 255);\" title=\"Xóa tệp\" type=\"button\"></button></div>\r\n\r\n<div class=\"file-upload-indicator\" style=\"box-sizing: border-box; padding-top: 2px; cursor: default;\" tabindex=\"-1\" title=\"\">&nbsp;</div>\r\n\r\n<div class=\"clearfix\" style=\"box-sizing: border-box;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<p style=\"margin: 6px 0px; font-family: inherit;\"><a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/amthucxeo?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">amthucxeo</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/diff?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">DIFF</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/dacsanxeo?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">dacsanxeo</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/dniff?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">dniff</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/dniff2019?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">dniff2019</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/danangfatasticity?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">danangfatasticity</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/worldchefs?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBBw8y7dNDKfo_mXrG2gRl7F5xpkyvLWHDTGBngrqhgg92NE3izs7kSMIDiMcyrGeREtd08REcqIRYuhAOT-Y0k2zP3z4qwYr9WqkzEtReWHxOakBcpIkrH5XUuO_AL6J9EmeE0637_l6T1g06eeZ5ZlSJNepZ3Q3ytGVsTPisZvUPoBTUvx5-N9hWS6L0N5dDt26jwUfQnP2ALAZJxVE3kKvmL7zTlknUrM2q76BByAZTsinyaAT28IttbdKLk0rEp8BBEDcXA7MHDwrmUIDxRUoPB5XPB4Lb4wEvml1b8JQ30of7f-Sl7KOKNz1CJiSvhAGNrOIUbPhIOnReLED8CqA&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">worldchefs</span></span></a></p>\r\n</div>\r\n','1','1','521','1559877540','1568859938','1');
INSERT INTO olala3w_article VALUES('969','480','Một Ngày Làm Đầu Bếp Xứ Quảng Cùng Ẩm Thực Xèo','mot-ngay-lam-dau-bep-xu-quang-cung-am-thuc-xeo','Ẩm Thực Xèo - Bánh Xèo Đà Nẵng - Điểm Hẹn Mùa Hè 2019','Bánh xèo Đà Nẵng','banhxeodanang,amthucxeo,amthucdanang,amthucmientrung,diemhenmuahe','mot-ngay-lam-dau-bep-xu-quang-cung-am-thuc-xeo-1560745369.jpg','','','0','0','0','0','0','2116','','<p style=\"margin-right: 0px; margin-bottom: 6px; margin-left: 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">MỘT NGÀY LÀM ĐẦU BẾP XỨ QUẢNG CÙNG <a href=\"https://amthucxeo.com/am-thuc-xeo\">ẨM THỰC XÈO</a>.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeF9typSXhsEkbQv-n9C24_befIH-FmNPPjUamPG6h0SbsZ_9vwWeOF0bUKmTnFoUcS-DwP9W3fSoMy1-0D_WRpyWhAeQegzj54Ps8vSIscLKQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t2=\"\" v9=\"\">😍</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeF9typSXhsEkbQv-n9C24_befIH-FmNPPjUamPG6h0SbsZ_9vwWeOF0bUKmTnFoUcS-DwP9W3fSoMy1-0D_WRpyWhAeQegzj54Ps8vSIscLKQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t2=\"\" v9=\"\">😍</span></span>Nằm trong chuỗi hoạt động của Điểm Hẹn Mùa hè 2019. Chương trình \"<a href=\"https://amthucxeo.com/mot-ngay-lam-dau-bep-xu-quang-cung-am-thuc-xeo\">Một ngày làm đầu bếp xứ Quảng cùng ẨM THỰC XÈO</a> thu hút rất nhiều người tham gia. Bởi đến đây bạn có thể cùng đầu bếp chế biến các món ăn địa phương dân dã và được chia sẻ bí quyết chế biến <a href=\"https://amthucxeo.com/thuc-don\">ẩm thực</a> xứ Quảng vô cùng thú vị. Ngoài ra bạn còn được thưởng thức các món ăn do chính các bạn và đầu bếp chế biến. Một trải nghiệm thú vị đúng không nào???<span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeEL7QXE1eaQWkPgtnIcXynTUMLUueU0IlZU6MtszpYm0U50qwz2KMO1jGiHCyOO0rD255-tTr7WEp0rjSxTrpRstF1HPNRTt0tay3JrKILyrA\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" tb4=\"\" v9=\"\">🥘</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFTk-zIg8-oD9dspiFqu4_-TeFKuGXxGZwJWcr9JuTBwai605gL6Vsya_O2gt0GcYKABZGu_3ljxQtIFKxOhJfdOP16Bbf2eEGP8svkBvaxrQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t33=\"\" v9=\"\">🥗</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeGPWpn4wBZsAVLH2tbRIluEubH7lr4ckPDlv0xf4qiGHxapKCSMlrtrufpVMHe-SE26_FyKA83_8MUx2SkmObkofywpt-zlHBJjt7Ti6wrcYg\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t5a=\"\" v9=\"\">🍝</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeEGmRt-jYD5acyaAoT1n5PKrnvl3LGFaaiQRrFRyuACwTUDw_p9mktqUXftu6uAUys6xalGz3XvGQsj6FHHNr9vZqWOmXxz1unTAug8M0oWRw\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" td9=\"\" v9=\"\">🍜</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeEOjbK-usA_K0oV_9PpscDLTX83iT9jpU9yDFU4NbPz8lEabVMbg1k6v95qeKf2TxR9X7SeBz8aKjgo_XdchK5IykMuYcI4mcKItDcoAy1-1g\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t66=\"\" v9=\"\">🍲</span></span></p>\r\n\r\n<div class=\"text_exposed_show\" style=\"display: inline; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">\r\n<p style=\"margin: 6px 0px; font-family: inherit;\"><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFGLHaS9fHLDjrPgCel1obGKssDIrKtuhJ12Yk6Jc_2pL-Kzwrw8cl9K0slOUp1iwCJzS8yd-B-usxNEDthhjmlunFsf_B0iZx7PMpcqB6SZg\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t1e=\"\" v9=\"\">⏩</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFGLHaS9fHLDjrPgCel1obGKssDIrKtuhJ12Yk6Jc_2pL-Kzwrw8cl9K0slOUp1iwCJzS8yd-B-usxNEDthhjmlunFsf_B0iZx7PMpcqB6SZg\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t1e=\"\" v9=\"\">⏩</span></span>Địa điểm:Công viên biển Đông. Gian <a href=\"https://amthucxeo.com/\">Ẩm thực Xèo</a>&nbsp;<span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" _nc_eui2=\"AeFVnOJGIvSSrEeEBXxH_5K86H3uRszvrHdXPXmXpi0ExLHvtB7DN37T74p7x19-1org6RitA1dqxC77gEUPEAUUlHsXToTCJCFuCxYkfRsrMQ\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t58=\"\" v9=\"\">🤩</span></span>&nbsp;– Không gian ẩm thực Xứ Quảng của Chương trình Đà Nẵng – Điểm hẹn mùa hè 2019.</p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: inherit;\"><a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/amthucxeo?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">amthucxeo</span></span></a><br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/localfood?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">localfood</span></span></a><br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/diemhenmuahe?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">diemhenmuahe</span></span></a>&nbsp;<br />\r\n<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/danangsummerdestination?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">danangsummerdestination</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/sontrapeninsula?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">SonTraPeninsula</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/danangbeach?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">danangbeach</span></span></a><a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/festivaltourism?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">festivaltourism</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/danang?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">danang</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/timetotravel?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">timetotravel</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/hellosummer?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">hellosummer</span></span></a>&nbsp;<a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/daubepxuquang?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARDqaqvCdvPkOIGd2yc7mf3TQn_4vF5ncFI13GBlVmZQiU0wPSyo-Oci-NkFuH9AiljTbuOncuZ-jaMJ25UYmrRVyend1nc0szXa11MQhdBNq-psD9jdmLE5NeeWZdw_xFkv9xz6tQSdNxxtPY2iCSZmnmrOo7VrPvsJSDTkxkAYgLNcyQkCmZmum9IKrcp7XBrnVW40I8x4VLwczPrxCzrfJJXZ6yOOWnbSvyZGoYiwllVRvGsReMZf90MsXTo7zZlJuSBa9Ih9XOx5ajuNoSrOTbW5Q0-e6vRT0wXlRIW0Plm9PgztG0A-lb6RS33JX235vwYN3ZHnKJ30Uaxr42a2EWEexLau_Aa2aw&amp;__tn__=%2ANK-R\" style=\"color: rgb(56, 88, 152); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; color: rgb(54, 88, 153); font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">daubepxuquang</span></span></a></p>\r\n</div>\r\n','1','0','70','1560745140','1568859911','1');
INSERT INTO olala3w_article VALUES('970','480','Ẩm Thực Xèo - Triển Lãm Thương Mại Gian Hàng Kinh Doanh Di Động Phố Đi Bộ - Chợ Đêm Bạch Đằng Quận Hải Châu - TP.Đà Nẵng','am-thuc-xeo-trien-lam-thuong-mai-gian-hang-kinh-doanh-di-dong-pho-di-bo-cho-dem-bach-dang-quan-hai-chau-tp-da-nang','ẨM THỰC XÈO - TRIỂN LÃM THƯƠNG MẠI GIAN HÀNG KINH DOANH DI ĐỘNG PHỐ ĐI BỘ-CHỢ ĐÊM BẠCH ĐẰNG QUẬN HẢI CHÂU-ĐÀ NẴNG','Ẩm Thực Xèo - Mang món ngon xứ quảng về ','amthucxeo,localfoodanang,xeo,trienlamgianghang','am-thuc-xeo-trien-lam-thuong-mai-gian-hang-kinh-doanh-di-dong-pho-di-bo-cho-1561350187.jpg','','','0','0','0','0','0','2117','Ẩm Thực Xèo - Mang ẩm thực địa phương đến với du khách bằng gian hàng di động','<p>ĐẮM CHÌM TRONG NGÀY HỘI ẨM THỰC CỦA NHỮNG MÓN NGON XỨ QUẢNG.</p>\r\n\r\n<p>Với mong muốn mang ẩm thực văn hoá địa phương đến gần với du khách trong nước cũng như là quốc tế. <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a> rất tự khi có mặt trong “TRIỂN LÃM THƯƠNG MẠI GIAN HÀNG KINH DOANH DI ĐỘNG PHỐ ĐI BỘ-CHỢ ĐÊM BẠCH ĐẰNG QUẬN HẢI CHÂU-TP.ĐÀ NẴNG”</p>\r\n\r\n<p>Mời mọi người ghé thăm gian hàng <a href=\"https://amthucxeo.com/\">Ẩm Thực Xèo</a> và cùng thưởng thức những món ngon đặc sắc của xứ Quảng nhé!</p>\r\n\r\n<div>\r\n<p>Thông tin chi tiết về chương trình:</p>\r\n\r\n<p>✅Thời gian: 9g30-22g00<br />\r\n👉🏻Từ ngày 25/06 đến ngày 30/06/2019 ( 06 ngày)</p>\r\n\r\n<p>✅Địa điểm:&nbsp;<br />\r\n👉🏻Tại khu vực đường Bạch Đằng, công viên phía Tây Cầu Rồng, quận Hải Châu, Đà Nẵng.</p>\r\n\r\n<p>✅Nội dung:</p>\r\n\r\n<p>👉🏻<a href=\"https://amthucxeo.com/am-thuc-xeo-trien-lam-thuong-mai-gian-hang-kinh-doanh-di-dong-pho-di-bo-cho-dem-bach-dang-quan-hai-chau-tp-da-nang\">Triển lãm các gian hàng di động của Chợ Đêm Bạch Đằng, Quận Hải Châu, TP.Đà Nẵng</a>...là dịp mà mọi người “mắt thấy, tay sờ” những gian hàng và điền tên mình vào mẫu đăng ký kinh doanh tại Chợ đêm nhé...</p>\r\n\r\n<p>👉🏻Được đắm mình trong Ngày Hội của những Món Ngon ẩm thực đặc sắc của Xứ Quảng Đà, thưởng thức những chương trình nghệ thuật mang màu sắc đường phố cùng các nhóm Street Dance của các bạn Trẻ Đà Nẵng</p>\r\n\r\n<p>👉🏻Được góp ý chung tay cho sản phẩm kinh doanh mà chính người dân Đà Nẵng là chủ “sở hữu”....của Chợ Đêm trong tương lai....</p>\r\n\r\n<p><a data-ft=\"{\" href=\"https://www.facebook.com/hashtag/amthucxeo?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARA2EILcELdHgw_5JG0eF5ZSOPQkpvAByZjeO4etPCOmWMCsiAJJJY13SMpySkswUHIW3uIXCGoEMJTW2MDuq2dZltzKdLeE05rk25VZvlXCfI9OSQ0TRDyzSXMRzDGGrCJsZr1xdc0hQ7TUhRncfw4UhOvFUymY6cj78UZlQIj_sQ07gnXr9HHLH7pg-1OC6ZTF6RVis80pN1lvVBKdgfN8Zez5LFrQPGgYmhBAuzgzzbOXlNlhea6S6eXLgr57trikElbaPEHJq2WISsPno15btLpYC402u423ebqdtF5mdsZ01lJGEY5WvKvhL6kiVc6C4fojk0Fl0Ts6hRL061XPQg&amp;__tn__=%2ANK-R\">#amthucxeo</a><br />\r\n<a data-ft=\"{\" href=\"https://www.facebook.com/hashtag/xeo?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARA2EILcELdHgw_5JG0eF5ZSOPQkpvAByZjeO4etPCOmWMCsiAJJJY13SMpySkswUHIW3uIXCGoEMJTW2MDuq2dZltzKdLeE05rk25VZvlXCfI9OSQ0TRDyzSXMRzDGGrCJsZr1xdc0hQ7TUhRncfw4UhOvFUymY6cj78UZlQIj_sQ07gnXr9HHLH7pg-1OC6ZTF6RVis80pN1lvVBKdgfN8Zez5LFrQPGgYmhBAuzgzzbOXlNlhea6S6eXLgr57trikElbaPEHJq2WISsPno15btLpYC402u423ebqdtF5mdsZ01lJGEY5WvKvhL6kiVc6C4fojk0Fl0Ts6hRL061XPQg&amp;__tn__=%2ANK-R\">#xeo</a><br />\r\n<a data-ft=\"{\" href=\"https://www.facebook.com/hashtag/localfood?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARA2EILcELdHgw_5JG0eF5ZSOPQkpvAByZjeO4etPCOmWMCsiAJJJY13SMpySkswUHIW3uIXCGoEMJTW2MDuq2dZltzKdLeE05rk25VZvlXCfI9OSQ0TRDyzSXMRzDGGrCJsZr1xdc0hQ7TUhRncfw4UhOvFUymY6cj78UZlQIj_sQ07gnXr9HHLH7pg-1OC6ZTF6RVis80pN1lvVBKdgfN8Zez5LFrQPGgYmhBAuzgzzbOXlNlhea6S6eXLgr57trikElbaPEHJq2WISsPno15btLpYC402u423ebqdtF5mdsZ01lJGEY5WvKvhL6kiVc6C4fojk0Fl0Ts6hRL061XPQg&amp;__tn__=%2ANK-R\">#localfood</a><br />\r\n<a data-ft=\"{\" href=\"https://www.facebook.com/hashtag/trienlamgianhangdidong?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARA2EILcELdHgw_5JG0eF5ZSOPQkpvAByZjeO4etPCOmWMCsiAJJJY13SMpySkswUHIW3uIXCGoEMJTW2MDuq2dZltzKdLeE05rk25VZvlXCfI9OSQ0TRDyzSXMRzDGGrCJsZr1xdc0hQ7TUhRncfw4UhOvFUymY6cj78UZlQIj_sQ07gnXr9HHLH7pg-1OC6ZTF6RVis80pN1lvVBKdgfN8Zez5LFrQPGgYmhBAuzgzzbOXlNlhea6S6eXLgr57trikElbaPEHJq2WISsPno15btLpYC402u423ebqdtF5mdsZ01lJGEY5WvKvhL6kiVc6C4fojk0Fl0Ts6hRL061XPQg&amp;__tn__=%2ANK-R\">#trienlamgianhangdidong</a></p>\r\n</div>\r\n\r\n<div class=\"text_exposed_show\" style=\"display: inline; font-family: Helvetica, Arial, sans-serif; color: rgb(28, 30, 33); text-align: start;\">\r\n<p style=\"margin: 6px 0px; font-family: inherit;\">&nbsp;</p>\r\n</div>\r\n','1','1','210','1561349460','1568859902','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_article_menu` (
  `article_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `icon` text NOT NULL,
  `plus` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`article_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=482 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article_menu VALUES('479','9','Ẩm Thực Xèo','am-thuc-xeo','Ẩm Thực Xèo - mang đặc sản đà nẵng đến với khách du lịch năm châu','Món ngon Đà Thành - Nhà hàng bánh xèo lớn nhất Việt Nam - Nhà hàng đặc sản địa phương','amthucxeo,dacsandanang,dacsandiaphuong,monngondanang','0','1','<p dir=\"ltr\" style=\"text-align: left;\"><b>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:28px;\">&nbsp;<span style=\"font-size:16px;\"> Ẩm Thực Xèo - Niềm Tự Hào Của Người Đà Nẵng</span></span></span></b><span style=\"font-size:18px;\"><span style=\"font-family:courier new,courier,monospace;\">.</span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align: left;\">&nbsp; &nbsp; Phải mất đến 2 năm , người sáng lập Ẩm Thực Xèo đã phải đi và thưởng thức , chắc lọc những tinh hoa của ẩm thực truyền thống cũng như mang theo hương vị của từng địa phương đi qua, trước khi bắt tay vào thành lập chuỗi nhà hàng Ẩm Thực Xèo.</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align: left;\">&nbsp; &nbsp; Nghe nơi đâu có bánh xèo ngon, anh cũng tạm gác lại mọi công việc để sắp xếp đến “thăm kiến” cho bằng được. Nói rằng, chưa có chỗ nào trên đất Việt chưa in dấu chân anh có lẽ cũng không ngoa, vì hiện giờ trên menu của nhà hàng hầu như đã là trọn bộ các chủng loại Bánh Xèo của dân tộc.</p>\r\n','Welcome To','','1','0','am-thuc-xeo-1552960613.jpg','1552020406','1568690526','1');
INSERT INTO olala3w_article_menu VALUES('480','12','Tin tức hoạt động','tin-tuc-hoat-dong','','','','0','1','','','','1','0','no','1552751297','1552751297','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `seat` varchar(255) NOT NULL,
  `seat_sort` int(11) NOT NULL DEFAULT 0,
  `color` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT 0,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_car_menu` (
  `car_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`car_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `menu_main` int(1) NOT NULL DEFAULT 0,
  `sort_hide` int(11) NOT NULL DEFAULT 1,
  `menu_sm` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `icon` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category VALUES('9','1','Giới thiệu','gioi-thieu','','','','','','1','0','1','1','2','0','no','','0','1552407167','25');
INSERT INTO olala3w_category VALUES('74','6','Thực đơn','thuc-don','Thực đơn của chúng tôi','','','','','1','0','2','1','6','0','thuc-don-1555661540.jpg','','0','1555661540','25');
INSERT INTO olala3w_category VALUES('14','15','Dữ liệu','data','','','','','','1','0','1','0','1','0','no','','0','0','0');
INSERT INTO olala3w_category VALUES('13','2','Slider','slider','','','','','','1','0','1','0','1','0','no','','0','1552293952','25');
INSERT INTO olala3w_category VALUES('11','2','Hình ảnh','hinh-anh','Thư viện','','','','','1','1','1','1','4','0','hinh-anh-1552964740.jpg','','0','1559460883','25');
INSERT INTO olala3w_category VALUES('91','2','Video','video','','','','','','1','1','4','1','1','0','no','','0','1554969919','25');
INSERT INTO olala3w_category VALUES('12','1','Tin tức','tin-tuc','Hoạt Động Ẩm Thực Xèo','','','','','1','1','5','1','3','0','tin-tuc-1552961321.jpg','','0','1552961321','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_category_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category_type VALUES('1','Bài viết','article_manager','1','1');
INSERT INTO olala3w_category_type VALUES('2','Hình ảnh','gallery_manager','2','1');
INSERT INTO olala3w_category_type VALUES('7','Đăng ký email','register_email','9','0');
INSERT INTO olala3w_category_type VALUES('6','Thực đơn','product_manager','3','1');
INSERT INTO olala3w_category_type VALUES('8','Booking online','order_list','7','1');
INSERT INTO olala3w_category_type VALUES('9','Tour du lịch','tour_manager','5','0');
INSERT INTO olala3w_category_type VALUES('10','Đồ lưu niệm','gift_manager','0','0');
INSERT INTO olala3w_category_type VALUES('11','Thuê xe','car_manager','6','0');
INSERT INTO olala3w_category_type VALUES('12','Vị trí địa lý','location_manager','0','0');
INSERT INTO olala3w_category_type VALUES('13','Dữ liệu đường phố','street_manager','0','0');
INSERT INTO olala3w_category_type VALUES('14','Dữ liệu phương hướng','direction_manager','0','0');
INSERT INTO olala3w_category_type VALUES('15','Dữ liệu khác','others_manager','4','1');
INSERT INTO olala3w_category_type VALUES('16','Chiều rộng đường','road_manager','0','0');
INSERT INTO olala3w_category_type VALUES('17','Dự án','project_manager','0','0');
INSERT INTO olala3w_category_type VALUES('18','BĐS kinh doanh','bds_business_manager','0','0');
INSERT INTO olala3w_category_type VALUES('19','Dữ liệu tên dự án','prjname_manager','0','0');
INSERT INTO olala3w_category_type VALUES('20','Thư liên hệ','contact_list','8','1');
INSERT INTO olala3w_category_type VALUES('21','Văn bản / Tài liệu','document_manager','3','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_constant` (
  `constant_id` int(11) NOT NULL AUTO_INCREMENT,
  `constant` varchar(50) NOT NULL,
  `value` text CHARACTER SET utf8mb4 NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(2) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`constant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_constant VALUES('1','date','d/m/Y','Kiểu hiển thị ngày tháng năm','3','1');
INSERT INTO olala3w_constant VALUES('2','time','H:i','Kiểu hiển thị giờ phút','3','2');
INSERT INTO olala3w_constant VALUES('3','timezone','Asia/Bangkok','Múi giờ','3','4');
INSERT INTO olala3w_constant VALUES('4','title','Ẩm Thực Xèo, Đặc Sản Đà Nẵng, Bánh Xèo','Title (trang chủ)','0','1');
INSERT INTO olala3w_constant VALUES('5','description','Ẩm thực Xèo, nhà hàng Bành Xèo nỗi tiếng nhất Đà Thành, không gian đẹp, bánh xèo có có 1-0-2, đến đà nẵng ăn gì, món ngon đà nẵng','Description (trang chủ)','0','2');
INSERT INTO olala3w_constant VALUES('6','keywords','banh xeo da nang, bánh xèo ngon nhất đà nẵng, bánh xèo, bánh xèo ngon, ẩm thực xèo, nhà hàng xèo, bánh xèo nổi tiếng đà nẵng, banh xeo, den da nang an gi, đến đà nẵng ăn gì, món ngon đà nẵng, mon ngon da nang','Keywords (trang chủ)','0','3');
INSERT INTO olala3w_constant VALUES('74','script_body','<div id=\"fb-root\"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = \"//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5\";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, \'script\', \'facebook-jssdk\'));</script>\r\n                    <script id=\'autoAdsMaxLead-widget-script\' src=\'https://cdn.autoads.asia/scripts/autoads-maxlead-widget.js?business_id=27d504f73a6f4b51b7b91acc0e8c11bb\' type=\'text/javascript\' charset=\'UTF-8\' async></script>                ','Script sau body','4','6');
INSERT INTO olala3w_constant VALUES('76','link_tripadvisor','https://www.tripadvisor.com.vn/Restaurant_Review-g298085-d15603541-Reviews-Am_Thuc_Xeo-Da_Nang.html','Tripadvisor','5','5');
INSERT INTO olala3w_constant VALUES('7','email_contact','marketing01@amomi.vn','Email','0','8');
INSERT INTO olala3w_constant VALUES('8','tell_contact',';0941 750 075','Điện thoại','0','9');
INSERT INTO olala3w_constant VALUES('9','fulldate','D, d/m/Y','Kiểu hiển ngày đầy đủ','3','3');
INSERT INTO olala3w_constant VALUES('10','SMTP_username','olala.3w@gmail.com','Tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('11','SMTP_password','cdreodvwrbpbugso','Mật khẩu email','1','0');
INSERT INTO olala3w_constant VALUES('12','error_page','<p>Vì lý do kỹ&nbsp;thuật website tạm ngưng&nbsp;hoạt động. Thành thật xin lỗi các bạn&nbsp;vì sự bất tiện này!</p>\r\n','Thông báo ngừng hoạt động','0','19');
INSERT INTO olala3w_constant VALUES('13','file_logo','/uploads/files/hinnh%20logo%20fix.png','Logo front-end','0','4');
INSERT INTO olala3w_constant VALUES('14','SMTP_secure','ssl','Sử dụng xác thực','1','0');
INSERT INTO olala3w_constant VALUES('15','SMTP_host','smtp.gmail.com','Máy chủ (SMTP) Thư gửi đi','1','0');
INSERT INTO olala3w_constant VALUES('16','SMTP_port','465','Cổng gửi mail','1','0');
INSERT INTO olala3w_constant VALUES('17','backup_auto','','Tự động sao lưu','2','0');
INSERT INTO olala3w_constant VALUES('18','backup_filetype','sql.gz','Định dạng lưu file CSDL','2','0');
INSERT INTO olala3w_constant VALUES('19','backup_filecount','5','Số file CSDL lưu lại','2','0');
INSERT INTO olala3w_constant VALUES('20','backup_email','olala.3w@gmail.com','Email nhận thông báo và file','2','0');
INSERT INTO olala3w_constant VALUES('21','SMTP_mailname','ẨM THỰC XÈO','Tên tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('22','link_facebook','https://www.facebook.com/amthucxeo.vietnam/','Facebook','5','1');
INSERT INTO olala3w_constant VALUES('23','link_googleplus','https://plus.google.com','Google+','5','2');
INSERT INTO olala3w_constant VALUES('24','link_twitter','https://twitter.com/xeo_am','Twitter','5','3');
INSERT INTO olala3w_constant VALUES('25','address_contact','75 Hoàng Văn Thụ, Q. Hải Châu, Tp. Đà Nẵng','Địa chỉ','0','11');
INSERT INTO olala3w_constant VALUES('73','script_bottom','<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?\'http\':\'https\';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+\'://platform.twitter.com/widgets.js\';fjs.parentNode.insertBefore(js,fjs);}}(document, \'script\', \'twitter-wjs\');</script>\r\n<script src=\"https://apis.google.com/js/platform.js\" async defer>\r\n  {lang: \'vi\'}\r\n</script>\r\n','Script cuối trang','4','7');
INSERT INTO olala3w_constant VALUES('26','content_registertry','','Email đăng ký học thử','13','17');
INSERT INTO olala3w_constant VALUES('27','author_google','','ID profile Google+','4','1');
INSERT INTO olala3w_constant VALUES('28','google_analytics','<!-- Global site tag (gtag.js) - Google Analytics -->\r\n<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-141586273-1\"></script>\r\n<script>\r\n  window.dataLayer = window.dataLayer || [];\r\n  function gtag(){dataLayer.push(arguments);}\r\n  gtag(\'js\', new Date());\r\n\r\n\r\n  gtag(\'config\', \'UA-141586273-1\');\r\n</script>','Google analytics','4','4');
INSERT INTO olala3w_constant VALUES('29','chat_online','','Script Chat Online','4','5');
INSERT INTO olala3w_constant VALUES('30','english_test','','Kiểm tra tiếng Anh của bạn','13','18');
INSERT INTO olala3w_constant VALUES('31','google_calendar','','Google Calendar (Account)','4','3');
INSERT INTO olala3w_constant VALUES('32','help_address','killlllme@gmail.com,0974.779.085,huy.to.bsn,mr.killlllme','Tư vấn - Địa chỉ','13','8');
INSERT INTO olala3w_constant VALUES('33','help_icon','fa-envelope-o,fa-phone,fa-skype,fa-facebook','Tư vấn - Icon','13','9');
INSERT INTO olala3w_constant VALUES('34','link_youtube','https://www.youtube.com/channel/UCcbP8RWuEsM6J0q695UJTrg?view_as=subscriber','Youtube','5','4');
INSERT INTO olala3w_constant VALUES('35','search_destination','Hà Nội,Đà Nẵng,Hồ Chí Minh,Phú Quốc,Nha Trang,Hạ Long,Đà Lạt,Phong Nha Kẻ Bàng,Côn đảo Vũng Tàu,Thái Lan,Singapore,Malaysia,Campuchia,Trung Quốc,Nhật Bản,Hàn Quốc,Hà Lan,Myanmar,Úc,Hong Kong,Philippines,Indonesia,Đài Loan,Châu Á,Châu Âu,Châu Mỹ,Châu Phi,Châu Úc','Điểm đến (Tìm kiếm tour)','13','8');
INSERT INTO olala3w_constant VALUES('36','search_day','1 Ngày,1 Ngày 1 Đêm,2 Ngày,2 Ngày 1 Đêm,3 Ngày,3 Ngày 2 Đêm,4 Ngày,4 Ngày 3 Đêm,5 Ngày,5 Ngày 4 Đêm,6 Ngày,6 Ngày 5 Đêm,7 Ngày,7 Ngày 6 Đêm,8 Ngày,8 Ngày 7 Đêm,9 Ngày,9 Ngày 8 Đêm,10 Ngày,10 Ngày 9 Đêm,11 Ngày,11 Ngày 10 Đêm,12 Ngày,12 Ngày 11 Đêm,1 Tuần,2 Tuần,3 Tuần,1 Tháng,2 Tháng,3 Tháng','Thời gian (Tìm kiếm tour)','13','9');
INSERT INTO olala3w_constant VALUES('75','fb_app_id','','Facebook App ID','4','2');
INSERT INTO olala3w_constant VALUES('77','upload_img_max_w','1900','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('78','upload_max_size','52428800','Dung lượng tối đa','6','2');
INSERT INTO olala3w_constant VALUES('79','upload_checking_mode','mild','Kiểu kiểm tra file tải lên','6','3');
INSERT INTO olala3w_constant VALUES('80','upload_type','1,4,5,6,7,8,9,10,11','Loại files cho phép','6','4');
INSERT INTO olala3w_constant VALUES('81','upload_ext','','Phần mở rộng bị cấm','6','5');
INSERT INTO olala3w_constant VALUES('82','upload_mime','','Loại mime bị cấm','6','6');
INSERT INTO olala3w_constant VALUES('83','upload_img_max_h','594','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('84','upload_auto_resize','1','Tự động resize ảnh','6','1');
INSERT INTO olala3w_constant VALUES('85','article_author','','Property = article:author','4','2');
INSERT INTO olala3w_constant VALUES('86','meta_author','Ẩm Thực Xèo','Meta author','0','4');
INSERT INTO olala3w_constant VALUES('88','meta_site_name','Ẩm Thực Xèo','Meta site name','0','5');
INSERT INTO olala3w_constant VALUES('89','meta_copyright','© 2019 Ẩm Thực Xèo. All Rights Reserved','Meta copyright','0','6');
INSERT INTO olala3w_constant VALUES('90','image_thumbnailUrl','/uploads/files/am-thuc-xeo-da-nang.jpg','Image : thumbnailUrl','0','7');
INSERT INTO olala3w_constant VALUES('91','set_time','Giờ mở cửa : Monday - Friday : 5:30PM - 11:00PM | Saturday - Sunday : 4:30PM - 10:00PM','Time','0','10');
INSERT INTO olala3w_constant VALUES('92','link_instagram','https://www.instagram.com/xeo_restaurant/','Instagram','5','6');

-- --------------------------------------------------------

CREATE TABLE `olala3w_contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-send-o',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_contact VALUES('2','Trần Hữu Thịnh','106/06 Cách Mạng Tháng Tám','thinh.coi.555@gmail.com','0905665695','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"white\" style=\"padding:10px 0; text-align: center;\"><a href=\"http://ola.amthucxeo.com\" target=\"_blank\"><img src=\"http://ola.amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ngon Ngon\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Trần Hữu Thịnh</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong vòng 24h tới.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN LIÊN HỆ CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Trần Hữu Thịnh<br/><label style=\"font-weight:600;padding-left:12px;\">Địa chỉ: </label> 106/06 Cách Mạng Tháng Tám<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> thinh.coi.555@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Số điện thoại: </label> 0905665695<br/><label style=\"font-weight:600;padding-left:12px;\">Nội dung: </label> Kiểm thử chức năng liên hệ.<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 127.0.0.1<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày gửi liên hệ: </label> 19/03/2019 23:32<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;font-weight:bold;\">Ngon Ngon</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','127.0.0.1','fa-send-o','1553013154','1553013162');
INSERT INTO olala3w_contact VALUES('3','Trần Hữu Thịnh','106/06 Cách Mạng Tháng Tám','thinh.coi.555@gmail.com','0905665695','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"http://ola.amthucxeo.com\" target=\"_blank\"><img src=\"http://ola.amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ngon Ngon\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Trần Hữu Thịnh</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong vòng 24h tới.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN LIÊN HỆ CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Trần Hữu Thịnh<br/><label style=\"font-weight:600;padding-left:12px;\">Địa chỉ: </label> 106/06 Cách Mạng Tháng Tám<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> thinh.coi.555@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Số điện thoại: </label> 0905665695<br/><label style=\"font-weight:600;padding-left:12px;\">Nội dung: </label> Kiểm thử chức năng liên hệ.<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 127.0.0.1<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày gửi liên hệ: </label> 19/03/2019 23:34<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;font-weight:bold;\">Ngon Ngon</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','127.0.0.1','fa-send-o','1553013272','1553051920');
INSERT INTO olala3w_contact VALUES('4','Trần Hữu Thịnh','106/06 Cách Mạng Tháng Tám','thinh.coi.555@gmail.com','0905665695','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"http://ola.amthucxeo.com\" target=\"_blank\"><img src=\"http://ola.amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ngon Ngon\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Trần Hữu Thịnh</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN LIÊN HỆ CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Trần Hữu Thịnh<br/><label style=\"font-weight:600;padding-left:12px;\">Địa chỉ: </label> 106/06 Cách Mạng Tháng Tám<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> thinh.coi.555@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Số điện thoại: </label> 0905665695<br/><label style=\"font-weight:600;padding-left:12px;\">Nội dung: </label> Kiểm thử chức năng liên hệ.<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 127.0.0.1<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày gửi liên hệ: </label> 19/03/2019 23:40<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;font-weight:bold;\">Ngon Ngon</td></tr><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;font-weight:bold;\">0941 750 075</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','127.0.0.1','fa-send-o','1553013634','1559987301');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_privilege` (
  `privilege_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `type` varchar(30) NOT NULL,
  `privilege_slug` varchar(50) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5010 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_privilege VALUES('2250','1','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('2249','1','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('2248','1','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('2255','1','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('1071','1','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('1545','1','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('1531','1','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('1530','1','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('2656','1','bds_business','bds_business_del;50');
INSERT INTO olala3w_core_privilege VALUES('2103','2','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2102','2','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2101','2','article','article_del;13');
INSERT INTO olala3w_core_privilege VALUES('2100','2','article','article_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2099','2','article','article_add;13');
INSERT INTO olala3w_core_privilege VALUES('2098','2','article','article_list;13');
INSERT INTO olala3w_core_privilege VALUES('2097','2','article','article_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2096','2','article','article_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2095','2','article','article_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2094','2','article','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2093','2','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2092','2','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2091','2','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2090','2','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2089','2','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2088','2','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2087','2','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2086','2','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('273','2','gallery','gallery_menu_add;6');
INSERT INTO olala3w_core_privilege VALUES('274','2','gallery','gallery_menu_edit;6');
INSERT INTO olala3w_core_privilege VALUES('275','2','gallery','gallery_menu_del;6');
INSERT INTO olala3w_core_privilege VALUES('276','2','gallery','gallery_add;6');
INSERT INTO olala3w_core_privilege VALUES('277','2','gallery','gallery_edit;6');
INSERT INTO olala3w_core_privilege VALUES('278','2','gallery','gallery_del;6');
INSERT INTO olala3w_core_privilege VALUES('279','2','pages','pages_add');
INSERT INTO olala3w_core_privilege VALUES('280','2','pages','pages_edit');
INSERT INTO olala3w_core_privilege VALUES('281','2','pages','pages_del');
INSERT INTO olala3w_core_privilege VALUES('287','2','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('288','2','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('289','2','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('290','2','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('291','2','config','config_ipdie');
INSERT INTO olala3w_core_privilege VALUES('292','2','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('293','2','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('294','2','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('295','2','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('296','2','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('330','2','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('2655','1','bds_business','bds_business_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2654','1','bds_business','bds_business_add;50');
INSERT INTO olala3w_core_privilege VALUES('1070','1','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('1544','1','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('1529','1','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('1528','1','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3333','1','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('2653','1','bds_business','bds_business_list;50');
INSERT INTO olala3w_core_privilege VALUES('3331','1','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('1543','1','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3332','1','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('2254','1','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2252','1','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('2251','1','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('2208','1','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2207','1','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2206','1','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2205','1','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2204','1','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2203','1','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2202','1','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2201','1','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('1532','1','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('1542','1','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('1541','1','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('1540','1','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('1546','1','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('2200','1','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2198','1','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2199','1','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2197','1','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2195','1','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2196','1','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2194','1','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('4993','1','article','article_del;12');
INSERT INTO olala3w_core_privilege VALUES('3983','1','tour','tour_del;70');
INSERT INTO olala3w_core_privilege VALUES('3982','1','tour','tour_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3981','1','tour','tour_add;70');
INSERT INTO olala3w_core_privilege VALUES('3980','1','tour','tour_list;70');
INSERT INTO olala3w_core_privilege VALUES('3979','1','tour','tour_menu_del;70');
INSERT INTO olala3w_core_privilege VALUES('3978','1','tour','tour_menu_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3977','1','tour','tour_menu_add;70');
INSERT INTO olala3w_core_privilege VALUES('3976','1','tour','category_edit;70');
INSERT INTO olala3w_core_privilege VALUES('1712','1','gift','gift_add;22');
INSERT INTO olala3w_core_privilege VALUES('1711','1','gift','gift_list;22');
INSERT INTO olala3w_core_privilege VALUES('1710','1','gift','gift_menu_del;22');
INSERT INTO olala3w_core_privilege VALUES('1709','1','gift','gift_menu_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1708','1','gift','gift_menu_add;22');
INSERT INTO olala3w_core_privilege VALUES('1707','1','gift','category_edit;22');
INSERT INTO olala3w_core_privilege VALUES('3838','1','car','car_list;67');
INSERT INTO olala3w_core_privilege VALUES('3837','1','car','car_menu_del;67');
INSERT INTO olala3w_core_privilege VALUES('3836','1','car','car_menu_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3835','1','car','car_menu_add;67');
INSERT INTO olala3w_core_privilege VALUES('3834','1','car','category_edit;67');
INSERT INTO olala3w_core_privilege VALUES('1713','1','gift','gift_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1714','1','gift','gift_del;22');
INSERT INTO olala3w_core_privilege VALUES('2193','1','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('3328','1','info','sys_info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3327','1','info','sys_info_site');
INSERT INTO olala3w_core_privilege VALUES('4992','1','article','article_edit;12');
INSERT INTO olala3w_core_privilege VALUES('2085','2','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4985','1','article','article_del;15');
INSERT INTO olala3w_core_privilege VALUES('4984','1','article','article_edit;15');
INSERT INTO olala3w_core_privilege VALUES('4982','1','article','article_list;15');
INSERT INTO olala3w_core_privilege VALUES('2253','1','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('2256','1','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2290','1','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2291','1','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2292','1','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2780','1','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2779','1','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2778','1','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2777','1','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2776','1','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3841','1','car','car_del;67');
INSERT INTO olala3w_core_privilege VALUES('3840','1','car','car_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3839','1','car','car_add;67');
INSERT INTO olala3w_core_privilege VALUES('4027','1','document','document_add;73');
INSERT INTO olala3w_core_privilege VALUES('2652','1','bds_business','bds_business_menu_del;50');
INSERT INTO olala3w_core_privilege VALUES('2651','1','bds_business','bds_business_menu_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2650','1','bds_business','bds_business_menu_add;50');
INSERT INTO olala3w_core_privilege VALUES('2649','1','bds_business','category_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2781','1','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2782','1','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2783','1','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2784','1','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2785','1','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2786','1','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2787','1','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2788','1','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2789','1','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2790','1','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2791','1','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2792','9','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2793','9','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2794','9','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2795','9','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2796','9','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2797','11','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2798','11','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2799','11','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2800','11','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2801','11','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2802','11','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2803','11','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2804','11','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2805','11','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2806','11','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('3031','11','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('3030','11','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2809','11','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('2815','11','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2814','11','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2813','11','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2816','1','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('2817','1','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('2818','1','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('2830','12','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2831','12','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2832','12','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2833','12','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2834','12','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2835','12','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2836','12','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2837','12','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2838','12','category','prjname_manager');
INSERT INTO olala3w_core_privilege VALUES('2839','12','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2840','12','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('2841','12','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2842','12','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2843','12','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2908','12','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2909','12','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2910','12','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2911','12','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2912','12','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2913','12','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2914','12','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2915','12','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2916','12','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2917','12','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('2918','12','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2919','12','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('2920','12','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('2921','12','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('2922','12','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2923','12','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('2924','12','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2925','12','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('2926','12','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2927','12','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('2928','12','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('2929','12','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('2930','12','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2931','12','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('2932','12','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2933','12','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2934','12','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2935','12','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2936','12','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2937','12','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2938','12','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2939','12','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2940','12','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2941','12','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2942','12','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2943','12','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2944','12','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2945','12','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2946','12','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2947','12','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2948','12','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2949','12','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('2950','12','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2951','12','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('2952','12','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('2953','12','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('2954','12','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2955','12','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('2956','12','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2957','12','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('2958','12','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2959','12','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('2960','12','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('2961','12','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('2962','12','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2963','12','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('2964','12','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2965','12','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2966','12','product','product_menu_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2967','12','product','product_menu_del;37');
INSERT INTO olala3w_core_privilege VALUES('2968','12','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2969','12','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2970','12','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2971','12','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2985','12','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2984','12','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2983','12','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2982','12','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2981','12','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('2980','12','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2986','12','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2987','12','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2988','12','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2989','12','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2990','12','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2991','12','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2992','12','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2993','12','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2994','12','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2995','12','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2996','12','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2997','12','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2998','12','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2999','12','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('3000','12','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('3001','12','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('3002','12','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('3003','12','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('3004','12','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('3005','12','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('3006','12','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('3007','12','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('3008','12','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('3009','12','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('3010','12','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('3011','12','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('3012','12','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('3013','12','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3014','12','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('3015','12','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('3016','12','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('3017','12','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3018','12','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('3019','12','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('3020','12','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('3021','12','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('3022','12','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('3023','12','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('3024','12','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('3025','12','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('3026','12','info','Info_diary');
INSERT INTO olala3w_core_privilege VALUES('3027','12','info','Info_php');
INSERT INTO olala3w_core_privilege VALUES('3028','12','info','Info_site');
INSERT INTO olala3w_core_privilege VALUES('3029','12','info','Info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3032','11','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3033','11','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('3034','11','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('3035','11','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('3036','11','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3037','11','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('3038','11','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3039','11','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('3040','11','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3041','11','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('3042','11','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('3043','11','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('3044','11','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3045','11','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('3046','11','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3047','11','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('3048','11','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3049','11','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('3050','11','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('3051','11','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('3052','11','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3053','11','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('3054','11','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3055','11','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('3056','11','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3057','11','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('3058','11','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('3059','11','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('3060','11','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3061','11','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('3062','11','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3063','11','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('3064','11','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3065','11','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('3066','11','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('3067','11','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('3068','11','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3069','11','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('3070','11','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3071','11','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('3072','11','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3073','11','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('3074','11','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('3075','11','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('3076','11','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3077','11','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('3078','11','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3079','11','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('3080','11','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3081','11','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('3082','11','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('3083','11','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('3084','11','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3085','11','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('3137','11','product','owner_real;37');
INSERT INTO olala3w_core_privilege VALUES('3136','11','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('3135','11','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('3134','11','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('4983','1','article','article_add;15');
INSERT INTO olala3w_core_privilege VALUES('4981','1','article','article_menu_del;15');
INSERT INTO olala3w_core_privilege VALUES('3133','11','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('3138','11','product','owner_cus;37');
INSERT INTO olala3w_core_privilege VALUES('3326','1','info','sys_info_php');
INSERT INTO olala3w_core_privilege VALUES('3325','1','info','sys_info_diary');
INSERT INTO olala3w_core_privilege VALUES('3334','1','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('4951','1','gallery','gallery_add;11');
INSERT INTO olala3w_core_privilege VALUES('4950','1','gallery','gallery_list;11');
INSERT INTO olala3w_core_privilege VALUES('4949','1','gallery','gallery_menu_del;11');
INSERT INTO olala3w_core_privilege VALUES('4948','1','gallery','gallery_menu_edit;11');
INSERT INTO olala3w_core_privilege VALUES('4947','1','gallery','gallery_menu_add;11');
INSERT INTO olala3w_core_privilege VALUES('4946','1','gallery','category_edit;11');
INSERT INTO olala3w_core_privilege VALUES('4945','1','gallery','gallery_del;13');
INSERT INTO olala3w_core_privilege VALUES('4943','1','gallery','gallery_add;13');
INSERT INTO olala3w_core_privilege VALUES('4944','1','gallery','gallery_edit;13');
INSERT INTO olala3w_core_privilege VALUES('4939','1','gallery','gallery_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('4026','1','document','document_list;73');
INSERT INTO olala3w_core_privilege VALUES('4025','1','document','document_menu_del;73');
INSERT INTO olala3w_core_privilege VALUES('4024','1','document','document_menu_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4023','1','document','document_menu_add;73');
INSERT INTO olala3w_core_privilege VALUES('4022','1','document','category_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4028','1','document','document_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4029','1','document','document_del;73');
INSERT INTO olala3w_core_privilege VALUES('4998','1','category','order_list');
INSERT INTO olala3w_core_privilege VALUES('4980','1','article','article_menu_edit;15');
INSERT INTO olala3w_core_privilege VALUES('4979','1','article','article_menu_add;15');
INSERT INTO olala3w_core_privilege VALUES('4913','1','product','product_del;74');
INSERT INTO olala3w_core_privilege VALUES('4912','1','product','product_edit;74');
INSERT INTO olala3w_core_privilege VALUES('4910','1','product','product_list;74');
INSERT INTO olala3w_core_privilege VALUES('4911','1','product','product_add;74');
INSERT INTO olala3w_core_privilege VALUES('4909','1','product','product_menu_del;74');
INSERT INTO olala3w_core_privilege VALUES('4906','1','product','category_edit;74');
INSERT INTO olala3w_core_privilege VALUES('4907','1','product','product_menu_add;74');
INSERT INTO olala3w_core_privilege VALUES('4908','1','product','product_menu_edit;74');
INSERT INTO olala3w_core_privilege VALUES('4991','1','article','article_add;12');
INSERT INTO olala3w_core_privilege VALUES('4990','1','article','article_list;12');
INSERT INTO olala3w_core_privilege VALUES('4989','1','article','article_menu_del;12');
INSERT INTO olala3w_core_privilege VALUES('4988','1','article','article_menu_edit;12');
INSERT INTO olala3w_core_privilege VALUES('5009','1','others','others_del;14');
INSERT INTO olala3w_core_privilege VALUES('5008','1','others','others_edit;14');
INSERT INTO olala3w_core_privilege VALUES('5007','1','others','others_add;14');
INSERT INTO olala3w_core_privilege VALUES('5006','1','others','others_list;14');
INSERT INTO olala3w_core_privilege VALUES('5005','1','others','others_menu_del;14');
INSERT INTO olala3w_core_privilege VALUES('5004','1','others','others_menu_edit;14');
INSERT INTO olala3w_core_privilege VALUES('5003','1','others','others_menu_add;14');
INSERT INTO olala3w_core_privilege VALUES('5002','1','others','category_edit;14');
INSERT INTO olala3w_core_privilege VALUES('4987','1','article','article_menu_add;12');
INSERT INTO olala3w_core_privilege VALUES('4986','1','article','category_edit;12');
INSERT INTO olala3w_core_privilege VALUES('4961','1','gallery','gallery_del;91');
INSERT INTO olala3w_core_privilege VALUES('4960','1','gallery','gallery_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4959','1','gallery','gallery_add;91');
INSERT INTO olala3w_core_privilege VALUES('4958','1','gallery','gallery_list;91');
INSERT INTO olala3w_core_privilege VALUES('4957','1','gallery','gallery_menu_del;91');
INSERT INTO olala3w_core_privilege VALUES('4956','1','gallery','gallery_menu_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4955','1','gallery','gallery_menu_add;91');
INSERT INTO olala3w_core_privilege VALUES('4954','1','gallery','category_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4953','1','gallery','gallery_del;11');
INSERT INTO olala3w_core_privilege VALUES('4952','1','gallery','gallery_edit;11');
INSERT INTO olala3w_core_privilege VALUES('4978','1','article','category_edit;15');
INSERT INTO olala3w_core_privilege VALUES('4977','1','article','article_del;14');
INSERT INTO olala3w_core_privilege VALUES('4942','1','gallery','gallery_list;13');
INSERT INTO olala3w_core_privilege VALUES('4941','1','gallery','gallery_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('4976','1','article','article_edit;14');
INSERT INTO olala3w_core_privilege VALUES('4975','1','article','article_add;14');
INSERT INTO olala3w_core_privilege VALUES('4974','1','article','article_list;14');
INSERT INTO olala3w_core_privilege VALUES('4973','1','article','article_menu_del;14');
INSERT INTO olala3w_core_privilege VALUES('4972','1','article','article_menu_edit;14');
INSERT INTO olala3w_core_privilege VALUES('4971','1','article','article_menu_add;14');
INSERT INTO olala3w_core_privilege VALUES('4969','1','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('4970','1','article','category_edit;14');
INSERT INTO olala3w_core_privilege VALUES('4968','1','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4967','1','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('4966','1','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('4965','1','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('4963','1','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('4940','1','gallery','gallery_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('4938','1','gallery','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('4997','1','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('4964','1','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4962','1','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4996','1','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('4995','1','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('4994','1','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4999','1','category','contact_list');
INSERT INTO olala3w_core_privilege VALUES('5000','1','category','register_email');
INSERT INTO olala3w_core_privilege VALUES('5001','1','category','plugin_page');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_role VALUES('1','Administrator','Nhóm quản trị tối cao','1','1441786254','1');
INSERT INTO olala3w_core_role VALUES('2','Tester','Nhóm kiểm thử','1','1441851198','1');
INSERT INTO olala3w_core_role VALUES('9','Broker','Nhân viên môi giới. Chỉ nhập và quản lý thông tin BĐS.','1','1439055844','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_name` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT 0,
  `birthday` int(11) NOT NULL DEFAULT 0,
  `apply` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT 1,
  `vote` bigint(20) NOT NULL DEFAULT 1,
  `click_vote` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id_edit` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_user VALUES('1','1','admin','51383c6d1a0848e60200ceda4819264b','Administrator','1','694198800','Quản trị website','info@amomi.vn','0941750075','','<p>75 Hoàng Văn Thụ, Q. Hải Châu, Tp. Đà Nẵng</p>\r\n','0','1','u_1553044290_bddf95185f7ba07fe8395d61942a935e.png','1','1','1','1408159832','1568873482','25');
INSERT INTO olala3w_core_user VALUES('25','1','dev','7dff79b41f9b4334bc2f7490b4cde32d','Trần Hữu Thịnh','1','-460969200','','thinh.tran@olalagroup.vn','0905665695','','','1','1','u_1552015852_dc015a34d7e9da724c7081eefae54c7c.jpg','1','1','1','0','1552015852','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_direction` (
  `direction_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`direction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `release_date` int(11) NOT NULL DEFAULT 0,
  `effective_date` int(11) NOT NULL DEFAULT 0,
  `file` varchar(255) NOT NULL DEFAULT 'no',
  `type` varchar(5) NOT NULL DEFAULT 'unk',
  `size` int(11) NOT NULL DEFAULT 0,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document_menu` (
  `document_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL DEFAULT 'not-found',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`document_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `upload_id` bigint(20) NOT NULL DEFAULT 0,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `link` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=712 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery VALUES('690','99','Khách Hàng Của Chúng Tôi','khach-hang-cua-chung-toi','','','','khach-hang-cua-chung-toi-1552965103.jpg','2023','','','','1','0','79','1552965000','1567762711','1');
INSERT INTO olala3w_gallery VALUES('691','99','Thưởng Thức Món Ngon','thuong-thuc-mon-ngon','','','','thuong-thuc-mon-ngon-1552967350.jpg','2024','','','','1','0','124','1552965120','1567763756','1');
INSERT INTO olala3w_gallery VALUES('692','99','Triển Lãm Hàng Việt Đà Nẵng','trien-lam-hang-viet-da-nang','','','','trien-lam-ket-noi-hang-viet-da-nang-2019-1552965384.jpg','2025','','','','1','0','103','1552965240','1567763734','1');
INSERT INTO olala3w_gallery VALUES('685','97','Bánh xèo thịt gà','banh-xeo-thit-ga','','','','banh-xeo-thit-ga-1552791204.png','1978','','','','1','0','1','1552403580','1567847899','25');
INSERT INTO olala3w_gallery VALUES('686','97','Bánh xèo tôm hùm','banh-xeo-tom-hum','','','','banh-xeo-tom-hum-1552791067.jpg','1979','','','','1','0','1','1552489980','1567847899','25');
INSERT INTO olala3w_gallery VALUES('689','99','Những Người Bạn Nghệ Sĩ','nhung-nguoi-ban-nghe-si','','','','nhung-nguoi-ban-nghe-si-1552790018.png','2017','','','','1','0','105','1552789980','1567763779','1');
INSERT INTO olala3w_gallery VALUES('683','97','Nem lụi','nem-lui','','','','nem-lui-1552791277.png','1976','','','','1','0','1','1552403520','1567847900','25');
INSERT INTO olala3w_gallery VALUES('684','97','Bánh xèo thịt bò','banh-xeo-thit-bo','','','','banh-xeo-thit-bo-1552791242.png','1977','','','','1','0','1','1552403580','1567847900','25');
INSERT INTO olala3w_gallery VALUES('693','98','Bánh Xèo','banh-xeo-jl5zm118fc','','','','jvnehya1-banh-xeo.jpg','0','','','https://www.youtube.com/watch?v=J-sHqLYOYHM','1','0','38','1554969900','1567764021','1');
INSERT INTO olala3w_gallery VALUES('694','98','Bánh Xèo - Ẩm Thực Xèo','banh-xeo-am-thuc-xeo','','','','108t0hhx-banh-xeo-am-thuc-xeo.jpg','0','','','https://www.youtube.com/watch?v=ehg-0Z1SYG0','1','0','38','1554969960','1567764012','1');
INSERT INTO olala3w_gallery VALUES('695','98','Bánh Xèo - 75 Hoàng Văn Thụ, Đà Nẵng','banh-xeo-75-hoang-van-thu-da-nang','','','','twkscpm9-banh-xeo-75-hoang-van-thu-da-nang.jpg','0','','','https://www.youtube.com/watch?v=DfXQQbvVlOA','1','0','38','1554952020','1567764043','1');
INSERT INTO olala3w_gallery VALUES('696','98','Đặc Sản Bánh Xèo Đà Nẵng','dac-san-banh-xeo-da-nang','','','','3fxmd05n-dac-san-banh-xeo-da-nang.jpg','0','','','https://www.youtube.com/watch?v=C0olsLLIB8o','1','0','37','1554970020','1567763998','1');
INSERT INTO olala3w_gallery VALUES('697','99','Người Mẫu Thể Hình Việt Nam 2019','nguoi-mau-the-hinh-viet-nam-2019','','','','nguoi-mau-the-hinh-viet-nam-2019-1555316288.jpg','2054','<p style=\"margin-right: 0px; margin-bottom: 6px; margin-left: 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(29, 33, 41); text-align: start;\"><a class=\"_58cn\" data-ft=\"{\" href=\"https://www.facebook.com/hashtag/%E1%BA%A9m_th%E1%BB%B1c_x%C3%A8o?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBDeGHSsxqHGTBpfJBbRDnpzEeL8v-4KJ_1VTb2c8-MVs1QXZjDeSZPRgclvvegzkUqI4Of6wzbVNmDxCkXzZwm7eXW-D7uK-y6Se-3ttUFct2VSi-IXnkZmDaZovdv-yPamRWkVKFlv9tKoN00K51zkgocdccmeGu2q2mOHeKJqnXdA16Ii1udBTKsWdWIYpZKHXPiw5ubULOhcZCVMd50qeZAmTfZeFDwL5VtRzu494ICFAQ2RBxIUQRBaOdb69cf7oUjmvMsWJ1ydrY9Hz3K9gnqVctrdyQh45l9pNatNzBw2O1hUsPtpY-kZ9iTZdZEYa9m1ggP4XZFhfW3ql_VQA&amp;__tn__=%2ANK-R\" style=\"color: rgb(54, 88, 153); cursor: pointer; font-family: inherit;\"><span class=\"_5afx\" style=\"direction: ltr; unicode-bidi: isolate; font-family: inherit;\"><span aria-label=\"hashtag\" class=\"_58cl _5afz\" style=\"unicode-bidi: isolate; font-family: inherit;\">#</span><span class=\"_58cm\" style=\"font-family: inherit;\">ẨM_Thực_Xèo</span></span></a>&nbsp;hân hạnh được đón đoàn FITNESS MODEL Người mẫu thể hình VIET NAM 2019 đến trải nghiệm và thưởng thức những món ăn đặc sản Đà Nẵng tại nhà hàng.<span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t66=\"\" v9=\"\">💓</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" t66=\"\" v9=\"\">💓</span></span></p>\r\n\r\n<p style=\"margin: 6px 0px; font-family: Helvetica, Arial, sans-serif; color: rgb(29, 33, 41); text-align: start;\">Cảm ơn Hoa hậu Phan Thị Mơ và Hoa khôi Trương Diệu Ngọc đã có những lời khen ngợi dành cho nhà hàng.<span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" tea=\"\" v9=\"\">🥰</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" tea=\"\" v9=\"\">🥰</span></span><span class=\"_5mfr\" style=\"margin-right: 1px; margin-left: 1px; font-family: inherit;\"><span 1=\"\" 16=\"\" class=\"_6qdm\" emoji.php=\"\" https:=\"\" images=\"\" static.xx.fbcdn.net=\"\" style=\"background-repeat: no-repeat; background-size: contain; color: transparent; display: inline-block; text-shadow: none; vertical-align: text-bottom; font-family: inherit; height: 16px; width: 16px; font-size: 16px; background-image: url(\" tea=\"\" v9=\"\">🥰</span></span></p>\r\n','','','1','0','90','1555316100','1567763702','1');
INSERT INTO olala3w_gallery VALUES('699','99','Miss World','miss-world','','','','miss-world-1557287118.jpg','2098','','','','1','0','85','1557286380','1564216969','25');
INSERT INTO olala3w_gallery VALUES('700','98','Các Đầu Bếp Quốc Tế Ghé Thăm Ẩm Thực Xèo','cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo','Lễ Hội Ẩm Thực Quốc Tế - Ẩm Thực Xèo','Đầu bếp quốc tế ghé thăm Ẩm Thực Xèo','amthucxeo,diff,daubepquocte,festivalfood,dacsandanang','waxyhqq2-cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo.jpg','0','<p>Hình ảnh các đầu bếp nổi tiếng trên khắp thế giới ghé thăm ẩm thực xèo . Ẩm thực xèo - Nhà hàng đặc sản địa phương tự hào là Nhà Hàng bánh xèo lớn nhất Đà Nẵng . Cảm ơn các ban ngành đã tạo điều kiện để Ẩm Thực Xèo tổ chức buổi họp mặt .</p>\r\n','','https://www.youtube.com/watch?v=HFna1thmRlg','1','1','30','1559459760','1568690078','1');
INSERT INTO olala3w_gallery VALUES('701','99','Hình Ảnh Các Đầu Bếp Quốc Tế Ghé Thăm Ẩm Thực Xèo','hinh-anh-cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo','','','','hinh-anh-cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo-1559460201.jpg','2105','','','','1','1','68','1559460060','1567763627','1');
INSERT INTO olala3w_gallery VALUES('705','99','Ẩm Thực Xèo - Món Ngon Xứ Quảng - Đến Đà Nẵng Phải Đến Xèo','am-thuc-xeo-mon-ngon-xu-quang-den-da-nang-phai-den-xeo','','','','am-thuc-xeo-mon-ngon-xu-quang-den-da-nang-phai-den-xeo-1559552252.jpg','2110','','','','0','0','3','1559552040','1567763584','1');
INSERT INTO olala3w_gallery VALUES('706','99','Combo Món Ăn Chiêu Đãi Đầu Bếp Quốc Tế Tại Ẩm Thực Xèo - DNIFF International Chef','combo-mon-an-chieu-dai-dau-bep-quoc-te-tai-am-thuc-xeo-dniff-international-chef','','','','combo-mon-an-chieu-dai-dau-bep-quoc-te-tai-am-thuc-xeo-dniff-international-c-1559553878.jpg','2111','','','','0','1','2','1559553480','1567763556','1');
INSERT INTO olala3w_gallery VALUES('707','99','Chương Trình Giao Lưu Cùng KOLs Tik Tok Việt Nam Tại Ẩm Thực Xèo ','chuong-trinh-giao-luu-cung-kols-tik-tok-viet-nam-tai-am-thuc-xeo','','','','chuong-trinh-giao-luu-cung-kols-tik-tok-viet-nam-tai-am-thuc-xeo-1560344177.jpg','2115','','','','1','0','47','1560343800','1567763474','1');
INSERT INTO olala3w_gallery VALUES('711','97','Bằng Hữu Tương Giao - Trao Nhau Tam Hữu','bang-huu-tuong-giao-trao-nhau-tam-huu','','','','bang-huu-tuong-giao-trao-nhau-tam-huu-1567847877.jpg','2123','','','','1','1','1','1567847820','1567847885','1');
INSERT INTO olala3w_gallery VALUES('708','99','Chào Mừng Đoàn Khách Đến Từ Sở Nội Vụ TP.Đà Nẵng','chao-mung-doan-khach-den-tu-so-noi-vu-tp-da-nang','','','','chao-mung-doan-khach-den-tu-so-noi-vu-tp-da-nang-1565582117.jpg','2122','','','','1','1','19','1565581320','1567763444','1');
INSERT INTO olala3w_gallery VALUES('709','98','Chào Đón Cộng Đồng Brand Walkers Đến Với Ẩm Thực Xèo','chao-don-cong-dong-brand-walkers-den-voi-am-thuc-xeo','CHÀO ĐÓN CỘNG ĐỒNG BRAND WALKERS ĐẾN VỚI ẨM THỰC XÈO - ĐÀ NẴNG','Hơn 200 thành viên trong cộng đồng Brand Walkers toàn quốc đến với Ẩm Thực Xèo - Đà Nẵng . Ẩm Thực Xèo đã mang đến bữa trưa vô cùng thú vị với những món ăn là đặc sản đặc trưng của miền trung , mang tới sự mới mẻ đầy màu sắc của bạn bè ba miền . ','monngondanang,amthucxeo,brandwalkers,megaevent,hanhtrinhbay','43aoe3gd-chao-don-cong-dong-brand-walkers-den-voi-am-thuc-xeo.jpg','0','','','https://www.youtube.com/watch?v=iNIuLxOlBKI','1','0','13','1565841600','1568781977','25');
INSERT INTO olala3w_gallery VALUES('710','98','Ẩm Thực Xèo - Tái Hiện Hình Ảnh Bánh Xèo Lớn Nhất Thế Giới - Phần Trình Diễn Của 13 Đầu Bếp Quốc Tế','am-thuc-xeo-tai-hien-hinh-anh-banh-xeo-lon-nhat-the-gioi-phan-trinh-dien-cua-13-dau-bep-quoc-te','Ẩm Thực Xèo - Tái Hiện Bánh Xèo Kỷ Lục Lớn Nhất Thế Giới ','Việt Nam , Bánh Xèo  lớn nhất','banhxeokyluc,banhxeolonnhatthegioi,banhxeo,amthucxeodanang,amthucxeo,dacsandanang','omdg6emn-am-thuc-xeo-tai-hien-hinh-anh-banh-xeo-lon-nhat-the-gioi-phan-trinh-dien-cua-13-dau-bep-quoc-te.jpg','0','<p><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">Ẩm Thực Xèo - Đặc sản Đà Nẵng ♥ Bấm đăng kí để theo dõi video mới nhất: </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/redirect?q=http%3A%2F%2Fbit.ly%2F2WvInxb&amp;v=euUkQRL0WDI&amp;event=video_description&amp;redir_token=aRfvnSkXUDnyS--atQduAQ4xFN98MTU2NzMxMzQ1MUAxNTY3MjI3MDUx\" rel=\"nofollow\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\" target=\"_blank\">http://bit.ly/2WvInxb</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> ♥ Facebook: </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/redirect?q=https%3A%2F%2Fwww.facebook.com%2Fxeo75&amp;v=euUkQRL0WDI&amp;event=video_description&amp;redir_token=aRfvnSkXUDnyS--atQduAQ4xFN98MTU2NzMxMzQ1MUAxNTY3MjI3MDUx\" rel=\"nofollow\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\" target=\"_blank\">https://www.facebook.com/xeo75</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> ♥ ♥ Website : </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/redirect?q=http%3A%2F%2Famthucxeo.com&amp;v=euUkQRL0WDI&amp;event=video_description&amp;redir_token=aRfvnSkXUDnyS--atQduAQ4xFN98MTU2NzMxMzQ1MUAxNTY3MjI3MDUx\" rel=\"nofollow\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\" target=\"_blank\">http://amthucxeo.com</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> ♥ ------------------------------------------------------------------------- Ẩm Thực Xèo - Tinh Hoa Ẩm Thực Việt Nam Lễ Hội Văn Hóa Ẩm Thực Quốc Tế 2019 tại Đà Nẵng - DIFF Ẩm Thực Xèo hân hạnh là nhà tài trợ vàng cho Lễ Hội Ẩm Thực Quốc Tế Đà Nẵng. Nằm trong chuỗi sự kiện DIFF ( Pháo Hoa Quốc Tế ) và DNIFF ( Lễ Hội Ẩm Thực Quốc Tế ) tại Đà Nẵng . Ẩm Thực Xèo tổ chức tái hiện lại hình ảnh bánh xèo kỷ lục guiness to nhất thế giới do 13 đầu bếp nổi tiếng quốc tế chung tay tạo nên .Qua sự kiện này Ẩm Thực Xèo mong muốn mang lại cho bạn bè quốc tế thấy được tinh hoa của ẩm thực miền trung Việt Nam . </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23AMTHUCXEODACSANDANANG\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#AMTHUCXEODACSANDANANG</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23LEHOIVANHOAAMTHUC\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#LEHOIVANHOAAMTHUC</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23DIFF2019\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#DIFF2019</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23DIFF\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#DIFF</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23AMTHUCXEO\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#AMTHUCXEO</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23DACSANDANANG\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#DACSANDANANG</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23LEHOIVANHOAAMTHUCQUOCTE\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#LEHOIVANHOAAMTHUCQUOCTE</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23BANHXEOGUINESS\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#BANHXEOGUINESS</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23BANHXEOKYLUC\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#BANHXEOKYLUC</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23DAUBEPQUOCTE\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#DAUBEPQUOCTE</a><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23banhxeokyluc\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#banhxeokyluc</a><span style=\"color: rgb(13, 13, 13); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\"> </span><a class=\"yt-simple-endpoint style-scope yt-formatted-string\" href=\"https://www.youtube.com/results?search_query=%23amthucxeodanang\" spellcheck=\"false\" style=\"display: inline-block; cursor: pointer; color: var(--yt-endpoint-visited-color, var(--yt-spec-call-to-action)); font-family: Roboto, Arial, sans-serif; text-align: start; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">#amthucxeodanang</a></p>\r\n','','https://www.youtube.com/watch?v=euUkQRL0WDI','1','0','4','1567227060','1568781898','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery_menu` (
  `gallery_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`gallery_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery_menu VALUES('98','91','Thư viện video','thu-vien-video','','','','0','1','','1','0','no','1552757386','1552757386','25');
INSERT INTO olala3w_gallery_menu VALUES('97','13','Slider banner','slider-banner','','','','0','1','','1','0','no','1552293963','1552293963','25');
INSERT INTO olala3w_gallery_menu VALUES('99','11','Thư viện hình ảnh','thu-vien-hinh-anh','','','','0','1','','1','0','no','1552758936','1552758936','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gift` (
  `gift_id` int(11) NOT NULL AUTO_INCREMENT,
  `gift_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT 0,
  `made` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`gift_id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gift_menu` (
  `gift_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`gift_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_link` (
  `link_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `category` int(11) NOT NULL DEFAULT 0,
  `menu` int(11) NOT NULL DEFAULT 0,
  `post` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=707 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_link VALUES('345','lien-he','0','0','0','0');
INSERT INTO olala3w_link VALUES('409','admin','0','0','0','0');
INSERT INTO olala3w_link VALUES('433','home','0','0','0','0');
INSERT INTO olala3w_link VALUES('498','olala','0','0','0','0');
INSERT INTO olala3w_link VALUES('499','gioi-thieu','9','0','0','1552020343');
INSERT INTO olala3w_link VALUES('500','am-thuc-xeo','9','479','0','1568690526');
INSERT INTO olala3w_link VALUES('501','tin-tuc','12','0','0','1552961321');
INSERT INTO olala3w_link VALUES('502','slider','13','0','0','1552293952');
INSERT INTO olala3w_link VALUES('503','slider-banner','13','97','0','1552293963');
INSERT INTO olala3w_link VALUES('506','hinh-anh','11','0','0','1552964740');
INSERT INTO olala3w_link VALUES('507','thuc-don','74','0','0','1555661540');
INSERT INTO olala3w_link VALUES('508','goi-tron','74','258','0','1552903437');
INSERT INTO olala3w_link VALUES('509','goi-cuon','74','259','0','1552547555');
INSERT INTO olala3w_link VALUES('510','nem-lui','13','97','683','1552791276');
INSERT INTO olala3w_link VALUES('511','banh-xeo-thit-bo','13','97','684','1552791242');
INSERT INTO olala3w_link VALUES('512','banh-xeo-thit-ga','13','97','685','1552791204');
INSERT INTO olala3w_link VALUES('513','banh-xeo-tom-hum','13','97','686','1552791311');
INSERT INTO olala3w_link VALUES('514','hanh-trinh-cua-tinh-hoa-am-thuc-viet','9','479','959','1568690253');
INSERT INTO olala3w_link VALUES('515','banh-xeo-tom-hum-rhf5ydksf3','74','258','675','1552529272');
INSERT INTO olala3w_link VALUES('516','banh-xeo-hai-san','74','258','676','1552535683');
INSERT INTO olala3w_link VALUES('517','coca','74','259','677','1552535695');
INSERT INTO olala3w_link VALUES('518','banh-cuon','74','260','0','1552547566');
INSERT INTO olala3w_link VALUES('519','banh-xeo','74','261','0','1552547571');
INSERT INTO olala3w_link VALUES('520','thuc-uong','74','262','0','1552547579');
INSERT INTO olala3w_link VALUES('521','goi-bo-bop-thau','74','258','678','1552547952');
INSERT INTO olala3w_link VALUES('522','goi-trai-va','74','258','679','1555472582');
INSERT INTO olala3w_link VALUES('523','goi-mit-non','74','258','680','1555472649');
INSERT INTO olala3w_link VALUES('524','goi-cung-dinh','74','258','681','1555472291');
INSERT INTO olala3w_link VALUES('525','goi-co-hu-dua','74','258','682','1557888260');
INSERT INTO olala3w_link VALUES('526','goi-rau-cang-cua','74','258','683','1555472854');
INSERT INTO olala3w_link VALUES('527','khoai-tay-chien-gion','74','258','684','1555473378');
INSERT INTO olala3w_link VALUES('528','goi-tom-hum','74','258','685','1555472070');
INSERT INTO olala3w_link VALUES('529','la-pho-cuon-thit-nuong','74','259','686','1568708087');
INSERT INTO olala3w_link VALUES('530','cha-gio-pho-mai','74','259','687','1555314455');
INSERT INTO olala3w_link VALUES('531','ram-tom','74','259','688','1568707689');
INSERT INTO olala3w_link VALUES('532','ram-cha-cua-be','74','259','689','1554693363');
INSERT INTO olala3w_link VALUES('533','ram-tom-hoa-tien','74','259','690','1555474202');
INSERT INTO olala3w_link VALUES('534','goi-cuon-thit-nuong','74','259','691','1568628937');
INSERT INTO olala3w_link VALUES('535','goi-cuon-tom-thit','74','259','692','1568628567');
INSERT INTO olala3w_link VALUES('536','goi-cuon-nem-nuong','74','259','693','1568628953');
INSERT INTO olala3w_link VALUES('537','tom-huu-tam-huu','74','259','694','1568628896');
INSERT INTO olala3w_link VALUES('538','ca-nuc-cuon','74','260','695','1568707914');
INSERT INTO olala3w_link VALUES('539','ca-hoa-rong','74','260','696','1555483857');
INSERT INTO olala3w_link VALUES('540','thit-nuong','74','260','697','1555483782');
INSERT INTO olala3w_link VALUES('541','nem-lui-am-thuc-xeo','74','260','698','1568646697');
INSERT INTO olala3w_link VALUES('542','thit-heo-dai-loc','74','260','699','1555315198');
INSERT INTO olala3w_link VALUES('543','thit-heo-thao-moc','74','260','700','1568628993');
INSERT INTO olala3w_link VALUES('544','banh-xeo-tom-thit','74','261','701','1555485351');
INSERT INTO olala3w_link VALUES('545','banh-xeo-tom-nhay','74','261','702','1555663648');
INSERT INTO olala3w_link VALUES('546','banh-xeo-thap-cam','74','261','703','1555485151');
INSERT INTO olala3w_link VALUES('547','banh-xeo-pho-mai-hai-san','74','261','704','1555485189');
INSERT INTO olala3w_link VALUES('548','banh-xeo-tom-hum-qw5q6e0gwy','74','261','705','1555485013');
INSERT INTO olala3w_link VALUES('549','tin-tuc-hoat-dong','12','480','0','1552751297');
INSERT INTO olala3w_link VALUES('550','banh-xeo-mien-trung','12','480','960','1568860781');
INSERT INTO olala3w_link VALUES('551','da-nang-xac-lap-ky-luc-banh-xeo-lon-nhat-vn','12','480','961','1568860743');
INSERT INTO olala3w_link VALUES('552','am-thuc-xeo-tri-an-khach-hang','12','480','962','1568860041');
INSERT INTO olala3w_link VALUES('553','video','91','0','0','1554969919');
INSERT INTO olala3w_link VALUES('554','thu-vien-video','91','98','0','1552757386');
INSERT INTO olala3w_link VALUES('555','thu-vien-hinh-anh','11','99','0','1552758936');
INSERT INTO olala3w_link VALUES('558','nhung-nguoi-ban-nghe-si','11','99','689','1567763779');
INSERT INTO olala3w_link VALUES('560','nuoc-khoang-thien-nhien-aquafina','74','262','706','1552963535');
INSERT INTO olala3w_link VALUES('561','cocacoca-pepsi','74','262','707','1552963547');
INSERT INTO olala3w_link VALUES('562','bia-heineken-lon','74','262','708','1552963248');
INSERT INTO olala3w_link VALUES('563','bia-tiger-cac-loai','74','262','709','1552963631');
INSERT INTO olala3w_link VALUES('564','khach-hang-cua-chung-toi','11','99','690','1567762711');
INSERT INTO olala3w_link VALUES('565','thuong-thuc-mon-ngon','11','99','691','1567763756');
INSERT INTO olala3w_link VALUES('566','trien-lam-hang-viet-da-nang','11','99','692','1567763734');
INSERT INTO olala3w_link VALUES('567','gio-dat-ban','14','1','0','1553006541');
INSERT INTO olala3w_link VALUES('568','9-00am','14','1','1','1553007321');
INSERT INTO olala3w_link VALUES('569','10-00am','14','1','2','1553007278');
INSERT INTO olala3w_link VALUES('570','11-00am','14','1','3','1553007327');
INSERT INTO olala3w_link VALUES('571','12-00am','14','1','4','1553007332');
INSERT INTO olala3w_link VALUES('572','1-00pm','14','1','5','1553007340');
INSERT INTO olala3w_link VALUES('573','2-00pm','14','1','6','1553007351');
INSERT INTO olala3w_link VALUES('574','4-00pm','14','1','7','1553007376');
INSERT INTO olala3w_link VALUES('575','5-00pm','14','1','8','1553007383');
INSERT INTO olala3w_link VALUES('576','6-00pm','14','1','9','1553007390');
INSERT INTO olala3w_link VALUES('577','7-00pm','14','1','10','1553007399');
INSERT INTO olala3w_link VALUES('578','8-00pm','14','1','11','1553007407');
INSERT INTO olala3w_link VALUES('579','9-00pm','14','1','12','1553007416');
INSERT INTO olala3w_link VALUES('580','search','0','0','0','0');
INSERT INTO olala3w_link VALUES('581','order','0','0','0','0');
INSERT INTO olala3w_link VALUES('582','banh-xeo-jl5zm118fc','91','98','693','1567764021');
INSERT INTO olala3w_link VALUES('583','banh-xeo-am-thuc-xeo','91','98','694','1567764012');
INSERT INTO olala3w_link VALUES('584','banh-xeo-75-hoang-van-thu-da-nang','91','98','695','1567764043');
INSERT INTO olala3w_link VALUES('585','dac-san-banh-xeo-da-nang','91','98','696','1567763998');
INSERT INTO olala3w_link VALUES('586','sinh-to-xoai','74','262','710','1554977834');
INSERT INTO olala3w_link VALUES('587','ca-phe-dua','74','262','711','1554972705');
INSERT INTO olala3w_link VALUES('588','ca-phe-sua-da','74','262','712','1568602829');
INSERT INTO olala3w_link VALUES('589','ca-phe-den-da','74','262','713','1554973447');
INSERT INTO olala3w_link VALUES('590','ruou-soju','74','262','714','1554973736');
INSERT INTO olala3w_link VALUES('591','ruou-nep-moi','74','262','715','1554973826');
INSERT INTO olala3w_link VALUES('592','ruou-vodka-men','74','262','716','1554974572');
INSERT INTO olala3w_link VALUES('593','bia-heneiken','74','262','717','1554975371');
INSERT INTO olala3w_link VALUES('594','bia-tiger','74','262','718','1554975464');
INSERT INTO olala3w_link VALUES('595','7-up','74','262','719','1554975543');
INSERT INTO olala3w_link VALUES('596','pepsi','74','262','720','1554975618');
INSERT INTO olala3w_link VALUES('597','coca-s7ye83ihcq','74','262','721','1554975730');
INSERT INTO olala3w_link VALUES('598','nuoc-suoi','74','262','722','1554975804');
INSERT INTO olala3w_link VALUES('599','nuoc-dua','74','262','723','1554975983');
INSERT INTO olala3w_link VALUES('600','soda-chanh-day','74','262','724','1568606011');
INSERT INTO olala3w_link VALUES('601','tra-tac-que','74','262','725','1554976609');
INSERT INTO olala3w_link VALUES('602','nuoc-chanh-tuoi','74','262','726','1554976758');
INSERT INTO olala3w_link VALUES('603','nuoc-ep-tao','74','262','727','1554976829');
INSERT INTO olala3w_link VALUES('604','nuoc-ep-thom','74','262','728','1554976942');
INSERT INTO olala3w_link VALUES('605','nuoc-ep-dua-hau','74','262','729','1554977709');
INSERT INTO olala3w_link VALUES('606','trang-mieng','74','263','0','1554978003');
INSERT INTO olala3w_link VALUES('607','kem-flan','74','263','730','1554978468');
INSERT INTO olala3w_link VALUES('608','rau-cau-dua','74','263','731','1554978459');
INSERT INTO olala3w_link VALUES('609','yaourt-xoai','74','263','732','1554978537');
INSERT INTO olala3w_link VALUES('610','yaourt','74','263','733','1554978607');
INSERT INTO olala3w_link VALUES('611','xoi-xoai','74','263','734','1554978671');
INSERT INTO olala3w_link VALUES('612','nguoi-mau-the-hinh-viet-nam-2019','11','99','697','1567763702');
INSERT INTO olala3w_link VALUES('613','goi-bap-chuoi','74','258','735','1557888410');
INSERT INTO olala3w_link VALUES('614','pho-luoi-lac','74','258','736','1555661990');
INSERT INTO olala3w_link VALUES('615','banh-xeo-tom-hum-size-700gr-con','74','261','737','1555484640');
INSERT INTO olala3w_link VALUES('616','bx-tom-hum-size-300gr-con','74','261','738','1555485053');
INSERT INTO olala3w_link VALUES('617','banh-xeo-muc','74','261','739','1555662967');
INSERT INTO olala3w_link VALUES('618','banh-xeo-hai-san-obes28d3qh','74','261','740','1555663254');
INSERT INTO olala3w_link VALUES('619','banh-xeo-thit-bo-rb5hzc3vrv','74','261','741','1555662884');
INSERT INTO olala3w_link VALUES('620','banh-xeo-thit-ga-am-thuc-xeo','74','261','742','1555663548');
INSERT INTO olala3w_link VALUES('621','banh-xeo-thit-vit','74','261','743','1555663454');
INSERT INTO olala3w_link VALUES('622','banh-xeo-nam','74','261','744','1555663353');
INSERT INTO olala3w_link VALUES('623','bun-my-pho','74','264','0','1555485857');
INSERT INTO olala3w_link VALUES('624','com','74','265','0','1555485874');
INSERT INTO olala3w_link VALUES('625','canh','74','266','0','1555485894');
INSERT INTO olala3w_link VALUES('626','bun-cha-thit-nuong','74','264','745','1555665601');
INSERT INTO olala3w_link VALUES('627','bun-thit-nuong','74','264','746','1555486553');
INSERT INTO olala3w_link VALUES('628','banh-hoi-thit-nuong','74','264','747','1563789502');
INSERT INTO olala3w_link VALUES('629','my-quang-tom-thit','74','264','748','1555487815');
INSERT INTO olala3w_link VALUES('630','my-quang-ga','74','264','749','1555488037');
INSERT INTO olala3w_link VALUES('631','my-quang-ca-loc','74','264','750','1555488126');
INSERT INTO olala3w_link VALUES('632','pho-ong-bay','74','264','751','1555665378');
INSERT INTO olala3w_link VALUES('633','pho-luoi-ap-chao','74','264','752','1555488751');
INSERT INTO olala3w_link VALUES('634','pho-luoi-chien-xu','74','264','753','1555665152');
INSERT INTO olala3w_link VALUES('635','pho-luoi-tom-thit','74','264','754','1555665048');
INSERT INTO olala3w_link VALUES('636','pho-luoi-ga','74','264','755','1555664967');
INSERT INTO olala3w_link VALUES('637','pho-luoi-ca-loc','74','264','756','1555491722');
INSERT INTO olala3w_link VALUES('638','pho-luoi-ca-nuc','74','264','757','1555491728');
INSERT INTO olala3w_link VALUES('639','com-chien-trung','74','265','758','1555748651');
INSERT INTO olala3w_link VALUES('640','com-chien-hai-san','74','265','759','1555491901');
INSERT INTO olala3w_link VALUES('641','com-ga-nep-cam','74','265','760','1555748808');
INSERT INTO olala3w_link VALUES('642','com-lam-thit-xiu','74','265','761','1555491994');
INSERT INTO olala3w_link VALUES('643','com-lam','74','265','762','1555748712');
INSERT INTO olala3w_link VALUES('644','com-trai-dua','74','265','763','1555748392');
INSERT INTO olala3w_link VALUES('645','com-trai-bi','74','265','764','1555748465');
INSERT INTO olala3w_link VALUES('646','com-trai-dua-am-thuc-xeo','74','265','765','1555492225');
INSERT INTO olala3w_link VALUES('647','canh-bo-ham-dau-hu','74','266','766','1555492334');
INSERT INTO olala3w_link VALUES('648','canh-rong-bien','74','266','767','1555492389');
INSERT INTO olala3w_link VALUES('649','canh-chua-ca-loc','74','266','768','1556363299');
INSERT INTO olala3w_link VALUES('650','canh-ga-la-giang','74','266','769','1556363231');
INSERT INTO olala3w_link VALUES('651','canh-cai-thit-bam','74','266','770','1555492593');
INSERT INTO olala3w_link VALUES('652','canh-tom-chua-cay','74','266','771','1555748982');
INSERT INTO olala3w_link VALUES('655','den-da-nang-dung-quen-ghe-am-thuc-xeo','12','480','964','1568860010');
INSERT INTO olala3w_link VALUES('656','kham-pha-mien-am-thuc-phong-phu-da-nang','12','480','965','1568859994');
INSERT INTO olala3w_link VALUES('657','miss-world','11','99','699','1557287118');
INSERT INTO olala3w_link VALUES('658','tra-cu-lao','74','262','772','1557738429');
INSERT INTO olala3w_link VALUES('659','tra-cu-lao-7ufrilc9s1','74','262','773','1557738516');
INSERT INTO olala3w_link VALUES('660','chanh-sa-tac','74','262','774','1568602610');
INSERT INTO olala3w_link VALUES('661','gioi-thieu-cac-mon-an-dan-da-xu-quang-den-voi-dau-bep-quoc-te','12','480','966','1568859882');
INSERT INTO olala3w_link VALUES('662','cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo','91','98','700','1567763983');
INSERT INTO olala3w_link VALUES('663','hinh-anh-cac-dau-bep-quoc-te-ghe-tham-am-thuc-xeo','11','99','701','1567763627');
INSERT INTO olala3w_link VALUES('667','am-thuc-xeo-mon-ngon-xu-quang-den-da-nang-phai-den-xeo','11','99','705','1567763584');
INSERT INTO olala3w_link VALUES('668','combo-mon-an-chieu-dai-dau-bep-quoc-te-tai-am-thuc-xeo-dniff-international-chef','11','99','706','1567763556');
INSERT INTO olala3w_link VALUES('669','le-hoi-am-thuc-quoc-te-dniff-tai-da-nang-am-thuc-xeo','12','480','967','1568859956');
INSERT INTO olala3w_link VALUES('670','su-kien-cac-dau-bep-quoc-te-giao-luu-lam-banh-xeo-viet-nam','12','480','968','1568859938');
INSERT INTO olala3w_link VALUES('671','chuong-trinh-giao-luu-cung-kols-tik-tok-viet-nam-tai-am-thuc-xeo','11','99','707','1567763474');
INSERT INTO olala3w_link VALUES('672','dia-diem','14','2','0','1560481220');
INSERT INTO olala3w_link VALUES('673','75-hoang-van-thu-da-nang','14','2','13','1560481227');
INSERT INTO olala3w_link VALUES('674','sieu-thi-lotte-mart-da-nang','14','2','14','1560481232');
INSERT INTO olala3w_link VALUES('675','19a-vo-van-kiet-da-nang','14','2','15','1560481238');
INSERT INTO olala3w_link VALUES('676','mot-ngay-lam-dau-bep-xu-quang-cung-am-thuc-xeo','12','480','969','1568859911');
INSERT INTO olala3w_link VALUES('677','am-thuc-xeo-trien-lam-thuong-mai-gian-hang-kinh-doanh-di-dong-pho-di-bo-cho-dem-bach-dang-quan-hai-chau-tp-da-nang','12','480','970','1568859902');
INSERT INTO olala3w_link VALUES('678','tripadvisor','0','0','0','0');
INSERT INTO olala3w_link VALUES('679','nem-lui-lon','74','260','775','1563788985');
INSERT INTO olala3w_link VALUES('680','chao-mung-doan-khach-den-tu-so-noi-vu-tp-da-nang','11','99','708','1567763444');
INSERT INTO olala3w_link VALUES('681','chao-don-cong-dong-brand-walkers-den-voi-am-thuc-xeo','91','98','709','1568781977');
INSERT INTO olala3w_link VALUES('682','am-thuc-xeo-tai-hien-hinh-anh-banh-xeo-lon-nhat-the-gioi-phan-trinh-dien-cua-13-dau-bep-quoc-te','91','98','710','1568781898');
INSERT INTO olala3w_link VALUES('683','bang-huu-tuong-giao-trao-nhau-tam-huu','13','97','711','1567847877');
INSERT INTO olala3w_link VALUES('684','combo-tinh-hoa-xu-quang-must-try','74','267','0','1568607814');
INSERT INTO olala3w_link VALUES('685','met-pho-san-que-son-lac-ngo-sen','74','267','776','1568603251');
INSERT INTO olala3w_link VALUES('686','tam-huu','74','267','777','1568603285');
INSERT INTO olala3w_link VALUES('687','non-banh-xeo','74','267','778','1568603353');
INSERT INTO olala3w_link VALUES('688','my-quang-tho','74','267','779','1568603408');
INSERT INTO olala3w_link VALUES('689','combo-long-chim-ngu-hanh','74','267','780','1568603497');
INSERT INTO olala3w_link VALUES('690','banh-xeo-thit-bo-2-cai','74','261','781','1568606071');
INSERT INTO olala3w_link VALUES('691','banh-xeo-tom-nhay-2-cai','74','261','782','1568607686');
INSERT INTO olala3w_link VALUES('692','banh-xeo-ga-2-cai','74','261','783','1568606108');
INSERT INTO olala3w_link VALUES('693','banh-xeo-thit-vit-2-cai','74','261','784','1568606146');
INSERT INTO olala3w_link VALUES('694','banh-xeo-nam-2-cai','74','261','785','1568606175');
INSERT INTO olala3w_link VALUES('695','ruou-tam-da-dinh-lang','74','262','786','1568607245');
INSERT INTO olala3w_link VALUES('696','ruou-tam-da-nep-cai-500-ml','74','262','787','1568607233');
INSERT INTO olala3w_link VALUES('697','soda-chanh-day-jlksacgwns','74','262','788','1568607284');
INSERT INTO olala3w_link VALUES('698','soda-dau','74','262','789','1568607639');
INSERT INTO olala3w_link VALUES('699','soda-blue-curacao','74','262','790','1568607660');
INSERT INTO olala3w_link VALUES('700','banh-xeo-tom-thit-90jgiy51wl','74','261','791','1568607736');
INSERT INTO olala3w_link VALUES('701','rau-cau-dua-jk5ol9gstg','74','267','792','1568607863');
INSERT INTO olala3w_link VALUES('702','banh-trang-cuon-thit-heo-thao-moc','74','267','793','1568607982');
INSERT INTO olala3w_link VALUES('703','tra-cu-lao-kk90bll5e3','74','267','794','1568608291');
INSERT INTO olala3w_link VALUES('704','combo','74','268','0','1568629436');
INSERT INTO olala3w_link VALUES('705','combo-kham-pha-319-000-2-nguoi','74','268','795','1568689704');
INSERT INTO olala3w_link VALUES('706','combo-no-say-499-000-3-nguoi','74','268','796','1568689691');

-- --------------------------------------------------------

CREATE TABLE `olala3w_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_location_menu` (
  `location_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_online` (
  `online_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `site` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`online_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51722 DEFAULT CHARSET=latin1;

INSERT INTO olala3w_online VALUES('51713','207.46.13.112','1568873391','url=soda-dau-88.html','Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)','0');
INSERT INTO olala3w_online VALUES('51714','66.249.73.72','1568872736','url=chemistry_153964335/lairage.expert','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','0');
INSERT INTO olala3w_online VALUES('51715','40.77.167.204','1568872816','url=public_html/Tag-55239993-photostate2a288einterface','Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)','0');
INSERT INTO olala3w_online VALUES('51716','171.251.28.2','1568873207','url=tripadvisor','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('51717','117.2.155.163','1568873302','url=tripadvisor&fbclid=IwAR01ccf6J82ziE4rWLImdarA_u2cg2F1NLq5lg3sxsnjI1PRnyVDA-xLBhE','Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','0');
INSERT INTO olala3w_online VALUES('51718','116.110.25.154','1568873566','url=img/loading.gif','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36','0');
INSERT INTO olala3w_online VALUES('51719','134.209.41.27','1568873541','url=bot/93fba2e7/Up-dating3.php&country.x=-&amp;ACCT.x=ID-PPL=PA324188.166.98.249=ScrPg=4d1e4b0c319902a5e9285c15b55a36493deaf67c0a4b03aa0774567cbc75f505S=$1$vS99j06/$PpPfCoQLdsCZ2m69z3dFt1CcjWLdSbgJiOT6tQVUGmsvnz4qMYDXBFPwuN7yKoH2hkEAlerpZ15R9afI3x80IEeOA','Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)','0');
INSERT INTO olala3w_online VALUES('51720','159.65.170.197','1568873541','url=bot/93fba2e7/Up-dating3.php&country.x=-&amp;ACCT.x=ID-PPL=PA324188.166.98.249=ScrPg=4d1e4b0c319902a5e9285c15b55a36493deaf67c0a4b03aa0774567cbc75f505S=$1$vS99j06/$PpPfCoQLdsCZ2m69z3dFt1CcjWLdSbgJiOT6tQVUGmsvnz4qMYDXBFPwuN7yKoH2hkEAlerpZ15R9afI3x80IEeOA','Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)','0');
INSERT INTO olala3w_online VALUES('51721','207.46.13.222','1568873698','url=09a47fe-95057699_gwyn_roofageroofage.college','Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_online_daily` (
  `online_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`online_daily_id`)
) ENGINE=MyISAM AUTO_INCREMENT=860 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_online_daily VALUES('1','2014-08-18','3');
INSERT INTO olala3w_online_daily VALUES('2','2014-08-17','1');
INSERT INTO olala3w_online_daily VALUES('3','2014-08-14','102');
INSERT INTO olala3w_online_daily VALUES('4','2014-08-06','100');
INSERT INTO olala3w_online_daily VALUES('5','2014-08-16','3');
INSERT INTO olala3w_online_daily VALUES('6','2014-08-13','10');
INSERT INTO olala3w_online_daily VALUES('7','2014-08-11','40');
INSERT INTO olala3w_online_daily VALUES('8','2014-08-09','90');
INSERT INTO olala3w_online_daily VALUES('9','2014-08-15','82');
INSERT INTO olala3w_online_daily VALUES('10','2014-08-12','207');
INSERT INTO olala3w_online_daily VALUES('11','2014-08-10','10');
INSERT INTO olala3w_online_daily VALUES('12','2014-08-08','7');
INSERT INTO olala3w_online_daily VALUES('13','2014-08-07','13');
INSERT INTO olala3w_online_daily VALUES('14','2014-08-19','13');
INSERT INTO olala3w_online_daily VALUES('15','2014-08-20','9');
INSERT INTO olala3w_online_daily VALUES('16','2014-08-21','135');
INSERT INTO olala3w_online_daily VALUES('17','2014-08-22','5');
INSERT INTO olala3w_online_daily VALUES('18','2014-09-27','7');
INSERT INTO olala3w_online_daily VALUES('19','2014-09-28','16');
INSERT INTO olala3w_online_daily VALUES('20','2014-09-29','5');
INSERT INTO olala3w_online_daily VALUES('21','2014-09-30','14');
INSERT INTO olala3w_online_daily VALUES('22','2014-10-01','16');
INSERT INTO olala3w_online_daily VALUES('23','2014-10-02','12');
INSERT INTO olala3w_online_daily VALUES('24','2014-10-03','7');
INSERT INTO olala3w_online_daily VALUES('25','2014-10-04','1');
INSERT INTO olala3w_online_daily VALUES('26','2014-10-05','2');
INSERT INTO olala3w_online_daily VALUES('27','2014-10-07','4');
INSERT INTO olala3w_online_daily VALUES('28','2014-10-08','11');
INSERT INTO olala3w_online_daily VALUES('29','2014-10-14','1');
INSERT INTO olala3w_online_daily VALUES('30','2014-10-20','1');
INSERT INTO olala3w_online_daily VALUES('31','2014-10-26','4');
INSERT INTO olala3w_online_daily VALUES('32','2014-10-27','9');
INSERT INTO olala3w_online_daily VALUES('33','2014-10-28','11');
INSERT INTO olala3w_online_daily VALUES('34','2014-10-29','13');
INSERT INTO olala3w_online_daily VALUES('35','2014-10-30','10');
INSERT INTO olala3w_online_daily VALUES('36','2014-10-31','14');
INSERT INTO olala3w_online_daily VALUES('37','2014-11-01','8');
INSERT INTO olala3w_online_daily VALUES('38','2014-11-02','12');
INSERT INTO olala3w_online_daily VALUES('39','2014-11-03','2');
INSERT INTO olala3w_online_daily VALUES('40','2014-11-05','4');
INSERT INTO olala3w_online_daily VALUES('41','2014-11-06','2');
INSERT INTO olala3w_online_daily VALUES('42','2014-11-07','4');
INSERT INTO olala3w_online_daily VALUES('43','2014-11-08','1');
INSERT INTO olala3w_online_daily VALUES('44','2014-11-09','1');
INSERT INTO olala3w_online_daily VALUES('45','2014-11-10','11');
INSERT INTO olala3w_online_daily VALUES('46','2014-11-11','8');
INSERT INTO olala3w_online_daily VALUES('47','2014-11-12','3');
INSERT INTO olala3w_online_daily VALUES('48','2014-11-13','5');
INSERT INTO olala3w_online_daily VALUES('49','2014-11-14','6');
INSERT INTO olala3w_online_daily VALUES('50','2014-11-15','1');
INSERT INTO olala3w_online_daily VALUES('51','2014-11-16','1');
INSERT INTO olala3w_online_daily VALUES('52','2014-11-17','4');
INSERT INTO olala3w_online_daily VALUES('53','2014-11-18','1');
INSERT INTO olala3w_online_daily VALUES('54','2014-11-19','4');
INSERT INTO olala3w_online_daily VALUES('55','2014-11-20','1');
INSERT INTO olala3w_online_daily VALUES('56','2014-11-21','4');
INSERT INTO olala3w_online_daily VALUES('57','2014-11-22','1');
INSERT INTO olala3w_online_daily VALUES('58','2014-11-23','16');
INSERT INTO olala3w_online_daily VALUES('59','2014-11-24','1');
INSERT INTO olala3w_online_daily VALUES('60','2014-11-25','5');
INSERT INTO olala3w_online_daily VALUES('61','2014-11-27','15');
INSERT INTO olala3w_online_daily VALUES('62','2014-11-28','18');
INSERT INTO olala3w_online_daily VALUES('63','2014-11-29','10');
INSERT INTO olala3w_online_daily VALUES('64','2014-11-30','10');
INSERT INTO olala3w_online_daily VALUES('65','2014-12-01','6');
INSERT INTO olala3w_online_daily VALUES('66','2014-12-02','13');
INSERT INTO olala3w_online_daily VALUES('67','2014-12-03','9');
INSERT INTO olala3w_online_daily VALUES('68','2014-12-04','9');
INSERT INTO olala3w_online_daily VALUES('69','2014-12-05','7');
INSERT INTO olala3w_online_daily VALUES('70','2014-12-06','1');
INSERT INTO olala3w_online_daily VALUES('71','2014-12-08','5');
INSERT INTO olala3w_online_daily VALUES('72','2014-12-09','2');
INSERT INTO olala3w_online_daily VALUES('73','2014-12-10','5');
INSERT INTO olala3w_online_daily VALUES('74','2014-12-11','13');
INSERT INTO olala3w_online_daily VALUES('75','2014-12-12','4');
INSERT INTO olala3w_online_daily VALUES('76','2014-12-16','2');
INSERT INTO olala3w_online_daily VALUES('77','2014-12-20','11');
INSERT INTO olala3w_online_daily VALUES('78','2014-12-21','6');
INSERT INTO olala3w_online_daily VALUES('79','2014-12-22','5');
INSERT INTO olala3w_online_daily VALUES('80','2014-12-23','3');
INSERT INTO olala3w_online_daily VALUES('81','2014-12-24','1');
INSERT INTO olala3w_online_daily VALUES('82','2014-12-26','2');
INSERT INTO olala3w_online_daily VALUES('83','2014-12-27','10');
INSERT INTO olala3w_online_daily VALUES('84','0000-00-00','1');
INSERT INTO olala3w_online_daily VALUES('85','2014-12-28','15');
INSERT INTO olala3w_online_daily VALUES('86','2014-12-29','11');
INSERT INTO olala3w_online_daily VALUES('87','2014-12-30','1');
INSERT INTO olala3w_online_daily VALUES('88','2015-01-02','11');
INSERT INTO olala3w_online_daily VALUES('89','2015-01-03','4');
INSERT INTO olala3w_online_daily VALUES('90','2015-01-04','2');
INSERT INTO olala3w_online_daily VALUES('91','2015-01-05','9');
INSERT INTO olala3w_online_daily VALUES('92','2015-01-06','7');
INSERT INTO olala3w_online_daily VALUES('93','2015-01-07','1');
INSERT INTO olala3w_online_daily VALUES('94','2015-01-08','7');
INSERT INTO olala3w_online_daily VALUES('95','2015-01-09','13');
INSERT INTO olala3w_online_daily VALUES('96','2015-01-10','2');
INSERT INTO olala3w_online_daily VALUES('97','2015-01-12','1');
INSERT INTO olala3w_online_daily VALUES('98','2015-01-19','2');
INSERT INTO olala3w_online_daily VALUES('99','2015-01-20','12');
INSERT INTO olala3w_online_daily VALUES('100','2015-01-21','8');
INSERT INTO olala3w_online_daily VALUES('101','2015-01-22','43');
INSERT INTO olala3w_online_daily VALUES('102','2015-01-23','36');
INSERT INTO olala3w_online_daily VALUES('103','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('104','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('105','2015-01-25','46');
INSERT INTO olala3w_online_daily VALUES('106','2015-01-26','51');
INSERT INTO olala3w_online_daily VALUES('107','2015-01-27','53');
INSERT INTO olala3w_online_daily VALUES('108','2015-01-28','46');
INSERT INTO olala3w_online_daily VALUES('109','2015-01-29','471');
INSERT INTO olala3w_online_daily VALUES('110','2015-01-30','191');
INSERT INTO olala3w_online_daily VALUES('111','2015-01-31','106');
INSERT INTO olala3w_online_daily VALUES('112','2015-02-01','61');
INSERT INTO olala3w_online_daily VALUES('113','2015-02-02','37');
INSERT INTO olala3w_online_daily VALUES('114','2015-02-03','53');
INSERT INTO olala3w_online_daily VALUES('115','2015-02-04','66');
INSERT INTO olala3w_online_daily VALUES('116','2015-02-05','63');
INSERT INTO olala3w_online_daily VALUES('117','2015-02-06','86');
INSERT INTO olala3w_online_daily VALUES('118','2015-02-07','63');
INSERT INTO olala3w_online_daily VALUES('119','2015-02-08','68');
INSERT INTO olala3w_online_daily VALUES('120','2015-02-09','64');
INSERT INTO olala3w_online_daily VALUES('121','2015-02-10','46');
INSERT INTO olala3w_online_daily VALUES('122','2015-02-11','53');
INSERT INTO olala3w_online_daily VALUES('123','2015-02-12','28');
INSERT INTO olala3w_online_daily VALUES('124','2015-02-13','155');
INSERT INTO olala3w_online_daily VALUES('125','2015-02-14','43');
INSERT INTO olala3w_online_daily VALUES('126','2015-02-15','27');
INSERT INTO olala3w_online_daily VALUES('127','2015-02-16','22');
INSERT INTO olala3w_online_daily VALUES('128','2015-02-17','20');
INSERT INTO olala3w_online_daily VALUES('129','2015-02-18','19');
INSERT INTO olala3w_online_daily VALUES('130','2015-02-19','16');
INSERT INTO olala3w_online_daily VALUES('131','2015-02-20','18');
INSERT INTO olala3w_online_daily VALUES('132','2015-02-21','33');
INSERT INTO olala3w_online_daily VALUES('133','2015-02-22','31');
INSERT INTO olala3w_online_daily VALUES('134','2015-02-23','34');
INSERT INTO olala3w_online_daily VALUES('135','2015-02-24','22');
INSERT INTO olala3w_online_daily VALUES('136','2015-02-25','26');
INSERT INTO olala3w_online_daily VALUES('137','2015-02-26','34');
INSERT INTO olala3w_online_daily VALUES('138','2015-02-27','19');
INSERT INTO olala3w_online_daily VALUES('139','2015-02-28','5');
INSERT INTO olala3w_online_daily VALUES('140','2015-03-01','12');
INSERT INTO olala3w_online_daily VALUES('141','2015-03-02','24');
INSERT INTO olala3w_online_daily VALUES('142','2015-03-03','48');
INSERT INTO olala3w_online_daily VALUES('143','2015-03-04','49');
INSERT INTO olala3w_online_daily VALUES('144','2015-03-05','43');
INSERT INTO olala3w_online_daily VALUES('145','2015-03-06','33');
INSERT INTO olala3w_online_daily VALUES('146','2015-03-07','52');
INSERT INTO olala3w_online_daily VALUES('147','2015-03-08','26');
INSERT INTO olala3w_online_daily VALUES('148','2015-03-09','46');
INSERT INTO olala3w_online_daily VALUES('149','2015-03-10','37');
INSERT INTO olala3w_online_daily VALUES('150','2015-03-11','47');
INSERT INTO olala3w_online_daily VALUES('151','2015-03-12','33');
INSERT INTO olala3w_online_daily VALUES('152','2015-03-13','28');
INSERT INTO olala3w_online_daily VALUES('153','2015-03-14','2');
INSERT INTO olala3w_online_daily VALUES('154','2015-03-16','5');
INSERT INTO olala3w_online_daily VALUES('155','2015-03-17','18');
INSERT INTO olala3w_online_daily VALUES('156','2015-03-18','11');
INSERT INTO olala3w_online_daily VALUES('157','2015-03-19','21');
INSERT INTO olala3w_online_daily VALUES('158','2015-03-20','18');
INSERT INTO olala3w_online_daily VALUES('159','2015-03-21','3');
INSERT INTO olala3w_online_daily VALUES('160','2015-05-06','5');
INSERT INTO olala3w_online_daily VALUES('161','2015-05-07','4');
INSERT INTO olala3w_online_daily VALUES('162','2015-05-08','3');
INSERT INTO olala3w_online_daily VALUES('163','2015-05-09','2');
INSERT INTO olala3w_online_daily VALUES('164','2015-05-10','8');
INSERT INTO olala3w_online_daily VALUES('165','2015-05-11','3');
INSERT INTO olala3w_online_daily VALUES('166','2015-05-12','4');
INSERT INTO olala3w_online_daily VALUES('167','2015-05-15','1');
INSERT INTO olala3w_online_daily VALUES('168','2015-05-16','2');
INSERT INTO olala3w_online_daily VALUES('169','2015-05-17','2');
INSERT INTO olala3w_online_daily VALUES('170','2015-05-18','1');
INSERT INTO olala3w_online_daily VALUES('171','2015-05-19','3');
INSERT INTO olala3w_online_daily VALUES('172','2015-05-23','1');
INSERT INTO olala3w_online_daily VALUES('173','2015-05-24','1');
INSERT INTO olala3w_online_daily VALUES('174','2015-05-25','2');
INSERT INTO olala3w_online_daily VALUES('175','2015-05-26','2');
INSERT INTO olala3w_online_daily VALUES('176','2015-05-27','4');
INSERT INTO olala3w_online_daily VALUES('177','2015-05-28','4');
INSERT INTO olala3w_online_daily VALUES('178','2015-05-29','3');
INSERT INTO olala3w_online_daily VALUES('179','2015-05-31','3');
INSERT INTO olala3w_online_daily VALUES('180','2015-06-01','1');
INSERT INTO olala3w_online_daily VALUES('181','2015-06-02','2');
INSERT INTO olala3w_online_daily VALUES('182','2015-06-03','3');
INSERT INTO olala3w_online_daily VALUES('183','2015-06-04','3');
INSERT INTO olala3w_online_daily VALUES('184','2015-06-05','1');
INSERT INTO olala3w_online_daily VALUES('185','2015-06-06','1');
INSERT INTO olala3w_online_daily VALUES('186','2015-06-08','1');
INSERT INTO olala3w_online_daily VALUES('187','2015-06-09','2');
INSERT INTO olala3w_online_daily VALUES('188','2015-06-10','1');
INSERT INTO olala3w_online_daily VALUES('189','2015-06-11','2');
INSERT INTO olala3w_online_daily VALUES('190','2015-06-12','3');
INSERT INTO olala3w_online_daily VALUES('191','2015-06-13','2');
INSERT INTO olala3w_online_daily VALUES('192','2015-06-14','1');
INSERT INTO olala3w_online_daily VALUES('193','2015-06-15','4');
INSERT INTO olala3w_online_daily VALUES('194','2015-06-16','1');
INSERT INTO olala3w_online_daily VALUES('195','2015-06-17','1');
INSERT INTO olala3w_online_daily VALUES('196','2015-06-18','1');
INSERT INTO olala3w_online_daily VALUES('197','2015-06-21','1');
INSERT INTO olala3w_online_daily VALUES('198','2015-06-22','3');
INSERT INTO olala3w_online_daily VALUES('199','2015-06-23','1');
INSERT INTO olala3w_online_daily VALUES('200','2015-06-24','8');
INSERT INTO olala3w_online_daily VALUES('201','2015-06-28','1');
INSERT INTO olala3w_online_daily VALUES('202','2015-06-29','3');
INSERT INTO olala3w_online_daily VALUES('203','2015-06-30','4');
INSERT INTO olala3w_online_daily VALUES('204','2015-07-01','4');
INSERT INTO olala3w_online_daily VALUES('205','2015-07-02','3');
INSERT INTO olala3w_online_daily VALUES('206','2015-07-03','3');
INSERT INTO olala3w_online_daily VALUES('207','2015-07-06','1');
INSERT INTO olala3w_online_daily VALUES('208','2015-07-07','1');
INSERT INTO olala3w_online_daily VALUES('209','2015-07-12','4');
INSERT INTO olala3w_online_daily VALUES('210','2015-07-13','6');
INSERT INTO olala3w_online_daily VALUES('211','2015-07-14','29');
INSERT INTO olala3w_online_daily VALUES('212','2015-07-15','190');
INSERT INTO olala3w_online_daily VALUES('213','2015-07-16','361');
INSERT INTO olala3w_online_daily VALUES('214','2015-07-17','354');
INSERT INTO olala3w_online_daily VALUES('215','2015-07-18','238');
INSERT INTO olala3w_online_daily VALUES('216','2015-07-19','343');
INSERT INTO olala3w_online_daily VALUES('217','2015-07-20','802');
INSERT INTO olala3w_online_daily VALUES('218','2015-07-21','1926');
INSERT INTO olala3w_online_daily VALUES('219','2015-07-22','1349');
INSERT INTO olala3w_online_daily VALUES('220','2015-07-23','1648');
INSERT INTO olala3w_online_daily VALUES('221','2015-07-24','2370');
INSERT INTO olala3w_online_daily VALUES('222','2015-07-25','4986');
INSERT INTO olala3w_online_daily VALUES('223','2015-07-26','2251');
INSERT INTO olala3w_online_daily VALUES('224','2015-07-27','3882');
INSERT INTO olala3w_online_daily VALUES('225','2015-07-28','3496');
INSERT INTO olala3w_online_daily VALUES('226','2015-07-29','3603');
INSERT INTO olala3w_online_daily VALUES('227','2015-07-30','2778');
INSERT INTO olala3w_online_daily VALUES('228','2015-07-31','5');
INSERT INTO olala3w_online_daily VALUES('229','2015-08-01','2');
INSERT INTO olala3w_online_daily VALUES('230','2015-08-02','3');
INSERT INTO olala3w_online_daily VALUES('231','2015-08-03','2');
INSERT INTO olala3w_online_daily VALUES('232','2015-08-05','5');
INSERT INTO olala3w_online_daily VALUES('233','2015-08-06','1');
INSERT INTO olala3w_online_daily VALUES('234','2015-08-07','5');
INSERT INTO olala3w_online_daily VALUES('235','2015-08-08','8');
INSERT INTO olala3w_online_daily VALUES('236','2015-08-09','7');
INSERT INTO olala3w_online_daily VALUES('237','2015-08-10','6');
INSERT INTO olala3w_online_daily VALUES('238','2015-08-11','1');
INSERT INTO olala3w_online_daily VALUES('239','2015-08-12','2');
INSERT INTO olala3w_online_daily VALUES('240','2015-08-13','3');
INSERT INTO olala3w_online_daily VALUES('241','2015-08-14','1');
INSERT INTO olala3w_online_daily VALUES('242','2015-08-16','2');
INSERT INTO olala3w_online_daily VALUES('243','2015-08-17','2');
INSERT INTO olala3w_online_daily VALUES('244','2015-08-18','1');
INSERT INTO olala3w_online_daily VALUES('245','2015-08-28','2');
INSERT INTO olala3w_online_daily VALUES('246','2015-08-29','1');
INSERT INTO olala3w_online_daily VALUES('247','2015-08-30','1');
INSERT INTO olala3w_online_daily VALUES('248','2015-08-31','3');
INSERT INTO olala3w_online_daily VALUES('249','2015-09-01','1');
INSERT INTO olala3w_online_daily VALUES('250','2015-09-04','1');
INSERT INTO olala3w_online_daily VALUES('251','2015-09-05','1');
INSERT INTO olala3w_online_daily VALUES('252','2015-09-06','1');
INSERT INTO olala3w_online_daily VALUES('253','2015-09-07','1');
INSERT INTO olala3w_online_daily VALUES('254','2015-09-08','1');
INSERT INTO olala3w_online_daily VALUES('255','2015-09-09','3');
INSERT INTO olala3w_online_daily VALUES('256','2015-09-10','3');
INSERT INTO olala3w_online_daily VALUES('257','2015-09-11','2');
INSERT INTO olala3w_online_daily VALUES('258','2015-09-17','1');
INSERT INTO olala3w_online_daily VALUES('259','2015-09-27','3');
INSERT INTO olala3w_online_daily VALUES('260','2015-09-28','2');
INSERT INTO olala3w_online_daily VALUES('261','2015-10-19','1');
INSERT INTO olala3w_online_daily VALUES('262','2015-10-20','4');
INSERT INTO olala3w_online_daily VALUES('263','2015-10-21','1');
INSERT INTO olala3w_online_daily VALUES('264','2015-10-24','1');
INSERT INTO olala3w_online_daily VALUES('265','2015-10-25','5');
INSERT INTO olala3w_online_daily VALUES('266','2015-10-26','22');
INSERT INTO olala3w_online_daily VALUES('267','2015-10-27','36');
INSERT INTO olala3w_online_daily VALUES('268','2015-11-10','1');
INSERT INTO olala3w_online_daily VALUES('269','2015-11-11','3');
INSERT INTO olala3w_online_daily VALUES('270','2015-11-12','22');
INSERT INTO olala3w_online_daily VALUES('271','2015-11-13','45');
INSERT INTO olala3w_online_daily VALUES('272','2015-11-14','9');
INSERT INTO olala3w_online_daily VALUES('273','2015-11-15','27');
INSERT INTO olala3w_online_daily VALUES('274','2015-11-16','36');
INSERT INTO olala3w_online_daily VALUES('275','2015-11-17','24');
INSERT INTO olala3w_online_daily VALUES('276','2015-11-18','10');
INSERT INTO olala3w_online_daily VALUES('277','2015-11-19','14');
INSERT INTO olala3w_online_daily VALUES('278','2015-11-20','7');
INSERT INTO olala3w_online_daily VALUES('279','2015-11-21','5');
INSERT INTO olala3w_online_daily VALUES('280','2015-11-22','1');
INSERT INTO olala3w_online_daily VALUES('281','2015-11-23','12');
INSERT INTO olala3w_online_daily VALUES('282','2015-11-24','5');
INSERT INTO olala3w_online_daily VALUES('283','2015-11-27','1');
INSERT INTO olala3w_online_daily VALUES('284','2015-11-28','2');
INSERT INTO olala3w_online_daily VALUES('285','2015-11-29','1');
INSERT INTO olala3w_online_daily VALUES('286','2015-11-30','4');
INSERT INTO olala3w_online_daily VALUES('287','2015-12-01','38');
INSERT INTO olala3w_online_daily VALUES('288','2015-12-02','34');
INSERT INTO olala3w_online_daily VALUES('289','2015-12-03','41');
INSERT INTO olala3w_online_daily VALUES('290','2015-12-04','34');
INSERT INTO olala3w_online_daily VALUES('291','2015-12-09','1');
INSERT INTO olala3w_online_daily VALUES('292','2015-12-19','1');
INSERT INTO olala3w_online_daily VALUES('293','2015-12-20','2');
INSERT INTO olala3w_online_daily VALUES('294','2015-12-21','7');
INSERT INTO olala3w_online_daily VALUES('295','2015-12-22','5');
INSERT INTO olala3w_online_daily VALUES('296','2015-12-23','52');
INSERT INTO olala3w_online_daily VALUES('297','2015-12-24','37');
INSERT INTO olala3w_online_daily VALUES('298','2015-12-25','39');
INSERT INTO olala3w_online_daily VALUES('299','2015-12-26','13');
INSERT INTO olala3w_online_daily VALUES('300','2015-12-27','2');
INSERT INTO olala3w_online_daily VALUES('301','2015-12-28','18');
INSERT INTO olala3w_online_daily VALUES('302','2015-12-29','9');
INSERT INTO olala3w_online_daily VALUES('303','2015-12-30','16');
INSERT INTO olala3w_online_daily VALUES('304','2015-12-31','6');
INSERT INTO olala3w_online_daily VALUES('305','2016-01-07','3');
INSERT INTO olala3w_online_daily VALUES('306','2016-01-08','3');
INSERT INTO olala3w_online_daily VALUES('307','2016-01-09','7');
INSERT INTO olala3w_online_daily VALUES('308','2016-01-10','1');
INSERT INTO olala3w_online_daily VALUES('309','2016-01-12','7');
INSERT INTO olala3w_online_daily VALUES('310','2016-01-13','4');
INSERT INTO olala3w_online_daily VALUES('311','2016-01-14','4');
INSERT INTO olala3w_online_daily VALUES('312','2016-01-15','14');
INSERT INTO olala3w_online_daily VALUES('313','2016-01-16','66');
INSERT INTO olala3w_online_daily VALUES('314','2016-01-17','45');
INSERT INTO olala3w_online_daily VALUES('315','2016-01-18','31');
INSERT INTO olala3w_online_daily VALUES('316','2016-01-19','7');
INSERT INTO olala3w_online_daily VALUES('317','2016-01-20','12');
INSERT INTO olala3w_online_daily VALUES('318','2016-01-21','5');
INSERT INTO olala3w_online_daily VALUES('319','2016-01-22','7');
INSERT INTO olala3w_online_daily VALUES('320','2016-01-23','4');
INSERT INTO olala3w_online_daily VALUES('321','2016-01-24','1');
INSERT INTO olala3w_online_daily VALUES('322','2016-01-25','25');
INSERT INTO olala3w_online_daily VALUES('323','2016-01-26','1');
INSERT INTO olala3w_online_daily VALUES('324','2016-01-27','11');
INSERT INTO olala3w_online_daily VALUES('325','2016-01-28','40');
INSERT INTO olala3w_online_daily VALUES('326','2016-01-29','35');
INSERT INTO olala3w_online_daily VALUES('327','2016-01-30','6');
INSERT INTO olala3w_online_daily VALUES('328','2016-02-01','14');
INSERT INTO olala3w_online_daily VALUES('329','2016-02-02','40');
INSERT INTO olala3w_online_daily VALUES('330','2016-02-03','163');
INSERT INTO olala3w_online_daily VALUES('331','2016-02-04','81');
INSERT INTO olala3w_online_daily VALUES('332','2016-02-05','63');
INSERT INTO olala3w_online_daily VALUES('333','2016-02-06','52');
INSERT INTO olala3w_online_daily VALUES('334','2016-02-07','38');
INSERT INTO olala3w_online_daily VALUES('335','2016-02-08','35');
INSERT INTO olala3w_online_daily VALUES('336','2016-02-09','48');
INSERT INTO olala3w_online_daily VALUES('337','2016-02-10','39');
INSERT INTO olala3w_online_daily VALUES('338','2016-02-11','34');
INSERT INTO olala3w_online_daily VALUES('339','2016-02-12','74');
INSERT INTO olala3w_online_daily VALUES('340','2016-02-13','56');
INSERT INTO olala3w_online_daily VALUES('341','2016-02-14','60');
INSERT INTO olala3w_online_daily VALUES('342','2016-02-15','104');
INSERT INTO olala3w_online_daily VALUES('343','2016-02-16','59');
INSERT INTO olala3w_online_daily VALUES('344','2016-02-17','58');
INSERT INTO olala3w_online_daily VALUES('345','2016-02-18','43');
INSERT INTO olala3w_online_daily VALUES('346','2016-02-19','2');
INSERT INTO olala3w_online_daily VALUES('347','2016-02-20','2');
INSERT INTO olala3w_online_daily VALUES('348','2016-02-22','3');
INSERT INTO olala3w_online_daily VALUES('349','2016-03-01','1');
INSERT INTO olala3w_online_daily VALUES('350','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('351','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('352','2016-03-07','1');
INSERT INTO olala3w_online_daily VALUES('353','2016-03-08','1');
INSERT INTO olala3w_online_daily VALUES('354','2016-03-09','14');
INSERT INTO olala3w_online_daily VALUES('355','2016-03-10','5');
INSERT INTO olala3w_online_daily VALUES('356','2016-03-11','6');
INSERT INTO olala3w_online_daily VALUES('357','2016-03-13','2');
INSERT INTO olala3w_online_daily VALUES('358','2016-03-14','1');
INSERT INTO olala3w_online_daily VALUES('359','2016-03-20','1');
INSERT INTO olala3w_online_daily VALUES('360','2016-03-26','8');
INSERT INTO olala3w_online_daily VALUES('361','2016-03-27','8');
INSERT INTO olala3w_online_daily VALUES('362','2016-03-28','46');
INSERT INTO olala3w_online_daily VALUES('363','2016-03-29','1');
INSERT INTO olala3w_online_daily VALUES('364','2016-03-30','11');
INSERT INTO olala3w_online_daily VALUES('365','2016-03-31','2');
INSERT INTO olala3w_online_daily VALUES('366','2016-04-02','1');
INSERT INTO olala3w_online_daily VALUES('367','2016-04-03','5');
INSERT INTO olala3w_online_daily VALUES('368','2016-04-04','10');
INSERT INTO olala3w_online_daily VALUES('369','2016-04-05','31');
INSERT INTO olala3w_online_daily VALUES('370','2016-04-06','65');
INSERT INTO olala3w_online_daily VALUES('371','2016-04-07','35');
INSERT INTO olala3w_online_daily VALUES('372','2016-04-08','15');
INSERT INTO olala3w_online_daily VALUES('373','2016-04-09','1');
INSERT INTO olala3w_online_daily VALUES('374','2016-04-20','2');
INSERT INTO olala3w_online_daily VALUES('375','2016-04-22','2');
INSERT INTO olala3w_online_daily VALUES('376','2016-04-23','7');
INSERT INTO olala3w_online_daily VALUES('377','2016-04-24','8');
INSERT INTO olala3w_online_daily VALUES('378','2016-04-25','1');
INSERT INTO olala3w_online_daily VALUES('379','2016-04-26','2');
INSERT INTO olala3w_online_daily VALUES('380','2016-04-27','4');
INSERT INTO olala3w_online_daily VALUES('381','2016-04-28','3');
INSERT INTO olala3w_online_daily VALUES('382','2016-05-05','1');
INSERT INTO olala3w_online_daily VALUES('383','2016-05-08','9');
INSERT INTO olala3w_online_daily VALUES('384','2016-05-09','3');
INSERT INTO olala3w_online_daily VALUES('385','2016-05-10','2');
INSERT INTO olala3w_online_daily VALUES('386','2016-05-11','5');
INSERT INTO olala3w_online_daily VALUES('387','2016-05-12','6');
INSERT INTO olala3w_online_daily VALUES('388','2016-05-13','11');
INSERT INTO olala3w_online_daily VALUES('389','2016-05-15','3');
INSERT INTO olala3w_online_daily VALUES('390','2016-05-16','8');
INSERT INTO olala3w_online_daily VALUES('391','2016-05-17','7');
INSERT INTO olala3w_online_daily VALUES('392','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('393','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('394','2016-05-20','2');
INSERT INTO olala3w_online_daily VALUES('395','2016-05-22','5');
INSERT INTO olala3w_online_daily VALUES('396','2016-05-23','1');
INSERT INTO olala3w_online_daily VALUES('397','2016-05-24','1');
INSERT INTO olala3w_online_daily VALUES('398','2016-05-30','5');
INSERT INTO olala3w_online_daily VALUES('399','2016-06-16','1');
INSERT INTO olala3w_online_daily VALUES('400','2016-06-24','5');
INSERT INTO olala3w_online_daily VALUES('401','2016-06-25','12');
INSERT INTO olala3w_online_daily VALUES('402','2016-06-26','5');
INSERT INTO olala3w_online_daily VALUES('403','2016-08-08','6');
INSERT INTO olala3w_online_daily VALUES('404','2016-08-09','4');
INSERT INTO olala3w_online_daily VALUES('405','2016-08-10','5');
INSERT INTO olala3w_online_daily VALUES('406','2016-08-11','2');
INSERT INTO olala3w_online_daily VALUES('407','2016-08-12','6');
INSERT INTO olala3w_online_daily VALUES('408','2016-08-14','1');
INSERT INTO olala3w_online_daily VALUES('409','2016-08-16','12');
INSERT INTO olala3w_online_daily VALUES('410','2016-08-17','39');
INSERT INTO olala3w_online_daily VALUES('411','2016-08-18','157');
INSERT INTO olala3w_online_daily VALUES('412','2016-08-19','196');
INSERT INTO olala3w_online_daily VALUES('413','2016-08-20','227');
INSERT INTO olala3w_online_daily VALUES('414','2016-08-21','190');
INSERT INTO olala3w_online_daily VALUES('415','2016-08-22','545');
INSERT INTO olala3w_online_daily VALUES('416','2016-08-23','367');
INSERT INTO olala3w_online_daily VALUES('417','2016-08-24','369');
INSERT INTO olala3w_online_daily VALUES('418','2016-08-25','418');
INSERT INTO olala3w_online_daily VALUES('419','2016-08-26','512');
INSERT INTO olala3w_online_daily VALUES('420','2016-08-27','614');
INSERT INTO olala3w_online_daily VALUES('421','2016-08-28','631');
INSERT INTO olala3w_online_daily VALUES('422','2016-08-29','728');
INSERT INTO olala3w_online_daily VALUES('423','2016-08-30','579');
INSERT INTO olala3w_online_daily VALUES('424','2016-08-31','333');
INSERT INTO olala3w_online_daily VALUES('425','2016-09-01','219');
INSERT INTO olala3w_online_daily VALUES('426','2016-09-02','108');
INSERT INTO olala3w_online_daily VALUES('427','2016-09-03','157');
INSERT INTO olala3w_online_daily VALUES('428','2016-09-04','156');
INSERT INTO olala3w_online_daily VALUES('429','2016-09-05','662');
INSERT INTO olala3w_online_daily VALUES('430','2016-09-06','744');
INSERT INTO olala3w_online_daily VALUES('431','2016-09-07','504');
INSERT INTO olala3w_online_daily VALUES('432','2016-09-08','571');
INSERT INTO olala3w_online_daily VALUES('433','2016-09-09','516');
INSERT INTO olala3w_online_daily VALUES('434','2016-09-10','484');
INSERT INTO olala3w_online_daily VALUES('435','2016-09-11','384');
INSERT INTO olala3w_online_daily VALUES('436','2016-09-12','332');
INSERT INTO olala3w_online_daily VALUES('437','2016-09-13','371');
INSERT INTO olala3w_online_daily VALUES('438','2016-09-14','338');
INSERT INTO olala3w_online_daily VALUES('439','2016-09-15','366');
INSERT INTO olala3w_online_daily VALUES('440','2016-09-16','536');
INSERT INTO olala3w_online_daily VALUES('441','2016-09-17','345');
INSERT INTO olala3w_online_daily VALUES('442','2016-09-18','363');
INSERT INTO olala3w_online_daily VALUES('443','2016-09-19','354');
INSERT INTO olala3w_online_daily VALUES('444','2016-09-20','359');
INSERT INTO olala3w_online_daily VALUES('445','2016-09-21','471');
INSERT INTO olala3w_online_daily VALUES('446','2016-09-22','405');
INSERT INTO olala3w_online_daily VALUES('447','2016-09-23','460');
INSERT INTO olala3w_online_daily VALUES('448','2016-09-24','461');
INSERT INTO olala3w_online_daily VALUES('449','2016-09-25','426');
INSERT INTO olala3w_online_daily VALUES('450','2016-09-26','432');
INSERT INTO olala3w_online_daily VALUES('451','2016-09-27','447');
INSERT INTO olala3w_online_daily VALUES('452','2016-09-28','324');
INSERT INTO olala3w_online_daily VALUES('453','2016-09-29','167');
INSERT INTO olala3w_online_daily VALUES('454','2016-09-30','265');
INSERT INTO olala3w_online_daily VALUES('455','2016-10-01','334');
INSERT INTO olala3w_online_daily VALUES('456','2016-10-02','272');
INSERT INTO olala3w_online_daily VALUES('457','2016-10-03','217');
INSERT INTO olala3w_online_daily VALUES('458','2016-10-04','214');
INSERT INTO olala3w_online_daily VALUES('459','2016-10-05','367');
INSERT INTO olala3w_online_daily VALUES('460','2016-10-06','462');
INSERT INTO olala3w_online_daily VALUES('461','2016-10-07','394');
INSERT INTO olala3w_online_daily VALUES('462','2016-10-08','321');
INSERT INTO olala3w_online_daily VALUES('463','2016-10-09','247');
INSERT INTO olala3w_online_daily VALUES('464','2016-10-10','268');
INSERT INTO olala3w_online_daily VALUES('465','2016-10-11','348');
INSERT INTO olala3w_online_daily VALUES('466','2016-10-12','471');
INSERT INTO olala3w_online_daily VALUES('467','2016-10-13','451');
INSERT INTO olala3w_online_daily VALUES('468','2016-10-14','502');
INSERT INTO olala3w_online_daily VALUES('469','2016-10-15','300');
INSERT INTO olala3w_online_daily VALUES('470','2016-10-16','228');
INSERT INTO olala3w_online_daily VALUES('471','2016-10-17','234');
INSERT INTO olala3w_online_daily VALUES('472','2016-10-18','272');
INSERT INTO olala3w_online_daily VALUES('473','2016-10-19','276');
INSERT INTO olala3w_online_daily VALUES('474','2016-10-20','366');
INSERT INTO olala3w_online_daily VALUES('475','2016-10-21','205');
INSERT INTO olala3w_online_daily VALUES('476','2016-10-22','228');
INSERT INTO olala3w_online_daily VALUES('477','2016-10-23','304');
INSERT INTO olala3w_online_daily VALUES('478','2016-10-24','286');
INSERT INTO olala3w_online_daily VALUES('479','2016-10-25','383');
INSERT INTO olala3w_online_daily VALUES('480','2016-10-26','338');
INSERT INTO olala3w_online_daily VALUES('481','2016-10-27','249');
INSERT INTO olala3w_online_daily VALUES('482','2016-10-28','295');
INSERT INTO olala3w_online_daily VALUES('483','2016-10-29','542');
INSERT INTO olala3w_online_daily VALUES('484','2016-10-30','468');
INSERT INTO olala3w_online_daily VALUES('485','2016-10-31','473');
INSERT INTO olala3w_online_daily VALUES('486','2016-11-01','300');
INSERT INTO olala3w_online_daily VALUES('487','2016-11-02','263');
INSERT INTO olala3w_online_daily VALUES('488','2016-11-03','369');
INSERT INTO olala3w_online_daily VALUES('489','2016-11-04','320');
INSERT INTO olala3w_online_daily VALUES('490','2016-11-05','202');
INSERT INTO olala3w_online_daily VALUES('491','2016-11-06','216');
INSERT INTO olala3w_online_daily VALUES('492','2016-11-07','243');
INSERT INTO olala3w_online_daily VALUES('493','2016-11-08','228');
INSERT INTO olala3w_online_daily VALUES('494','2016-11-09','200');
INSERT INTO olala3w_online_daily VALUES('495','2016-11-10','335');
INSERT INTO olala3w_online_daily VALUES('496','2016-11-11','189');
INSERT INTO olala3w_online_daily VALUES('497','2016-11-12','199');
INSERT INTO olala3w_online_daily VALUES('498','2016-11-13','476');
INSERT INTO olala3w_online_daily VALUES('499','2016-11-14','748');
INSERT INTO olala3w_online_daily VALUES('500','2016-11-15','384');
INSERT INTO olala3w_online_daily VALUES('501','2016-11-16','535');
INSERT INTO olala3w_online_daily VALUES('502','2016-11-17','669');
INSERT INTO olala3w_online_daily VALUES('503','2016-11-18','714');
INSERT INTO olala3w_online_daily VALUES('504','2016-11-19','778');
INSERT INTO olala3w_online_daily VALUES('505','2016-11-20','472');
INSERT INTO olala3w_online_daily VALUES('506','2016-11-21','339');
INSERT INTO olala3w_online_daily VALUES('507','2016-11-22','489');
INSERT INTO olala3w_online_daily VALUES('508','2016-11-23','283');
INSERT INTO olala3w_online_daily VALUES('509','2016-11-24','246');
INSERT INTO olala3w_online_daily VALUES('510','2016-11-25','276');
INSERT INTO olala3w_online_daily VALUES('511','2016-11-26','288');
INSERT INTO olala3w_online_daily VALUES('512','2016-11-27','268');
INSERT INTO olala3w_online_daily VALUES('513','2016-11-28','504');
INSERT INTO olala3w_online_daily VALUES('514','2016-11-29','478');
INSERT INTO olala3w_online_daily VALUES('515','2016-11-30','694');
INSERT INTO olala3w_online_daily VALUES('516','2016-12-01','524');
INSERT INTO olala3w_online_daily VALUES('517','2016-12-02','456');
INSERT INTO olala3w_online_daily VALUES('518','2016-12-03','450');
INSERT INTO olala3w_online_daily VALUES('519','2016-12-04','248');
INSERT INTO olala3w_online_daily VALUES('520','2016-12-05','99');
INSERT INTO olala3w_online_daily VALUES('521','2016-12-06','406');
INSERT INTO olala3w_online_daily VALUES('522','2016-12-07','508');
INSERT INTO olala3w_online_daily VALUES('523','2016-12-08','343');
INSERT INTO olala3w_online_daily VALUES('524','2016-12-09','452');
INSERT INTO olala3w_online_daily VALUES('525','2016-12-10','356');
INSERT INTO olala3w_online_daily VALUES('526','2016-12-11','415');
INSERT INTO olala3w_online_daily VALUES('527','2016-12-12','405');
INSERT INTO olala3w_online_daily VALUES('528','2016-12-13','260');
INSERT INTO olala3w_online_daily VALUES('529','2016-12-14','328');
INSERT INTO olala3w_online_daily VALUES('530','2016-12-15','697');
INSERT INTO olala3w_online_daily VALUES('531','2016-12-16','506');
INSERT INTO olala3w_online_daily VALUES('532','2016-12-17','388');
INSERT INTO olala3w_online_daily VALUES('533','2016-12-18','289');
INSERT INTO olala3w_online_daily VALUES('534','2016-12-19','312');
INSERT INTO olala3w_online_daily VALUES('535','2016-12-20','345');
INSERT INTO olala3w_online_daily VALUES('536','2016-12-21','349');
INSERT INTO olala3w_online_daily VALUES('537','2016-12-22','228');
INSERT INTO olala3w_online_daily VALUES('538','2016-12-23','374');
INSERT INTO olala3w_online_daily VALUES('539','2016-12-24','270');
INSERT INTO olala3w_online_daily VALUES('540','2016-12-25','201');
INSERT INTO olala3w_online_daily VALUES('541','2016-12-26','163');
INSERT INTO olala3w_online_daily VALUES('542','2016-12-27','178');
INSERT INTO olala3w_online_daily VALUES('543','2016-12-28','204');
INSERT INTO olala3w_online_daily VALUES('544','2016-12-29','244');
INSERT INTO olala3w_online_daily VALUES('545','2016-12-30','291');
INSERT INTO olala3w_online_daily VALUES('546','2016-12-31','535');
INSERT INTO olala3w_online_daily VALUES('547','2017-01-01','432');
INSERT INTO olala3w_online_daily VALUES('548','2017-01-02','383');
INSERT INTO olala3w_online_daily VALUES('549','2017-01-03','456');
INSERT INTO olala3w_online_daily VALUES('550','2017-01-04','324');
INSERT INTO olala3w_online_daily VALUES('551','2017-01-05','269');
INSERT INTO olala3w_online_daily VALUES('552','2017-01-06','117');
INSERT INTO olala3w_online_daily VALUES('553','2017-01-07','211');
INSERT INTO olala3w_online_daily VALUES('554','2017-01-08','282');
INSERT INTO olala3w_online_daily VALUES('555','2017-01-09','259');
INSERT INTO olala3w_online_daily VALUES('556','2017-01-10','270');
INSERT INTO olala3w_online_daily VALUES('557','2017-01-11','287');
INSERT INTO olala3w_online_daily VALUES('558','2017-01-12','287');
INSERT INTO olala3w_online_daily VALUES('559','2017-01-13','310');
INSERT INTO olala3w_online_daily VALUES('560','2017-01-14','96');
INSERT INTO olala3w_online_daily VALUES('561','2017-01-15','138');
INSERT INTO olala3w_online_daily VALUES('562','2017-01-16','173');
INSERT INTO olala3w_online_daily VALUES('563','2017-01-17','120');
INSERT INTO olala3w_online_daily VALUES('564','2017-01-18','206');
INSERT INTO olala3w_online_daily VALUES('565','2017-01-19','179');
INSERT INTO olala3w_online_daily VALUES('566','2017-01-20','136');
INSERT INTO olala3w_online_daily VALUES('567','2017-01-21','152');
INSERT INTO olala3w_online_daily VALUES('568','2017-01-22','257');
INSERT INTO olala3w_online_daily VALUES('569','2017-01-23','206');
INSERT INTO olala3w_online_daily VALUES('570','2017-01-24','226');
INSERT INTO olala3w_online_daily VALUES('571','2017-01-25','291');
INSERT INTO olala3w_online_daily VALUES('572','2017-01-26','154');
INSERT INTO olala3w_online_daily VALUES('573','2017-01-27','64');
INSERT INTO olala3w_online_daily VALUES('574','2017-01-28','118');
INSERT INTO olala3w_online_daily VALUES('575','2017-01-29','61');
INSERT INTO olala3w_online_daily VALUES('576','2017-01-30','89');
INSERT INTO olala3w_online_daily VALUES('577','2017-01-31','121');
INSERT INTO olala3w_online_daily VALUES('578','2017-02-01','98');
INSERT INTO olala3w_online_daily VALUES('579','2017-02-02','229');
INSERT INTO olala3w_online_daily VALUES('580','2017-02-03','310');
INSERT INTO olala3w_online_daily VALUES('581','2017-02-04','219');
INSERT INTO olala3w_online_daily VALUES('582','2017-02-05','254');
INSERT INTO olala3w_online_daily VALUES('583','2017-02-06','348');
INSERT INTO olala3w_online_daily VALUES('584','2017-02-07','279');
INSERT INTO olala3w_online_daily VALUES('585','2017-02-08','249');
INSERT INTO olala3w_online_daily VALUES('586','2017-02-09','215');
INSERT INTO olala3w_online_daily VALUES('587','2017-02-10','155');
INSERT INTO olala3w_online_daily VALUES('588','2017-02-11','140');
INSERT INTO olala3w_online_daily VALUES('589','2017-02-12','120');
INSERT INTO olala3w_online_daily VALUES('590','2017-02-13','154');
INSERT INTO olala3w_online_daily VALUES('591','2017-02-14','327');
INSERT INTO olala3w_online_daily VALUES('592','2017-02-15','314');
INSERT INTO olala3w_online_daily VALUES('593','2017-02-16','292');
INSERT INTO olala3w_online_daily VALUES('594','2017-02-17','183');
INSERT INTO olala3w_online_daily VALUES('595','2017-02-18','276');
INSERT INTO olala3w_online_daily VALUES('596','2017-02-19','211');
INSERT INTO olala3w_online_daily VALUES('597','2017-02-20','247');
INSERT INTO olala3w_online_daily VALUES('598','2017-02-21','141');
INSERT INTO olala3w_online_daily VALUES('599','2017-02-22','138');
INSERT INTO olala3w_online_daily VALUES('600','2017-02-23','166');
INSERT INTO olala3w_online_daily VALUES('601','2017-02-24','100');
INSERT INTO olala3w_online_daily VALUES('602','2017-02-25','175');
INSERT INTO olala3w_online_daily VALUES('603','2017-02-26','163');
INSERT INTO olala3w_online_daily VALUES('604','2017-02-27','6');
INSERT INTO olala3w_online_daily VALUES('605','2017-02-28','1');
INSERT INTO olala3w_online_daily VALUES('606','2017-03-01','3');
INSERT INTO olala3w_online_daily VALUES('607','2017-03-05','6');
INSERT INTO olala3w_online_daily VALUES('608','2017-03-06','1');
INSERT INTO olala3w_online_daily VALUES('609','2017-03-07','4');
INSERT INTO olala3w_online_daily VALUES('610','2017-03-08','97');
INSERT INTO olala3w_online_daily VALUES('611','2017-03-09','6');
INSERT INTO olala3w_online_daily VALUES('612','2017-03-10','1');
INSERT INTO olala3w_online_daily VALUES('613','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('614','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('615','2017-03-13','2');
INSERT INTO olala3w_online_daily VALUES('616','2017-03-14','2');
INSERT INTO olala3w_online_daily VALUES('617','2017-03-15','3');
INSERT INTO olala3w_online_daily VALUES('618','2017-03-20','3');
INSERT INTO olala3w_online_daily VALUES('619','2017-03-21','2');
INSERT INTO olala3w_online_daily VALUES('620','2017-04-16','1');
INSERT INTO olala3w_online_daily VALUES('621','2017-04-17','5');
INSERT INTO olala3w_online_daily VALUES('622','2017-04-21','3');
INSERT INTO olala3w_online_daily VALUES('623','2017-04-22','1');
INSERT INTO olala3w_online_daily VALUES('624','2017-04-26','1');
INSERT INTO olala3w_online_daily VALUES('625','2017-04-28','6');
INSERT INTO olala3w_online_daily VALUES('626','2017-04-29','3');
INSERT INTO olala3w_online_daily VALUES('627','2017-05-03','4');
INSERT INTO olala3w_online_daily VALUES('628','2017-05-04','2');
INSERT INTO olala3w_online_daily VALUES('629','2017-05-05','7');
INSERT INTO olala3w_online_daily VALUES('630','2017-05-07','9');
INSERT INTO olala3w_online_daily VALUES('631','2017-05-08','1');
INSERT INTO olala3w_online_daily VALUES('632','2017-05-09','6');
INSERT INTO olala3w_online_daily VALUES('633','2017-05-10','6');
INSERT INTO olala3w_online_daily VALUES('634','2017-05-12','1');
INSERT INTO olala3w_online_daily VALUES('635','2017-05-16','2');
INSERT INTO olala3w_online_daily VALUES('636','2017-05-17','11');
INSERT INTO olala3w_online_daily VALUES('637','2017-05-18','30');
INSERT INTO olala3w_online_daily VALUES('638','2017-05-19','10');
INSERT INTO olala3w_online_daily VALUES('639','2017-05-20','8');
INSERT INTO olala3w_online_daily VALUES('640','2017-05-21','20');
INSERT INTO olala3w_online_daily VALUES('641','2017-05-22','3');
INSERT INTO olala3w_online_daily VALUES('642','2017-05-23','3');
INSERT INTO olala3w_online_daily VALUES('0','2017-05-27','3');
INSERT INTO olala3w_online_daily VALUES('643','2017-05-28','2');
INSERT INTO olala3w_online_daily VALUES('644','2017-05-29','6');
INSERT INTO olala3w_online_daily VALUES('645','2017-05-30','2');
INSERT INTO olala3w_online_daily VALUES('646','2017-06-02','3');
INSERT INTO olala3w_online_daily VALUES('647','2017-06-03','4');
INSERT INTO olala3w_online_daily VALUES('648','2017-06-05','1');
INSERT INTO olala3w_online_daily VALUES('649','2017-06-06','3');
INSERT INTO olala3w_online_daily VALUES('650','2017-06-07','26');
INSERT INTO olala3w_online_daily VALUES('651','2017-06-08','20');
INSERT INTO olala3w_online_daily VALUES('652','2017-06-09','31');
INSERT INTO olala3w_online_daily VALUES('653','2017-06-10','9');
INSERT INTO olala3w_online_daily VALUES('654','2017-06-11','2');
INSERT INTO olala3w_online_daily VALUES('655','2017-06-12','14');
INSERT INTO olala3w_online_daily VALUES('656','2017-06-13','9');
INSERT INTO olala3w_online_daily VALUES('657','2017-06-14','13');
INSERT INTO olala3w_online_daily VALUES('658','2017-06-15','13');
INSERT INTO olala3w_online_daily VALUES('659','2017-06-16','28');
INSERT INTO olala3w_online_daily VALUES('660','2017-06-17','7');
INSERT INTO olala3w_online_daily VALUES('661','2017-06-19','16');
INSERT INTO olala3w_online_daily VALUES('662','2017-06-20','20');
INSERT INTO olala3w_online_daily VALUES('663','2017-06-21','12');
INSERT INTO olala3w_online_daily VALUES('664','2017-06-22','5');
INSERT INTO olala3w_online_daily VALUES('665','2017-06-29','1');
INSERT INTO olala3w_online_daily VALUES('666','2018-04-04','3');
INSERT INTO olala3w_online_daily VALUES('667','2018-04-05','4');
INSERT INTO olala3w_online_daily VALUES('668','2018-04-06','9');
INSERT INTO olala3w_online_daily VALUES('669','2018-04-07','6');
INSERT INTO olala3w_online_daily VALUES('670','2018-04-08','6');
INSERT INTO olala3w_online_daily VALUES('671','2018-04-09','2');
INSERT INTO olala3w_online_daily VALUES('672','2018-04-11','1');
INSERT INTO olala3w_online_daily VALUES('673','2018-04-12','2');
INSERT INTO olala3w_online_daily VALUES('674','2018-04-13','8');
INSERT INTO olala3w_online_daily VALUES('675','2018-04-14','11');
INSERT INTO olala3w_online_daily VALUES('676','2018-04-15','6');
INSERT INTO olala3w_online_daily VALUES('677','2018-04-16','3');
INSERT INTO olala3w_online_daily VALUES('678','2018-04-18','1');
INSERT INTO olala3w_online_daily VALUES('679','2018-04-23','3');
INSERT INTO olala3w_online_daily VALUES('680','2018-04-24','1');
INSERT INTO olala3w_online_daily VALUES('681','2018-04-28','2');
INSERT INTO olala3w_online_daily VALUES('682','2018-04-29','5');
INSERT INTO olala3w_online_daily VALUES('683','2018-04-30','2');
INSERT INTO olala3w_online_daily VALUES('684','2019-03-08','5');
INSERT INTO olala3w_online_daily VALUES('685','2019-03-11','1');
INSERT INTO olala3w_online_daily VALUES('686','2019-03-12','9');
INSERT INTO olala3w_online_daily VALUES('687','2019-03-13','3');
INSERT INTO olala3w_online_daily VALUES('688','2019-03-14','5');
INSERT INTO olala3w_online_daily VALUES('689','2019-03-15','3');
INSERT INTO olala3w_online_daily VALUES('690','2019-03-16','7');
INSERT INTO olala3w_online_daily VALUES('691','2019-03-17','3');
INSERT INTO olala3w_online_daily VALUES('692','2019-03-18','7');
INSERT INTO olala3w_online_daily VALUES('693','2019-03-19','3');
INSERT INTO olala3w_online_daily VALUES('694','2019-03-20','23');
INSERT INTO olala3w_online_daily VALUES('695','2019-03-21','3');
INSERT INTO olala3w_online_daily VALUES('696','2019-03-22','1');
INSERT INTO olala3w_online_daily VALUES('697','2019-03-25','7');
INSERT INTO olala3w_online_daily VALUES('698','2019-03-29','1');
INSERT INTO olala3w_online_daily VALUES('699','2019-03-31','10');
INSERT INTO olala3w_online_daily VALUES('700','2019-04-01','1');
INSERT INTO olala3w_online_daily VALUES('701','2019-04-03','11');
INSERT INTO olala3w_online_daily VALUES('702','2019-04-04','2');
INSERT INTO olala3w_online_daily VALUES('703','2019-04-05','10');
INSERT INTO olala3w_online_daily VALUES('704','2019-04-08','11');
INSERT INTO olala3w_online_daily VALUES('705','2019-04-11','10');
INSERT INTO olala3w_online_daily VALUES('706','2019-04-12','14');
INSERT INTO olala3w_online_daily VALUES('707','2019-04-15','9');
INSERT INTO olala3w_online_daily VALUES('708','2019-04-16','7');
INSERT INTO olala3w_online_daily VALUES('709','2019-04-17','12');
INSERT INTO olala3w_online_daily VALUES('710','2019-04-19','8');
INSERT INTO olala3w_online_daily VALUES('711','2019-04-20','4');
INSERT INTO olala3w_online_daily VALUES('712','2019-04-24','11');
INSERT INTO olala3w_online_daily VALUES('713','2019-04-25','2');
INSERT INTO olala3w_online_daily VALUES('714','2019-04-26','2');
INSERT INTO olala3w_online_daily VALUES('715','2019-04-27','6');
INSERT INTO olala3w_online_daily VALUES('716','2019-04-28','2');
INSERT INTO olala3w_online_daily VALUES('717','2019-04-30','1');
INSERT INTO olala3w_online_daily VALUES('718','2019-05-01','7');
INSERT INTO olala3w_online_daily VALUES('719','2019-05-02','8');
INSERT INTO olala3w_online_daily VALUES('720','2019-05-03','4');
INSERT INTO olala3w_online_daily VALUES('721','2019-05-04','2');
INSERT INTO olala3w_online_daily VALUES('722','2019-05-05','1');
INSERT INTO olala3w_online_daily VALUES('723','2019-05-06','6');
INSERT INTO olala3w_online_daily VALUES('724','2019-05-07','12');
INSERT INTO olala3w_online_daily VALUES('725','2019-05-08','13');
INSERT INTO olala3w_online_daily VALUES('726','2019-05-09','254');
INSERT INTO olala3w_online_daily VALUES('727','2019-05-10','408');
INSERT INTO olala3w_online_daily VALUES('728','2019-05-11','389');
INSERT INTO olala3w_online_daily VALUES('729','2019-05-12','426');
INSERT INTO olala3w_online_daily VALUES('730','2019-05-13','319');
INSERT INTO olala3w_online_daily VALUES('731','2019-05-14','351');
INSERT INTO olala3w_online_daily VALUES('732','2019-05-15','324');
INSERT INTO olala3w_online_daily VALUES('733','2019-05-16','433');
INSERT INTO olala3w_online_daily VALUES('734','2019-05-17','444');
INSERT INTO olala3w_online_daily VALUES('735','2019-05-18','415');
INSERT INTO olala3w_online_daily VALUES('736','2019-05-19','435');
INSERT INTO olala3w_online_daily VALUES('737','2019-05-20','400');
INSERT INTO olala3w_online_daily VALUES('738','2019-05-21','391');
INSERT INTO olala3w_online_daily VALUES('739','2019-05-22','380');
INSERT INTO olala3w_online_daily VALUES('740','2019-05-23','431');
INSERT INTO olala3w_online_daily VALUES('741','2019-05-24','493');
INSERT INTO olala3w_online_daily VALUES('742','2019-05-25','421');
INSERT INTO olala3w_online_daily VALUES('743','2019-05-26','386');
INSERT INTO olala3w_online_daily VALUES('744','2019-05-27','401');
INSERT INTO olala3w_online_daily VALUES('745','2019-05-28','449');
INSERT INTO olala3w_online_daily VALUES('746','2019-05-29','512');
INSERT INTO olala3w_online_daily VALUES('747','2019-05-30','451');
INSERT INTO olala3w_online_daily VALUES('748','2019-05-31','407');
INSERT INTO olala3w_online_daily VALUES('749','2019-06-01','459');
INSERT INTO olala3w_online_daily VALUES('750','2019-06-02','548');
INSERT INTO olala3w_online_daily VALUES('751','2019-06-03','447');
INSERT INTO olala3w_online_daily VALUES('752','2019-06-04','489');
INSERT INTO olala3w_online_daily VALUES('753','2019-06-05','869');
INSERT INTO olala3w_online_daily VALUES('754','2019-06-06','601');
INSERT INTO olala3w_online_daily VALUES('755','2019-06-07','654');
INSERT INTO olala3w_online_daily VALUES('756','2019-06-08','2969');
INSERT INTO olala3w_online_daily VALUES('757','2019-06-09','2923');
INSERT INTO olala3w_online_daily VALUES('758','2019-06-10','2703');
INSERT INTO olala3w_online_daily VALUES('759','2019-06-11','2227');
INSERT INTO olala3w_online_daily VALUES('760','2019-06-12','269');
INSERT INTO olala3w_online_daily VALUES('761','2019-06-13','2342');
INSERT INTO olala3w_online_daily VALUES('762','2019-06-14','1190');
INSERT INTO olala3w_online_daily VALUES('763','2019-06-15','1222');
INSERT INTO olala3w_online_daily VALUES('764','2019-06-16','1114');
INSERT INTO olala3w_online_daily VALUES('765','2019-06-17','1106');
INSERT INTO olala3w_online_daily VALUES('766','2019-06-18','1180');
INSERT INTO olala3w_online_daily VALUES('767','2019-06-19','1128');
INSERT INTO olala3w_online_daily VALUES('768','2019-06-20','1100');
INSERT INTO olala3w_online_daily VALUES('769','2019-06-21','1001');
INSERT INTO olala3w_online_daily VALUES('770','2019-06-22','1061');
INSERT INTO olala3w_online_daily VALUES('771','2019-06-23','1109');
INSERT INTO olala3w_online_daily VALUES('772','2019-06-24','1076');
INSERT INTO olala3w_online_daily VALUES('773','2019-06-25','1134');
INSERT INTO olala3w_online_daily VALUES('774','2019-06-26','1037');
INSERT INTO olala3w_online_daily VALUES('775','2019-06-27','1044');
INSERT INTO olala3w_online_daily VALUES('776','2019-06-28','977');
INSERT INTO olala3w_online_daily VALUES('777','2019-06-29','572');
INSERT INTO olala3w_online_daily VALUES('778','2019-06-30','535');
INSERT INTO olala3w_online_daily VALUES('779','2019-07-01','571');
INSERT INTO olala3w_online_daily VALUES('780','2019-07-02','602');
INSERT INTO olala3w_online_daily VALUES('781','2019-07-03','633');
INSERT INTO olala3w_online_daily VALUES('782','2019-07-04','566');
INSERT INTO olala3w_online_daily VALUES('783','2019-07-05','527');
INSERT INTO olala3w_online_daily VALUES('784','2019-07-06','515');
INSERT INTO olala3w_online_daily VALUES('785','2019-07-07','524');
INSERT INTO olala3w_online_daily VALUES('786','2019-07-08','523');
INSERT INTO olala3w_online_daily VALUES('787','2019-07-09','548');
INSERT INTO olala3w_online_daily VALUES('788','2019-07-10','498');
INSERT INTO olala3w_online_daily VALUES('789','2019-07-11','489');
INSERT INTO olala3w_online_daily VALUES('790','2019-07-12','531');
INSERT INTO olala3w_online_daily VALUES('791','2019-07-13','617');
INSERT INTO olala3w_online_daily VALUES('792','2019-07-14','562');
INSERT INTO olala3w_online_daily VALUES('793','2019-07-15','569');
INSERT INTO olala3w_online_daily VALUES('794','2019-07-16','594');
INSERT INTO olala3w_online_daily VALUES('795','2019-07-17','528');
INSERT INTO olala3w_online_daily VALUES('796','2019-07-18','437');
INSERT INTO olala3w_online_daily VALUES('797','2019-07-19','415');
INSERT INTO olala3w_online_daily VALUES('798','2019-07-20','458');
INSERT INTO olala3w_online_daily VALUES('799','2019-07-21','435');
INSERT INTO olala3w_online_daily VALUES('800','2019-07-22','468');
INSERT INTO olala3w_online_daily VALUES('801','2019-07-23','448');
INSERT INTO olala3w_online_daily VALUES('802','2019-07-24','333');
INSERT INTO olala3w_online_daily VALUES('803','2019-07-25','409');
INSERT INTO olala3w_online_daily VALUES('804','2019-07-26','393');
INSERT INTO olala3w_online_daily VALUES('805','2019-07-27','353');
INSERT INTO olala3w_online_daily VALUES('806','2019-07-28','371');
INSERT INTO olala3w_online_daily VALUES('807','2019-07-29','377');
INSERT INTO olala3w_online_daily VALUES('808','2019-07-30','371');
INSERT INTO olala3w_online_daily VALUES('809','2019-07-31','368');
INSERT INTO olala3w_online_daily VALUES('810','2019-08-01','376');
INSERT INTO olala3w_online_daily VALUES('811','2019-08-02','362');
INSERT INTO olala3w_online_daily VALUES('812','2019-08-03','386');
INSERT INTO olala3w_online_daily VALUES('813','2019-08-04','344');
INSERT INTO olala3w_online_daily VALUES('814','2019-08-05','327');
INSERT INTO olala3w_online_daily VALUES('815','2019-08-06','357');
INSERT INTO olala3w_online_daily VALUES('816','2019-08-07','354');
INSERT INTO olala3w_online_daily VALUES('817','2019-08-08','357');
INSERT INTO olala3w_online_daily VALUES('818','2019-08-09','359');
INSERT INTO olala3w_online_daily VALUES('819','2019-08-10','352');
INSERT INTO olala3w_online_daily VALUES('820','2019-08-11','381');
INSERT INTO olala3w_online_daily VALUES('821','2019-08-12','372');
INSERT INTO olala3w_online_daily VALUES('822','2019-08-13','374');
INSERT INTO olala3w_online_daily VALUES('823','2019-08-14','337');
INSERT INTO olala3w_online_daily VALUES('824','2019-08-15','356');
INSERT INTO olala3w_online_daily VALUES('825','2019-08-16','305');
INSERT INTO olala3w_online_daily VALUES('826','2019-08-17','346');
INSERT INTO olala3w_online_daily VALUES('827','2019-08-18','346');
INSERT INTO olala3w_online_daily VALUES('828','2019-08-19','317');
INSERT INTO olala3w_online_daily VALUES('829','2019-08-20','327');
INSERT INTO olala3w_online_daily VALUES('830','2019-08-21','331');
INSERT INTO olala3w_online_daily VALUES('831','2019-08-22','327');
INSERT INTO olala3w_online_daily VALUES('832','2019-08-23','371');
INSERT INTO olala3w_online_daily VALUES('833','2019-08-24','341');
INSERT INTO olala3w_online_daily VALUES('834','2019-08-25','320');
INSERT INTO olala3w_online_daily VALUES('835','2019-08-26','288');
INSERT INTO olala3w_online_daily VALUES('836','2019-08-27','298');
INSERT INTO olala3w_online_daily VALUES('837','2019-08-28','297');
INSERT INTO olala3w_online_daily VALUES('838','2019-08-29','264');
INSERT INTO olala3w_online_daily VALUES('839','2019-08-30','278');
INSERT INTO olala3w_online_daily VALUES('840','2019-08-31','265');
INSERT INTO olala3w_online_daily VALUES('841','2019-09-01','322');
INSERT INTO olala3w_online_daily VALUES('842','2019-09-02','274');
INSERT INTO olala3w_online_daily VALUES('843','2019-09-03','239');
INSERT INTO olala3w_online_daily VALUES('844','2019-09-04','257');
INSERT INTO olala3w_online_daily VALUES('845','2019-09-05','272');
INSERT INTO olala3w_online_daily VALUES('846','2019-09-06','296');
INSERT INTO olala3w_online_daily VALUES('847','2019-09-07','261');
INSERT INTO olala3w_online_daily VALUES('848','2019-09-08','269');
INSERT INTO olala3w_online_daily VALUES('849','2019-09-09','288');
INSERT INTO olala3w_online_daily VALUES('850','2019-09-10','235');
INSERT INTO olala3w_online_daily VALUES('851','2019-09-11','345');
INSERT INTO olala3w_online_daily VALUES('852','2019-09-12','290');
INSERT INTO olala3w_online_daily VALUES('853','2019-09-13','277');
INSERT INTO olala3w_online_daily VALUES('854','2019-09-14','324');
INSERT INTO olala3w_online_daily VALUES('855','2019-09-15','297');
INSERT INTO olala3w_online_daily VALUES('856','2019-09-16','298');
INSERT INTO olala3w_online_daily VALUES('857','2019-09-17','321');
INSERT INTO olala3w_online_daily VALUES('858','2019-09-18','276');
INSERT INTO olala3w_online_daily VALUES('859','2019-09-19','158');

-- --------------------------------------------------------

CREATE TABLE `olala3w_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-shopping-cart',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_order VALUES('7','Kỹ thuật OlalaWeb','0905665695','thinh.tran@olalagroup.vn','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"https://amthucxeo.com\" target=\"_blank\"><img src=\"https://amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ẩm Thực Xèo\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Kỹ thuật OlalaWeb</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Kỹ thuật OlalaWeb<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> thinh.tran@olalagroup.vn<br/><label style=\"font-weight:600;padding-left:12px;\">Điện thoại: </label> 0905665695<br/><label style=\"font-weight:600;padding-left:12px;\">Số người: </label> 15<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đến: </label> 25/05/2019<br/><label style=\"font-weight:600;padding-left:12px;\">Thời gian: </label> 4:00pm<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đặt: </label> 23/05/2019 15:16<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 116.110.122.73<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;\">Ẩm Thực Xèo</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','116.110.122.73','fa-globe','1558599368','1559987282');
INSERT INTO olala3w_order VALUES('8','김혜연','821042209971','kchocou@naver.com','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"https://amthucxeo.com\" target=\"_blank\"><img src=\"https://amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ẩm Thực Xèo\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> 김혜연</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> 김혜연<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> kchocou@naver.com<br/><label style=\"font-weight:600;padding-left:12px;\">Điện thoại: </label> 821042209971<br/><label style=\"font-weight:600;padding-left:12px;\">Số người: </label> 13명<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đến: </label> 21/06/2019<br/><label style=\"font-weight:600;padding-left:12px;\">Thời gian: </label> 5:00pm<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đặt: </label> 11/06/2019 12:25<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 218.48.16.238<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;\">Ẩm Thực Xèo</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','218.48.16.238','fa-globe','1560230726','1560330369');
INSERT INTO olala3w_order VALUES('9','Kiểm thử chức năng mới','0905665695','tranhuuthinh555@gmail.com','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"https://amthucxeo.com\" target=\"_blank\"><img src=\"https://amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ẩm Thực Xèo\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Kiểm thử chức năng mới</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Kiểm thử chức năng mới<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> tranhuuthinh555@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Điện thoại: </label> 0905665695<br/><label style=\"font-weight:600;padding-left:12px;\">Số người: </label> 02<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đến: </label> 14/06/2019<br/><label style=\"font-weight:600;padding-left:12px;\">Thời gian: </label> 6:00pm<br/><label style=\"font-weight:600;padding-left:12px;\">Địa điểm: </label> 75 Hoàng Văn Thụ - Đà Nẵng<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đặt: </label> 14/06/2019 10:32<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 116.110.214.244<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;\">Ẩm Thực Xèo</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','116.110.214.244','fa-globe','1560483137','1560590439');
INSERT INTO olala3w_order VALUES('10','Hoàng Lê Lợi','0901706770','hoangloi26985@gmail.com','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"https://amthucxeo.com\" target=\"_blank\"><img src=\"https://amthucxeo.com/uploads/files/logo-am-thuc-xeo.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ẩm Thực Xèo\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Hoàng Lê Lợi</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Hoàng Lê Lợi<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> hoangloi26985@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Điện thoại: </label> 0901706770<br/><label style=\"font-weight:600;padding-left:12px;\">Số người: </label> 10<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đến: </label> 14/07/2019<br/><label style=\"font-weight:600;padding-left:12px;\">Thời gian: </label> 2:00pm<br/><label style=\"font-weight:600;padding-left:12px;\">Địa điểm: </label> 19A Võ Văn Kiệt - Đà Nẵng<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đặt: </label> 14/07/2019 12:21<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 59.153.242.195<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;\">Ẩm Thực Xèo</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','59.153.242.195','fa-globe','1563081691','1563348638');
INSERT INTO olala3w_order VALUES('11','Trần Phan Hoài Thanh','0932430191','tranhoaithanh94@gmail.com','<div marginwidth=\"0\" marginheight=\"0\" style=\"font-family:Arial,serif;\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"table-layout:fixed;\"><tbody><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#f5f5f5\" style=\"padding:0;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;width:100%;\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:10px 0; text-align: center;\"><a href=\"https://amthucxeo.com\" target=\"_blank\"><img src=\"https://amthucxeo.com/uploads/files/hinnh%20logo%20fix.png\" style=\"max-height:70px;max-width:80%;\" alt=\"Ẩm Thực Xèo\" border=\"0\"></a></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"min-width:290px;margin:0 auto;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;\" width=\"620\"><tbody><tr><td style=\"border-left:6px solid #dfdfdf;font-size:13px;color:#666666;font-weight:normal;text-align:left;font-family:Arial,serif;line-height:18px;vertical-align:top;padding:15px 8px 25px 20px;\" bgcolor=\"#fdfdfd\"><p style=\"margin: 10px 0\">Chào <b> Trần Phan Hoài Thanh</b>,</p><p style=\"margin: 10px 0\">Xin chân thành cảm ơn Quý khách đã quan tâm và sử dụng dịch vụ của chúng tôi!<br>Yêu cầu của Quý khách đã gửi thành công. Chúng tôi sẽ phản hồi lại trong thời gian sớm nhất.</p><p style=\"margin: 10px 0\"><b style=\"text-decoration:underline;\">THÔNG TIN CỦA QUÝ KHÁCH:</b><br/><label style=\"font-weight:600;padding-left:12px;\">Họ và tên: </label> Trần Phan Hoài Thanh<br/><label style=\"font-weight:600;padding-left:12px;\">Email: </label> tranhoaithanh94@gmail.com<br/><label style=\"font-weight:600;padding-left:12px;\">Điện thoại: </label> 0932430191<br/><label style=\"font-weight:600;padding-left:12px;\">Số người: </label> 3<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đến: </label> 13/09/2019<br/><label style=\"font-weight:600;padding-left:12px;\">Thời gian: </label> 11:00am<br/><label style=\"font-weight:600;padding-left:12px;\">Địa điểm: </label> 75 Hoàng Văn Thụ - Đà Nẵng<br/><label style=\"font-weight:600;padding-left:12px;\">Ngày đặt: </label> 13/09/2019 10:19<br/><label style=\"font-weight:600;padding-left:12px;\">IP truy cập: </label> 113.176.100.89<br/></p><p style=\"margin: 10px 0\">Đây là hộp thư tự động. Sau thời gian trên nếu quý khách chưa nhân được phản hồi từ nhân viên của chúng tôi, rất có thể đã gặp sự cố nhỏ nào đó vì vậy Quý khách có thể liên hệ trực tiếp chúng tôi để nhận được những thông tin nhanh nhất.</p><p style=\"margin: 10px 0\">Chân thành cảm ơn!</p></td></tr></tbody></table><div style=\"min-height:35px\">&nbsp;</div><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\"><tbody><tr><td bgcolor=\"#e1e1e1\" style=\"padding:15px 10px 25px\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" style=\"margin:0 auto;min-width:290px;\" width=\"620\"><tbody><tr><td><table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\"><tbody><tr><td valign=\"top\" style=\"font-size:12px;color:#5e5e5e;font-family:Arial,serif;line-height:15px;\">Ẩm Thực Xèo</td></tr></tbody></table><table width=\"20%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tbody><tr><td style=\"font-size:13px;color:#5e5e5e;font-family:Arial,serif;line-height:1;vertical-align:top;text-align:right;font-style:italic;\"><span>Follow us on</span><br><a href=\"https://www.facebook.com/xeo75/\" target=\"_blank\"><img src=\"https://ci5.googleusercontent.com/proxy/PMSfAkbhhMLEe-tDCLFilReG-hlq_DWsTblTQ2qp8Dsq9KFW1UyFcKTr_uwU3EqyR8AhiFIooeExoAw9Oe3G5c6hvIEoOnU=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/fb.png\" width=\"27\" height=\"27\" alt=\"Facebook logo\" title=\"Facebook\" border=\"0\" style=\"padding:3px;\"></a>&nbsp;<a href=\"https://twitter.com\" target=\"_blank\"><img src=\"https://ci3.googleusercontent.com/proxy/GNHxgrYKL99Apyic0XnGYk6IqVZAc-wFuhgCDxzBYMr80NGggmI1nRORIBVRIkPkJHbQHGGMrTFtbzTDoxk5dc0i_H0HOc0=s0-d-e1-ft#https://www.livecoding.tv/static/img/email/tw.png\" width=\"27\" height=\"27\" alt=\"Twitter logo\" title=\"Twitter\" border=\"0\" style=\"padding:3px;\"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>','0','113.176.100.89','fa-globe','1568344758','1568361010');

-- --------------------------------------------------------

CREATE TABLE `olala3w_others` (
  `others_id` int(11) NOT NULL AUTO_INCREMENT,
  `others_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `p_from` bigint(20) NOT NULL DEFAULT 0,
  `p_to` bigint(20) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`others_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_others VALUES('1','1','9:00am','9-00am','0','0','1','1','0','1553006571','1553007321','25');
INSERT INTO olala3w_others VALUES('2','1','10:00am','10-00am','0','0','2','1','0','1553006584','1553007278','25');
INSERT INTO olala3w_others VALUES('3','1','11:00am','11-00am','0','0','3','1','0','1553007089','1553007327','25');
INSERT INTO olala3w_others VALUES('4','1','12:00am','12-00am','0','0','4','1','0','1553007130','1553007332','25');
INSERT INTO olala3w_others VALUES('5','1','1:00pm','1-00pm','0','0','5','1','0','1553007232','1553007340','25');
INSERT INTO olala3w_others VALUES('6','1','2:00pm','2-00pm','0','0','6','1','0','1553007351','1553007351','25');
INSERT INTO olala3w_others VALUES('7','1','4:00pm','4-00pm','0','0','7','1','0','1553007376','1553007376','25');
INSERT INTO olala3w_others VALUES('8','1','5:00pm','5-00pm','0','0','8','1','0','1553007383','1553007383','25');
INSERT INTO olala3w_others VALUES('9','1','6:00pm','6-00pm','0','0','9','1','0','1553007390','1553007390','25');
INSERT INTO olala3w_others VALUES('10','1','7:00pm','7-00pm','0','0','10','1','0','1553007399','1553007399','25');
INSERT INTO olala3w_others VALUES('11','1','8:00pm','8-00pm','0','0','11','1','0','1553007407','1553007407','25');
INSERT INTO olala3w_others VALUES('12','1','9:00pm','9-00pm','0','0','12','1','0','1553007416','1553007416','25');
INSERT INTO olala3w_others VALUES('13','2','75 Hoàng Văn Thụ - Đà Nẵng','75-hoang-van-thu-da-nang','0','0','1','1','0','1560481227','1560481227','25');
INSERT INTO olala3w_others VALUES('14','2','Siêu Thị Lotte Mart - Đà Nẵng','sieu-thi-lotte-mart-da-nang','0','0','2','1','0','1560481232','1560481232','25');
INSERT INTO olala3w_others VALUES('15','2','19A Võ Văn Kiệt - Đà Nẵng','19a-vo-van-kiet-da-nang','0','0','3','1','0','1560481238','1560481238','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_others_menu` (
  `others_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`others_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_others_menu VALUES('1','14','Giờ đặt bàn','gio-dat-ban','','0','1','1','0','1553006540','1553006540','25');
INSERT INTO olala3w_others_menu VALUES('2','14','Địa điểm','dia-diem','','0','2','1','0','1560481220','1560481220','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_page VALUES('27','copyright','Copyright','','<h4 class=\"font-constantia\" style=\"padding-bottom:5px;\"><strong>CÔNG TY CỔ PHẦN AMOMI</strong></h4>\r\n\r\n<p>Địa chỉ: 75 Hoàng Văn Thụ, Q. Hải Châu, Tp. Đà Nẵng</p>\r\n\r\n<p>Email: info@amomi.vn</p>\r\n\r\n<p>Hotline: <a href=\"tel:0941750075\">0941.750.075</a> - <a href=\"tel:19000375\">1900.0375</a></p>\r\n\r\n<p>Website: www.amthucxeo.com</p>\r\n','1','1','1555750445','25');
INSERT INTO olala3w_page VALUES('114','system','HỆ THỐNG CỬA HÀNG','','<p><a target=\"_blank\" href=\"https://goo.gl/maps/9NSuUvF2RgRnwGpE6\"><img alt=\"\" src=\"/uploads/images/icon/map.png\" style=\"width: 11px; height: 15px;\" />&nbsp; 75 Hoàng Văn Thụ - Đà Nẵng</a></p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/icon/map.png\" style=\"width: 11px; height: 15px;\" />&nbsp; <a target=\"_blank\" href=\"https://goo.gl/maps/F2Ti7oqvkoq9Y1W67\">Siêu Thị Lotte Mart - Đà Nẵng</a></p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/icon/map.png\" style=\"width: 11px; height: 15px;\" />&nbsp; <a target=\"_blank\" href=\"https://goo.gl/maps/TYwHFxXHeWHLAjPg9\">19A Võ Văn Kiệt - Đà Nẵng</a></p>\r\n','1','1','1557477582','1');
INSERT INTO olala3w_page VALUES('100','contact_maps','Bản đồ trang liên hệ','','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2711.094232271828!2d108.21967727804815!3d16.06205249060162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31421834a539afbd%3A0x7c7b2a8d818d6f64!2z4bqobSBUaOG7sWMgWMOobw!5e0!3m2!1svi!2s!4v1553048684294\" width=\"100%\" height=\"415\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>','1','1','1553048720','25');
INSERT INTO olala3w_page VALUES('101','contact_page','Thông tin liên hệ','Với sự nhiệt tình, chu đáo và cách làm việc chuyên nghiệp, chúng tôi tin tưởng sẽ làm thoả mãn mọi nhu cầu của quý vị.','<p>&nbsp; &nbsp;</p>\r\n','1','1','1553043662','25');
INSERT INTO olala3w_page VALUES('108','time_book','Thời gian mở cửa','','<p><strong>Monday - Friday : <span style=\"color:#ed1f24;\">5:30PM - 11:00PM</span> | Saturday - Sunday : <span style=\"color:#ed1f24;\">4:30PM - 10:00PM</span></strong></p>\r\n','1','1','1523117312','25');
INSERT INTO olala3w_page VALUES('109','business_hours','GIỜ MỞ CỬA','','<p>Tất cả các ngày trong tuần</p>\r\n\r\n<p>Từ&nbsp;10h A.M - 10h P.M</p>\r\n','1','1','1557477352','1');
INSERT INTO olala3w_page VALUES('110','item_1','66 MÓN ĂN','','<p>&nbsp; &nbsp;</p>\r\n','1','1','1555035859','25');
INSERT INTO olala3w_page VALUES('111','item_2','3 NHÀ HÀNG','','<p>&nbsp;&nbsp;</p>\r\n','1','1','1555035868','25');
INSERT INTO olala3w_page VALUES('112','item_3','7000+ KHÁCH HÀNG','','<p>&nbsp; &nbsp;</p>\r\n','1','1','1559461429','1');
INSERT INTO olala3w_page VALUES('113','item_4','10 NĂM KINH NGHIỆM','','<p>&nbsp; &nbsp;</p>\r\n','1','1','1552750874','25');
INSERT INTO olala3w_page VALUES('115','video_home','Video trang chủ','https://www.youtube.com/watch?v=euUkQRL0WDI','<p>&nbsp; &nbsp;&nbsp;</p>\r\n','1','1','1567227249','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_prjname` (
  `prjname_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  PRIMARY KEY (`prjname_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_menu_id` int(11) NOT NULL,
  `owner` int(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL DEFAULT 0,
  `sale` int(3) NOT NULL DEFAULT 0,
  `price` float NOT NULL DEFAULT 0,
  `guarantee` varchar(255) NOT NULL,
  `product_keys` varchar(50) NOT NULL,
  `direction` varchar(255) NOT NULL,
  `promotion` text NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `pin` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=797 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_product VALUES('704','261','0','Bánh xèo phô mai hải sản','banh-xeo-pho-mai-hai-san','dpcnd77d-704-banh-xeo-pho-mai-hai-san.jpg','','2010','0','189000','','FXXEO020','','<p>Tôm, Mực, Trứng gà, Nấm</p>\r\n','','','','1','0','0','1','','','','1552551600','1555493121','25');
INSERT INTO olala3w_product VALUES('703','261','0','Bánh xèo thập cẩm','banh-xeo-thap-cam','duocjhuf-703-banh-xeo-thap-cam.jpg','','2009','0','179000','','FXXEO010','','<p>Thịt heo, Tôm, Cua, Mực, Trứng gà</p>\r\n','','','','1','0','0','2','','','','1552551540','1555664882','25');
INSERT INTO olala3w_product VALUES('701','261','0','Bánh xèo tôm thịt','banh-xeo-tom-thit','we0247pc-701-banh-xeo-tom-thit.jpg','','2007','0','39000','','FXXEO050','','<p>Thịt heo, Tôm, Dưa Chua, Tương đậu, 11 loại rau ăn kèm</p>\r\n','','','','1','0','0','1','','','','1552551300','1555485351','25');
INSERT INTO olala3w_product VALUES('702','261','0','Bánh xèo tôm nhảy','banh-xeo-tom-nhay','f523gecu-702-banh-xeo-tom-nhay.jpg','','2008','0','39000','','FXXEO040','','<p>Tôm nhảy, Dưa Chua, Tương đậu, 11 loại rau ăn kèm</p>\r\n','','','','1','0','0','1','','','','1555575360','1568649945','25');
INSERT INTO olala3w_product VALUES('699','260','0','Thịt heo Đại Lộc','thit-heo-dai-loc','m6e1i03y-699-thit-heo-dai-loc.jpg','','2005','0','49000','','','','<p>Thịt ba chỉ heo thảo mộc, Mắm nêm. Bánh tráng, Đĩa rau sống.</p>\r\n','','','','1','0','0','1','','','','1552551060','1568629094','25');
INSERT INTO olala3w_product VALUES('700','260','0','Thịt heo Thảo mộc','thit-heo-thao-moc','zzik2jvf-700-thit-heo-thao-moc.jpg','','2006','0','79000','','FXCUB010','','<p>Thịt ba chỉ heo thảo mộc, mắm nêm, bánh tráng, đĩa rau sống</p>\r\n','','','','1','1','0','1','','','','1552551120','1568650011','1');
INSERT INTO olala3w_product VALUES('698','260','0','Nem lụi (nhỏ)','nem-lui-am-thuc-xeo','cq1gbdcj-698-nem-lui.jpg','','2004','0','49000','','FXCUB030','','<p>Nem lụi, Bánh tráng, 11 loại rau ăn kèm, Nước mắm Chua Ngọt</p>\r\n','','','','1','0','0','1','','','','1566461460','1568649926','1');
INSERT INTO olala3w_product VALUES('694','259','0','Tam hữu','tom-huu-tam-huu','x0zvniwm-694-tam-huu.jpg','','2000','0','49000','','FXGOC010','','<p>Tôm, Thịt heo, Rau cải</p>\r\n','','','','1','1','0','11','','','','1552550400','1568650026','1');
INSERT INTO olala3w_product VALUES('695','260','0','Cá nục cuốn','ca-nuc-cuon','tgp3crhc-695-ca-nuc-cuon.jpg','','2001','0','89000','','FXCUB060','','<p>Cá nục, Sốt chua ngọt, Rau muống, Bánh tráng</p>\r\n','','','','1','0','0','1','','','','1552550880','1568707914','1');
INSERT INTO olala3w_product VALUES('696','260','0','Cá hóa rồng','ca-hoa-rong','4r4jdl1q-696-ca-hoa-rong.jpg','','2002','0','189000','','FXCUB050','','<p>Cá điêu hồng, Đĩa rau ăn kèm, Mắm nêm, Tóp mở</p>\r\n','','','','1','1','0','1','','','','1552550940','1568708127','25');
INSERT INTO olala3w_product VALUES('697','260','0','Thịt nướng','thit-nuong','jmmztrew-697-thit-nuong.jpg','','2003','0','49000','','FXCUB040','','<p>Thịt heo nướng, bánh tráng, 11 loại rau ăn kèm, nước mắm chua ngọt.</p>\r\n','','','','1','0','0','1','','','','1552551000','1555483782','25');
INSERT INTO olala3w_product VALUES('692','259','0','Gỏi cuốn tôm thịt','goi-cuon-tom-thit','8a3n08sp-692-goi-cuon-tom-thit.jpg','','1998','0','49000','','FXGOC030','','<p>Thịt heo, Tôm, Xà lách, Bún tươi, Bánh tráng, Nước mắm chua ngọt</p>\r\n','','','','1','0','0','1','','','','1552550340','1568628567','1');
INSERT INTO olala3w_product VALUES('693','259','0','Gỏi cuốn nem nướng','goi-cuon-nem-nuong','llnijpzp-693-goi-cuon-nem-nuong.jpg','','1999','0','49000','','FXGOC020','','<p>Nem lụi, Xà lách, Bún tươi, Bánh tráng, Nước mắm chua ngọt</p>\r\n','','','','1','0','0','1','','','','1552550400','1568650027','1');
INSERT INTO olala3w_product VALUES('691','259','0','Gỏi cuốn thịt nướng','goi-cuon-thit-nuong','t09zjxn0-691-goi-cuon-thit-nuong.jpg','','1997','0','49000','','','','<p>Thịt heo nướng ướp, bún tươi, bánh tráng, nước mắm chua ngọt, dưa chua</p>\r\n','','','','1','0','0','1','','','','1552550280','1568628937','1');
INSERT INTO olala3w_product VALUES('690','259','0','Ram tôm hỏa tiễn','ram-tom-hoa-tien','3obuy2xi-690-ram-tom-hoa-tien.jpg','','1996','0','49000','','FXGOC050','','<p>Tôm, nem lụi, nấm, bánh tráng, sốt mắm chua ngọt.</p>\r\n','','','','1','0','0','1','','','','1552550220','1568650029','25');
INSERT INTO olala3w_product VALUES('687','259','0','Chả giò phô mai','cha-gio-pho-mai','rg4wvqe2-687-cha-gio-pho-mai.jpg','','1993','0','49000','','','','<p>Phô mai, Thịt heo, Trứng gà, Nấm, Mayonnaise</p>\r\n','','','','1','0','0','1','','','','1552550040','1555477190','25');
INSERT INTO olala3w_product VALUES('688','259','0','Ram tôm','ram-tom','c62eb0rj-688-ram-tom.jpg','','1994','0','49000','','','','<p>Tôm nhảy, Thịt heo, Bánh rể, Hành lá</p>\r\n','','','','1','0','0','1','','','','1552550100','1568708103','1');
INSERT INTO olala3w_product VALUES('689','259','0','Ram chả cua bể','ram-cha-cua-be','0xab8hx4-689-ram-cha-cua-be.jpg','','1995','0','59000','','','','<p>Thịt cua, Nem lụi, Nấm, Bánh tráng, Miến dong</p>\r\n','','','','1','0','0','1','','','','1552550160','1555477328','25');
INSERT INTO olala3w_product VALUES('685','258','0','Gỏi tôm hùm','goi-tom-hum','n2i1vf42-685-goi-tom-hum.jpg','','1991','0','549000','','FXGOT010','','<p>Tôm hùm, bưởi, bắp cải trắng, cà rốt, đu đủ</p>\r\n','','','','1','0','0','3','','','','1552545180','1555473253','25');
INSERT INTO olala3w_product VALUES('681','258','0','Gỏi Cung Đình','goi-cung-dinh','txaft80d-681-goi-cung-dinh.jpg','','1987','0','49000','','FXGOT020','','<p>Ba chỉ heo, Tôm, Phở lưới, Sốt trộn gỏi, Đậu phộng.</p>\r\n','','','','1','1','0','1','','','','1552548300','1568649999','25');
INSERT INTO olala3w_product VALUES('682','258','0','Gỏi cổ hũ dừa','goi-co-hu-dua','kmvs583s-682-goi-co-hu-dua.jpg','','1988','0','49000','','FXGOT070','','<p>Tôm, Thịt heo, bưởi, cổ hũ dừa, bắp cải trắng, sốt mắm chua ngọt</p>\r\n','','','','1','0','0','2','','','','1552548420','1557888260','1');
INSERT INTO olala3w_product VALUES('683','258','0','Gỏi rau càng cua','goi-rau-cang-cua','r5mwco4t-683-goi-rau-cang-cua.jpg','','1989','0','49000','','FXGOT080','','<p>U bò, trứng gàm rau càng cua, cà chua bi</p>\r\n','','','','1','0','0','1','','','','1552548540','1568629273','25');
INSERT INTO olala3w_product VALUES('684','258','0','Khoai tây chiên giòn','khoai-tay-chien-gion','8b74y4d8-684-khoai-tay-chien-gion.jpg','','1990','0','49000','','','','<p>Khoai tây, tương ớt đậm đà hương vị</p>\r\n','','','','1','0','0','3','','','','1552548600','1555473378','25');
INSERT INTO olala3w_product VALUES('686','259','0','Lá phở cuốn thịt nướng','la-pho-cuon-thit-nuong','tjc9u7nx-686-la-pho-cuon-thit-nuong.png','','1992','0','49000','','FXGOC090','','<p>Thịt heo nướng, mì lá, xà lách, đu đủ, cà rốt</p>\r\n','','','','1','0','0','1','','','','1552549920','1568708087','1');
INSERT INTO olala3w_product VALUES('680','258','0','Gỏi mít non','goi-mit-non','w2tntcwp-680-goi-mit-non.jpg','','1986','0','49000','','FXGOT060','','<p>Tôm, Thịt heo, Mít non, Bắp cải trắng, Sốt mắm chua ngọt.</p>\r\n','','','','1','0','0','1','','','','1552548120','1555473275','25');
INSERT INTO olala3w_product VALUES('679','258','0','Gỏi trái vả','goi-trai-va','kd37zlmy-679-goi-trai-va.jpg','','1985','0','49000','','FXGOT050','','<p>Tôm, Thịt heo, Trái vả, Bắp cải trắng, Sốt mắm chua ngọt</p>\r\n','','','','1','0','0','1','','','','1552548060','1555473271','25');
INSERT INTO olala3w_product VALUES('678','258','0','Gỏi Bò Bóp Thấu','goi-bo-bop-thau','uhujd5vr-678-goi-bo-bop-thau.jpg','','1984','0','49000','','Goi01','','<p>Bò Úc, Bánh đa, Sốt xào, Sốt trộn gỏi, Đậu phộng</p>\r\n','','','','1','0','0','1','','','','1552547640','1555493164','25');
INSERT INTO olala3w_product VALUES('705','261','0','BX tôm hùm (1kg/con)','banh-xeo-tom-hum-qw5q6e0gwy','ib58bely-705-banh-xeo-tom-hum.jpg','','2011','0','1999000','','FXXEO030','','<p>Tôm hùm, Tôm nhảy, Thịt bò, Mực, Trứng gà</p>\r\n','','','','1','0','0','1','','','','1552551600','1555485013','25');
INSERT INTO olala3w_product VALUES('715','262','0','Rượu nếp mới','ruou-nep-moi','lgotrlo0-715-ruou-nep-moi.jpg','','2033','0','249000','','','','','','','','1','0','0','1','','','','1554973740','0','25');
INSERT INTO olala3w_product VALUES('713','262','0','Cà phê đen đá','ca-phe-den-da','oc5kl6f3-713-ca-phe-den-da.jpg','','2031','0','29000','','','','','','','','1','0','0','1','','','','1554973260','0','25');
INSERT INTO olala3w_product VALUES('714','262','0','Rượu Soju','ruou-soju','3i0yh9c4-714-ruou-soju.jpg','','2032','0','179000','','','','','','','','1','0','0','1','','','','1554973440','0','25');
INSERT INTO olala3w_product VALUES('712','262','0','Cà phê sữa đá','ca-phe-sua-da','4m93uurj-712-ca-phe-sua-da.jpg','','2030','0','39000','','','','','','','','1','0','0','1','','','','1554972960','1568602829','1');
INSERT INTO olala3w_product VALUES('710','262','0','Sinh tố xoài','sinh-to-xoai','i4bqv84t-710-sinh-to-xoai.jpg','','2028','0','69000','','','','','','','','1','1','0','1','','','','1554977040','1555749428','25');
INSERT INTO olala3w_product VALUES('711','262','0','Cà phê dừa','ca-phe-dua','5vpgust1-711-ca-phe-dua.jpg','','2029','0','49000','','','','','','','','1','0','0','1','','','','1554972540','0','25');
INSERT INTO olala3w_product VALUES('716','262','0','Rượu Vodka men','ruou-vodka-men','mifr7upr-716-ruou-vodka-men.jpg','','2034','0','179000','','','','','','','','1','0','0','1','','','','1554974100','0','25');
INSERT INTO olala3w_product VALUES('717','262','0','Bia Heneiken','bia-heneiken','gwo36bm1-717-bia-heneiken.jpg','','2035','0','39000','','','','','','','','1','0','0','1','','','','1554974580','0','25');
INSERT INTO olala3w_product VALUES('718','262','0','Bia Tiger','bia-tiger','h6me9dmr-718-bia-tiger.jpg','','2036','0','29000','','','','','','','','1','0','0','1','','','','1554975360','0','25');
INSERT INTO olala3w_product VALUES('719','262','0','7 up','7-up','7yh0d5ri-719-7-up.jpg','','2037','0','29000','','','','','','','','1','0','0','1','','','','1554975420','0','25');
INSERT INTO olala3w_product VALUES('720','262','0','Pepsi','pepsi','g80dxhke-720-pepsi.jpg','','2038','0','29000','','','','','','','','1','0','0','1','','','','1554975540','0','25');
INSERT INTO olala3w_product VALUES('721','262','0','Coca','coca-s7ye83ihcq','57zo1c43-721-coca.jpg','','2039','0','29000','','','','','','','','1','0','0','1','','','','1554975660','0','25');
INSERT INTO olala3w_product VALUES('722','262','0','Nước suối','nuoc-suoi','wxikcqg8-722-nuoc-suoi.jpg','','2040','0','20000','','','','','','','','1','0','0','1','','','','1554975720','0','25');
INSERT INTO olala3w_product VALUES('723','262','0','Nước dừa','nuoc-dua','0uxj2d6a-723-nuoc-dua.jpg','','2041','0','49000','','','','','','','','1','0','0','1','','','','1554975780','0','25');
INSERT INTO olala3w_product VALUES('724','262','0','Nước ép chanh dây','soda-chanh-day','8novlqr4-724-soda-chanh-day.jpg','','2043','0','49000','','','','','','','','1','0','0','1','','','','1554976080','1568606011','1');
INSERT INTO olala3w_product VALUES('725','262','0','Trà tắc quế','tra-tac-que','dqj7sdv7-725-tra-tac-que.jpg','','2044','0','59000','','','','','','','','1','0','0','1','','','','1554976560','0','25');
INSERT INTO olala3w_product VALUES('726','262','0','Nước chanh tươi','nuoc-chanh-tuoi','ufzchbvd-726-nuoc-chanh-tuoi.jpg','','2045','0','49000','','','','','','','','1','0','0','3','','','','1554976680','1555749420','25');
INSERT INTO olala3w_product VALUES('727','262','0','Nước ép táo','nuoc-ep-tao','jl0uvomj-727-nuoc-ep-tao.jpg','','2046','0','59000','','','','','','','','1','1','0','1','','','','1554976740','1555749445','25');
INSERT INTO olala3w_product VALUES('728','262','0','Nước ép thơm','nuoc-ep-thom','94vydiw9-728-nuoc-ep-thom.jpg','','2047','0','49000','','','','','','','','1','1','0','1','','','','1554976800','1555749424','25');
INSERT INTO olala3w_product VALUES('729','262','0','Nước ép dưa hấu','nuoc-ep-dua-hau','cb8cud1f-729-nuoc-ep-dua-hau.jpg','','2048','0','49000','','','','','','','','1','1','0','1','','','','1554976920','1554977886','25');
INSERT INTO olala3w_product VALUES('730','263','0','Kem Flan','kem-flan','4w30td5i-730-kem-flan.jpg','','2049','0','19000','','','','','','','','1','0','0','1','','','','1554978120','1554978468','25');
INSERT INTO olala3w_product VALUES('731','263','0','Rau câu dừa','rau-cau-dua','c3ayi96b-731-rau-cau-dua.jpg','','2050','0','19000','','','','','','','','1','0','0','1','','','','1554978180','0','25');
INSERT INTO olala3w_product VALUES('732','263','0','Yaourt xoài','yaourt-xoai','zsckgiw3-732-yaourt-xoai.jpg','','2051','0','19000','','','','','','','','1','0','0','1','','','','1554978420','0','25');
INSERT INTO olala3w_product VALUES('733','263','0','Yaourt','yaourt','ihnn2v43-733-yaourt.jpg','','2052','0','19000','','','','','','','','1','0','0','1','','','','1554978540','0','25');
INSERT INTO olala3w_product VALUES('734','263','0','Xôi xoài','xoi-xoai','klh5to5m-734-xoi-xoai.jpg','','2053','0','39000','','','','','','','','1','1','0','1','','','','1554978600','1555749405','25');
INSERT INTO olala3w_product VALUES('735','258','0','Gỏi bắp chuối','goi-bap-chuoi','cbuhf2na-735-goi-bap-chuoi.jpg','','2055','0','49000','','FXGOT090','','','','','','1','0','0','1','','','','1552362480','1557888410','1');
INSERT INTO olala3w_product VALUES('736','258','0','Phở lưới lắc','pho-luoi-lac','uhl1hpdz-736-pho-luoi-lac.jpg','','2056','0','79000','','FXGOT040','','','','','','1','0','0','1','','','','1552362540','1555661990','25');
INSERT INTO olala3w_product VALUES('737','261','0','BX tôm hùm (Size 700gr/con)','banh-xeo-tom-hum-size-700gr-con','mhyu0x7c-737-banh-xeo-tom-hum-size-700gr-con.jpg','','2057','0','1599000','','FXXEO031','','<p>Tôm hùm, Tôm nhảy, Thịt bò, Mực, Trứng gà</p>\r\n','','','','1','0','0','1','','','','1555484400','1555484640','25');
INSERT INTO olala3w_product VALUES('738','261','0','BX tôm hùm (Size 300gr/con)','bx-tom-hum-size-300gr-con','qqx2epfz-738-bx-tom-hum-size-300gr-con.jpg','','2058','0','1199000','','FXXEO032','','<p><span style=\"color: rgb(85, 85, 85); text-align: start; background-color: rgb(247, 247, 247);\">Tôm hùm, Tôm nhảy, Thịt bò, Mực, Trứng gà</span></p>\r\n','','','','1','0','0','1','','','','1555485000','0','25');
INSERT INTO olala3w_product VALUES('739','261','0','Bánh xèo mực','banh-xeo-muc','5f7s4dva-739-banh-xeo-muc.jpg','','2059','0','179000','','FXXEO060','','<p>Mực tươi, Dưa Chua, Tương đậu, 11 loại rau ăn kèm</p>\r\n','','','','1','0','0','1','','','','1555485360','1555662967','25');
INSERT INTO olala3w_product VALUES('740','261','0','Bánh xèo hải sản','banh-xeo-hai-san-obes28d3qh','3w1qu9q2-740-banh-xeo-hai-san.jpg','','2060','0','179000','','FXXEO070','','<p>Tôm, Mực ,&nbsp;Dưa Chua, Tương đậu, 11 loại rau ăn kèm</p>\r\n','','','','1','0','0','1','','','','1555485420','1555663254','25');
INSERT INTO olala3w_product VALUES('741','261','0','Bánh xèo thịt bò','banh-xeo-thit-bo-rb5hzc3vrv','sjdcxh4d-741-banh-xeo-thit-bo.jpg','','2061','0','39000','','FXXEO080','','<p>Thịt bò,&nbsp;Dưa Chua, Tương đậu, 11 loại rau ăn kèm</p>\r\n','','','','1','0','0','1','','','','1555485480','1555662884','25');
INSERT INTO olala3w_product VALUES('742','261','0','Bánh xèo thịt gà','banh-xeo-thit-ga-am-thuc-xeo','t532e79x-742-banh-xeo-thit-ga.jpg','','2062','0','39000','','FXXEO090','','','','','','1','0','0','1','','','','1555485540','1555663548','25');
INSERT INTO olala3w_product VALUES('743','261','0','Bánh xèo thịt vịt','banh-xeo-thit-vit','sq3r63vm-743-banh-xeo-thit-vit.jpg','','2063','0','49000','','FXXEO100','','','','','','1','0','0','1','','','','1555485540','1555663454','25');
INSERT INTO olala3w_product VALUES('744','261','0','Bánh xèo nấm','banh-xeo-nam','89817q0o-744-banh-xeo-nam.jpg','','2064','0','39000','','FXXEO110','','','','','','1','0','0','1','','','','1555485600','1555663353','25');
INSERT INTO olala3w_product VALUES('745','264','0','Bún chả thịt nướng','bun-cha-thit-nuong','jozr2w5i-745-bun-cha-thit-nuong.jpg','','2065','0','49000','','FXBMP150','','','','','','1','0','0','1','','','','1555486200','1555665601','25');
INSERT INTO olala3w_product VALUES('746','264','0','Bún thịt nướng','bun-thit-nuong','u6y2i2bc-746-bun-thit-nuong.jpg','','2066','0','49000','','FXBMP140','','<p>Chả Nem Lụi,&nbsp;Thịt Nướng Ứớp,&nbsp;Mè Trắng Rang,&nbsp;Dưa Leo,&nbsp;Xà Lách Hỗn Hợp,&nbsp;Dưa Chua,&nbsp;Tương đậu</p>\r\n','','','','1','0','0','1','','','','1555486260','1555486553','25');
INSERT INTO olala3w_product VALUES('747','264','0','Bánh hỏi thịt nướng','banh-hoi-thit-nuong','x7t1fbaa-747-banh-hoi-thit-nuong.jpg','','2067','0','49000','','FXBMP130','','<p>Thịt Nướng Ướp,&nbsp;Bánh Hỏi (4 lát),&nbsp;Mè Trắng Rang,&nbsp;Dầu Hẹ,&nbsp;Ớt Sừng Đỏ,&nbsp;Ngò Rí,&nbsp;Nước Mắm Chua Ngọt</p>\r\n','','','','1','0','0','1','','','','1555486320','1563789502','1');
INSERT INTO olala3w_product VALUES('748','264','0','Mỳ quảng tôm thịt','my-quang-tom-thit','hp8mw7tj-748-my-quang-tom-thit.jpg','','2068','0','49000','','FXBMP120','','<p>Mỳ Quảng,&nbsp;Thịt Xíu,&nbsp;Tôm,&nbsp;Trứng Gà Luộc,&nbsp;Bánh Tráng,&nbsp;Đậu Phộng Rang, Các loại rau.</p>\r\n','','','','1','0','0','1','','','','1555487640','0','25');
INSERT INTO olala3w_product VALUES('749','264','0','Mỳ quảng gà ','my-quang-ga','js4t9xyq-749-my-quang-ga.jpg','','2070','0','49000','','FXBMP110','','<p>Mỳ Quảng,&nbsp;Gà, Bánh Tráng,&nbsp;Đậu Phộng Rang, Các loại rau</p>\r\n','','','','1','0','0','1','','','','1555487940','0','25');
INSERT INTO olala3w_product VALUES('750','264','0','Mỳ quảng cá lóc ','my-quang-ca-loc','fk9nzjco-750-my-quang-ca-loc.jpg','','2071','0','49000','','FXBMP100','','<p>Mỳ Quảng,&nbsp;Cá lóc, Bánh Tráng,&nbsp;Đậu Phộng Rang, Các loại rau.</p>\r\n','','','','1','0','0','1','','','','1555488060','0','25');
INSERT INTO olala3w_product VALUES('751','264','0','Phở ông Bảy','pho-ong-bay','w40xjxq6-751-pho-ong-bay.jpg','','2072','0','69000','','FXBMP070','','<p>Thịt Nạm Chín, U Bò Chín, Gân Bò Chín, Chả Nem Lụi ( 2 viên ), Bánh Phở, Nước Phở, Hành Lá, Ngò Rí, Hành Tây, Hành Lá.</p>\r\n','','','','1','0','0','1','','','','1555488120','1555665378','25');
INSERT INTO olala3w_product VALUES('752','264','0','Phở lưới áp chảo','pho-luoi-ap-chao','ybw7w50c-752-pho-luoi-ap-chao.jpg','','2073','0','59000','','FXBMP060','','','','','','1','0','0','1','','','','1555488180','0','25');
INSERT INTO olala3w_product VALUES('753','264','0','Phở lưới chiên xù','pho-luoi-chien-xu','g2vd9zgs-753-pho-luoi-chien-xu.jpg','','2074','0','59000','','FXBMP050','','','','','','1','0','0','1','','','','1555489140','1555665152','25');
INSERT INTO olala3w_product VALUES('754','264','0','Phở lưới tôm thịt','pho-luoi-tom-thit','tb5odyyx-754-pho-luoi-tom-thit.jpg','','2075','0','49000','','FXBMP040','','','','','','1','1','0','1','','','','1555489620','1568649980','25');
INSERT INTO olala3w_product VALUES('755','264','0','Phở lưới gà ','pho-luoi-ga','tekm73fd-755-pho-luoi-ga.jpg','','2076','0','49000','','FXBMP030','','','','','','1','0','0','1','','','','1555489980','1555664967','25');
INSERT INTO olala3w_product VALUES('756','264','0','Phở lưới cá lóc ','pho-luoi-ca-loc','gz42d6kl-756-pho-luoi-ca-loc.jpg','','2077','0','49000','','FXBMP020','','<p>Cá Lóc,&nbsp;Phở, Hành phi,&nbsp;Rau Hỗn Hợp</p>\r\n','','','','1','0','0','1','','','','1555491360','1568649979','25');
INSERT INTO olala3w_product VALUES('757','264','0','Phở lưới cá nục','pho-luoi-ca-nuc','sotxoodk-757-pho-luoi-ca-nuc.jpg','','2078','0','49000','','FXBMP010','','<p>Cá Nục,&nbsp;Phở, Hành phi,&nbsp;Rau Hỗn Hợp</p>\r\n','','','','1','0','0','1','','','','1555491480','1555749753','25');
INSERT INTO olala3w_product VALUES('758','265','0','Cơm chiên trứng','com-chien-trung','8t1oaevj-758-com-chien-trung.jpg','','2079','0','79000','','FXCOM080','','','','','','1','0','0','1','','','','1555491720','1555748651','25');
INSERT INTO olala3w_product VALUES('759','265','0','Cơm chiên hải sản','com-chien-hai-san','bnuyolx3-759-com-chien-hai-san.jpg','','2080','0','79000','','FXCOM070','','<p>Cơm chiên, Tôm, Mực, Dưa leo, Cà chua, Hành Ngò</p>\r\n','','','','1','0','0','1','','','','1555491780','0','25');
INSERT INTO olala3w_product VALUES('760','265','0','Cơm gà nếp cẩm','com-ga-nep-cam','f5dqzh2t-760-com-ga-nep-cam.jpg','','2081','0','79000','','FXCOM060','','','','','','1','0','0','1','','','','1555491900','1555748808','25');
INSERT INTO olala3w_product VALUES('761','265','0','Cơm lam thịt xíu','com-lam-thit-xiu','9xjxuklg-761-com-lam-thit-xiu.jpg','','2082','0','69000','','FXCOM050','','','','','','1','0','0','1','','','','1555491900','0','25');
INSERT INTO olala3w_product VALUES('762','265','0','Cơm lam','com-lam','wsohzuvr-762-com-lam.jpg','','2083','0','119000','','FXCOM040','','','','','','1','0','0','1','','','','1555491960','1555748712','25');
INSERT INTO olala3w_product VALUES('763','265','0','Cơm trái dừa','com-trai-dua','kno9r4c0-763-com-trai-dua.jpg','','2084','0','99000','','FXCOM030','','','','','','1','0','0','1','','','','1555492020','1555748392','25');
INSERT INTO olala3w_product VALUES('764','265','0','Cơm trái bí','com-trai-bi','utnfgve7-764-com-trai-bi.jpg','','2085','0','99000','','FXCOM020','','','','','','1','0','0','1','','','','1555492020','1555748465','25');
INSERT INTO olala3w_product VALUES('765','265','0','Cơm trái dứa','com-trai-dua-am-thuc-xeo','y540ff2c-765-com-trai-dua.jpg','','2086','0','119000','','FXCOM010','','<p>Mực, Thịt Xíu, Tôm, Trứng Gà, Cơm Trắng, Cơm Rang, Hạt Nêm, Bột Ngọt, Tiêu Đen Xay, Dầu ăn<br />\r\nThơm, Ngò Rí, Cà rốt, Đậu Hà Lan, Bắp</p>\r\n','','','','1','1','0','1','','','','1555492080','1555749531','25');
INSERT INTO olala3w_product VALUES('766','266','0','Canh bò hầm đậu hũ ','canh-bo-ham-dau-hu','299m2tpl-766-canh-bo-ham-dau-hu.jpg','','2087','0','59000','','FXCAN060','','','','','','1','0','0','1','','','','1555492260','0','25');
INSERT INTO olala3w_product VALUES('767','266','0','Canh rong biển','canh-rong-bien','o9um9pew-767-canh-rong-bien.jpg','','2088','0','59000','','FXCAN050','','','','','','1','0','0','1','','','','1555492320','0','25');
INSERT INTO olala3w_product VALUES('768','266','0','Canh chua cá lóc ','canh-chua-ca-loc','vd49y2g2-768-canh-chua-ca-loc.jpg','','2089','0','59000','','FXCAN040','','','','','','1','0','0','1','','','','1555492380','1556363299','25');
INSERT INTO olala3w_product VALUES('769','266','0','Canh gà lá giang','canh-ga-la-giang','1q9shsns-769-canh-ga-la-giang.jpg','','2090','0','59000','','FXCAN030','','<p>Ức gà, Đường, Hạt Nêm, Bột Ngọt, Bột Chanh, Nước, Dầu Ăn, Nước Mắm, Dầu Điều, Sả, Lá Giang, Hành Tím, Cà Chua</p>\r\n','','','','1','0','0','1','','','','1555492380','1556363231','25');
INSERT INTO olala3w_product VALUES('770','266','0','Canh cải thịt bằm','canh-cai-thit-bam','ol9d69a9-770-canh-cai-thit-bam.jpg','','2091','0','59000','','FXCAN020','','','','','','1','0','0','1','','','','1555492500','0','25');
INSERT INTO olala3w_product VALUES('771','266','0','Canh tôm chua cay','canh-tom-chua-cay','fo3scf4o-771-canh-tom-chua-cay.jpg','','2092','0','59000','','FXCAN010','','','','','','1','0','0','1','','','','1555492560','1555748982','25');
INSERT INTO olala3w_product VALUES('774','262','0','Chanh Sả Tắc','chanh-sa-tac','3t79gdk6-774-chanh-sa-tac.jpg','','2101','0','59000','','','','<p>Chảnh , Sả , Quả tắc , Đường , Muối</p>\r\n','','','','1','1','0','1','','','','1557738780','1568602610','1');
INSERT INTO olala3w_product VALUES('773','262','0','Trà Cù Lao','tra-cu-lao-7ufrilc9s1','aeo6cn9v-773-tra-cu-lao.jpg','','2100','0','59000','','TEA001','','<p>La hán , Táo tàu , atiso , Cúc bạch , Cam thảo , Chanh , Sả</p>\r\n','','','','1','1','0','1','','','','1557738360','1557738520','1');
INSERT INTO olala3w_product VALUES('775','260','0','Nem lụi (lớn)','nem-lui-lon','xcb8pwid-775-nem-lui-lon.jpg','','2118','0','89000','','','','<p>Nem lụi, Bánh tráng, 11 loại rau ăn kèm, Nước mắm Chua Ngọt</p>\r\n','','','','1','1','0','1','','','','1563788880','1568649928','1');
INSERT INTO olala3w_product VALUES('776','267','0','Mẹt phở sắn Quế Sơn lắc ngó sen','met-pho-san-que-son-lac-ngo-sen','rw0sc6u0-776-met-pho-san-que-son-lac-ngo-sen.jpg','','2125','0','0','','FXCOMBO010','','','','','','1','1','0','6','','','','1568603040','1568650160','1');
INSERT INTO olala3w_product VALUES('777','267','0','Tam Hữu','tam-huu','muizespt-777-tam-huu.jpg','','2127','0','0','','FXCOMBO020','','','','','','1','0','0','1','','','','1568603220','0','1');
INSERT INTO olala3w_product VALUES('778','267','0','Nón bánh xèo','non-banh-xeo','r9r78xer-778-non-banh-xeo.jpg','','2128','0','0','','','','<p>Bạn chọn 3 trong 5 loại bánh xèo : Bánh xèo gà , tôm nhảy , nấm , bò , vịt</p>\r\n','','','','1','0','0','1','','','','1568603280','0','1');
INSERT INTO olala3w_product VALUES('779','267','0','Mỳ quảng thố','my-quang-tho','lx7trdkp-779-my-quang-tho.jpg','','2129','0','0','','FXCOMBO030','','<p>Bạn có thể chọn mỳ cá lóc / tôm thịt / gà</p>\r\n','','','','1','0','0','1','','','','1568603340','0','1');
INSERT INTO olala3w_product VALUES('780','267','0','Combo Lồng chim ngũ hành ','combo-long-chim-ngu-hanh','0t0ivbyn-780-combo-long-chim-ngu-hanh.jpg','','2130','0','0','','FXCOMBO0340','','<p>Gồm chả bò , ram tôm , gỏi cuốn mực , nem lụi , bánh hỏi thịt nướng</p>\r\n','','','','1','1','0','1','','','','1568603400','1568650158','1');
INSERT INTO olala3w_product VALUES('781','261','0','Bánh xèo Thịt bò ( 2 cái )','banh-xeo-thit-bo-2-cai','2dxrovm8-781-banh-xeo-thit-bo-2-cai.jpg','','2132','0','69000','','','','','','','','1','0','0','1','','','','1568604900','1568606071','1');
INSERT INTO olala3w_product VALUES('782','261','0','Bánh xèo Tôm nhảy ( 2 cái )','banh-xeo-tom-nhay-2-cai','uazy2zm1-782-banh-xeo-tom-nhay-2-cai.jpg','','2133','0','69000','','','','','','','','1','1','0','1','','','','1568605980','1568649945','1');
INSERT INTO olala3w_product VALUES('783','261','0','Bánh xèo Gà ( 2 cái ) ','banh-xeo-ga-2-cai','p6taypdl-783-banh-xeo-ga-2-cai.jpg','','2134','0','69000','','','','','','','','1','0','0','1','','','','1568606040','0','1');
INSERT INTO olala3w_product VALUES('784','261','0','Bánh xèo Thịt vịt ( 2 cái ) ','banh-xeo-thit-vit-2-cai','i2xcr60v-784-banh-xeo-thit-vit-2-cai.jpg','','2135','0','69000','','','','','','','','1','0','0','1','','','','1568606100','0','1');
INSERT INTO olala3w_product VALUES('785','261','0','Bánh xèo Nấm ( 2 cái ) ','banh-xeo-nam-2-cai','lybjj46v-785-banh-xeo-nam-2-cai.jpg','','2136','0','69000','','','','','','','','1','0','0','1','','','','1568606160','0','1');
INSERT INTO olala3w_product VALUES('786','262','0','Rượu tam đa đinh lăng ( 500ml )','ruou-tam-da-dinh-lang','paeqedig-786-ruou-tam-da-dinh-lang.jpg','','2137','0','480000','','','','','','','','1','0','0','1','','','','1568606400','1568607245','1');
INSERT INTO olala3w_product VALUES('787','262','0','Rượu tam đa Nếp cái ( 500 ml )','ruou-tam-da-nep-cai-500-ml','2ves0y4y-787-ruou-tam-da-nep-cai-500-ml.jpg','','2138','0','249000','','','','','','','','1','0','0','1','','','','1568607180','0','1');
INSERT INTO olala3w_product VALUES('788','262','0','Soda chanh dây','soda-chanh-day-jlksacgwns','58d2xno7-788-soda-chanh-day.jpg','','2139','0','59000','','','','','','','','1','0','0','1','','','','1568607240','0','1');
INSERT INTO olala3w_product VALUES('789','262','0','Soda dâu','soda-dau','3b84mpm8-789-soda-dau.jpg','','2140','0','59000','','','','','','','','1','0','0','1','','','','1568607600','0','1');
INSERT INTO olala3w_product VALUES('790','262','0','Soda blue curacao','soda-blue-curacao','2ebpy31i-790-soda-blue-curacao.jpg','','2141','0','59000','','','','','','','','1','0','0','1','','','','1568607600','0','1');
INSERT INTO olala3w_product VALUES('791','261','0','Bánh xèo Tôm thịt ( 2 cái )','banh-xeo-tom-thit-90jgiy51wl','8genmihv-791-banh-xeo-tom-thit.jpg','','2142','0','69000','','','','','','','','1','0','0','1','','','','1568607660','1568607736','1');
INSERT INTO olala3w_product VALUES('792','267','0','Rau câu dừa','rau-cau-dua-jk5ol9gstg','mgaj4jyq-792-rau-cau-dua.jpg','','2143','0','0','','','','','','','','1','0','0','1','','','','1568607780','0','1');
INSERT INTO olala3w_product VALUES('793','267','0','Bánh tráng cuốn thịt heo thảo mộc','banh-trang-cuon-thit-heo-thao-moc','gpbja2c6-793-banh-trang-cuon-thit-heo-thao-moc.jpg','','2144','0','0','','','','','','','','1','0','0','1','','','','1568607840','0','1');
INSERT INTO olala3w_product VALUES('794','267','0','Trà cù lao','tra-cu-lao-kk90bll5e3','q8o33i1c-794-tra-cu-lao.jpg','','2145','0','0','','','','','','','','1','0','0','1','','','','1568607960','0','1');
INSERT INTO olala3w_product VALUES('795','268','0','Khám Phá ( 2 người )','combo-kham-pha-319-000-2-nguoi','2mvh3mgk-795-combo-kham-pha-319-000-2-nguoi.jpg','','2147','0','319000','','','','<p>Combo gồm : Gỏi cung đình , tam hữu , lá phở cuốn thịt nướng , nem lụi , bánh xèo tôm nhảy , bánh hỏi thịt nướng , cơm trái dứa&nbsp;, canh cải thịt bằm , rau câu dừa</p>\r\n','','','','1','0','0','1','','','','1568629440','1568689704','1');
INSERT INTO olala3w_product VALUES('796','268','0','Combo No Say ( 3 người )','combo-no-say-499-000-3-nguoi','1xzuq17f-796-combo-no-say-499-000-3-nguoi.jpg','','2149','0','499000','','','','<p>Combo Gồm : Phở lưới lắc , khoai tây chiên giòn , tam hữu , thịt heo thảo mộc , nem lụi , bánh xèo hải sản , bánh hỏi thịt nướng , bún chả thịt nướng , canh tôm chua cay , rau cau dừa</p>\r\n','','','','1','0','0','1','','','','1568629500','1568689692','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_product_menu` (
  `product_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_product_menu VALUES('262','74','Thức uống','thuc-uong','','','','','0','8','1','0','no','1552547579','1555485902','25');
INSERT INTO olala3w_product_menu VALUES('260','74','Bánh cuốn','banh-cuon','','','','','0','3','1','0','no','1552547566','1552547566','25');
INSERT INTO olala3w_product_menu VALUES('261','74','Bánh xèo','banh-xeo','','','','','0','4','1','0','no','1552547571','1552547571','25');
INSERT INTO olala3w_product_menu VALUES('258','74','Gỏi trộn','goi-tron','','','','','0','1','1','0','goi-tron-1552903437.png','1552401739','1557887728','25');
INSERT INTO olala3w_product_menu VALUES('259','74','Gỏi cuốn','goi-cuon','','','','','0','2','1','0','no','1552401755','1552547555','25');
INSERT INTO olala3w_product_menu VALUES('263','74','Tráng miệng','trang-mieng','','','','','0','9','1','0','no','1554978003','1555485911','25');
INSERT INTO olala3w_product_menu VALUES('264','74','Bún mỳ phở','bun-my-pho','','','','','0','5','1','0','no','1555485857','1555485864','25');
INSERT INTO olala3w_product_menu VALUES('265','74','Cơm','com','','','','','0','6','1','0','no','1555485874','1555485881','25');
INSERT INTO olala3w_product_menu VALUES('266','74','Canh','canh','','','','','0','7','1','0','no','1555485894','1555485900','25');
INSERT INTO olala3w_product_menu VALUES('267','74','Combo Tinh Hoa Xứ Quãng ( 320.000/4 người )','combo-tinh-hoa-xu-quang-must-try','','','','','0','10','1','1','combo-tinh-hoa-xu-quang-must-try-1568603040.jpg','1568602938','1568629279','1');
INSERT INTO olala3w_product_menu VALUES('268','74','Combo ','combo','','','','','0','11','1','0','no','1568629436','1568629436','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_project_menu` (
  `project_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `project_type` int(11) NOT NULL DEFAULT 0,
  `price_max` bigint(20) NOT NULL DEFAULT 0,
  `price_min` bigint(20) NOT NULL DEFAULT 0,
  `legal` int(1) NOT NULL DEFAULT 0,
  `location` int(11) NOT NULL DEFAULT 0,
  `geo_radius` int(11) NOT NULL DEFAULT 0,
  `project_use` varchar(255) NOT NULL,
  `project_hot` varchar(255) NOT NULL,
  `project_involve` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`project_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_email` (
  `register_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`register_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_try` (
  `register_try_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL DEFAULT 'no-name',
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`register_try_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_road` (
  `road_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`road_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_street` (
  `street_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tour` (
  `tour_id` int(11) NOT NULL AUTO_INCREMENT,
  `tour_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `tour_keys` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT 0,
  `date_schedule` varchar(255) NOT NULL,
  `date_departure` int(11) NOT NULL DEFAULT 0,
  `means` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `tour_type` varchar(255) NOT NULL,
  `destination` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `sale` int(3) NOT NULL DEFAULT 0,
  `schedule` text CHARACTER SET utf8mb4 NOT NULL,
  `price_list_service` text NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `maps` text CHARACTER SET utf8mb4 NOT NULL,
  `video` text CHARACTER SET utf8mb4 NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `pin` int(1) NOT NULL DEFAULT 0,
  `views` bigint(20) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tour_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tour_menu` (
  `tour_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 1,
  `is_active` int(1) NOT NULL DEFAULT 1,
  `hot` int(1) NOT NULL DEFAULT 0,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT 0,
  `modified_time` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tour_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_uploads_tmp` (
  `upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NOT NULL DEFAULT 0,
  `list_img` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2150 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_uploads_tmp VALUES('2025','1','1552965350_2025_37de922bd99594516c98a1d485529d73.jpg;1552965351_2025_185cf4fca5e6a7fc54ad3cfb3063bf59.jpg;1552965353_2025_583601173f603d997c21079d0da8fdbf.jpg;1552965354_2025_e8fe3426cb5cee3aabf9821ce377165c.jpg;1552965355_2025_8b7358a803a4323964cb97098775961f.jpg;1552965357_2025_b13d26e8339a2880b77a05b80b8e8a7c.jpg;1552965358_2025_0ff1c8cb917808f084b8e827517b0e5c.jpg;1552965360_2025_5c994aef6cd3db1987eac89f23984501.jpg;1552965361_2025_f90219f7e43766b1f93c4132481e129c.jpg;1552965362_2025_43d4dc7ab394369cc7fc4445ecb265f2.jpg;1552965364_2025_547648171127649b1b75d06cdeedfabd.jpg;1552965366_2025_4de32a13c1d603ee7aa4a7ebc8544b92.jpg;','1552965280');
INSERT INTO olala3w_uploads_tmp VALUES('2024','1','1552965215_2024_b6c8d77bbc1b2ee7ab22bba2c27be278.png;1552965216_2024_1ce1ca633af954caf3f593db4a0a7e99.jpg;1552965217_2024_de364af18a4b207c795ff559f150ad65.jpg;1552965218_2024_0ea6d7bebfb998f40632820365d5663a.jpg;1552965220_2024_072496a5060e219480b839a58eb2b26d.jpg;1552965221_2024_806ced18a48af3d23a9bd4012d3c5349.jpg;1552965222_2024_f1cef494ed26e05ff2ad3a760ed2cacf.jpg;1552965223_2024_4b659369fc3a55c7b5b2b7cd35afbc83.jpg;','1552965151');
INSERT INTO olala3w_uploads_tmp VALUES('2023','1','1552965048_2023_2465f4affc8c91371ac646663b2506d4.jpg;1552965049_2023_36fe4d7425f8f40f065987951e260021.jpg;1552965050_2023_d2286b514da9a059d77da20785871054.jpg;1552965052_2023_e4f85c82da81587b6bf535b4ca0d8073.jpg;1552965053_2023_d1b28eb6b5b6f25726834bd043d7a75d.jpg;1552965054_2023_fe4f70c08b126ca548a03fe8e9a3a0ca.jpg;1552965056_2023_bd02b9c3e7cea3deca9b8a9c33f0aa63.jpg;1552965057_2023_d2adf78c061af1659ad14be2972b2616.jpg;1552965059_2023_ecaec0b6cf2fca4f974f2a360ad52019.jpg;1552965062_2023_2bfda3fed90a3fdde6c0d4e33fc90e65.jpg;1552965098_2023_9734494fa67590b66c62abf1f68a675a.jpg;','1552965005');
INSERT INTO olala3w_uploads_tmp VALUES('2030','1','','1554972975');
INSERT INTO olala3w_uploads_tmp VALUES('2029','1','','1554972585');
INSERT INTO olala3w_uploads_tmp VALUES('2028','1','','1554972456');
INSERT INTO olala3w_uploads_tmp VALUES('2018','0','','1552961479');
INSERT INTO olala3w_uploads_tmp VALUES('2031','1','','1554973301');
INSERT INTO olala3w_uploads_tmp VALUES('2011','1','','1552551647');
INSERT INTO olala3w_uploads_tmp VALUES('2012','1','','1552751572');
INSERT INTO olala3w_uploads_tmp VALUES('2013','1','','1552751924');
INSERT INTO olala3w_uploads_tmp VALUES('2014','1','','1552752024');
INSERT INTO olala3w_uploads_tmp VALUES('2017','1','1552790004_2017_90ef3ae39b883d458d60892fd27e9d1e.png;1552790005_2017_86c6b3903554441a8b850c0c698a299d.png;1552790007_2017_2662828db9f2908526206f923db9e61f.png;1552790008_2017_092c4ee3c8502a1a2669237e35aeb863.png;1552790010_2017_62ef6c4840739b255a3a8b0d6000c6ac.jpg;1552790012_2017_21a9f81799b9bc30caa7af9cc409224b.jpg;1552790014_2017_3df49c3ab785f5ce0386d2223e720f8f.jpg;','1552789980');
INSERT INTO olala3w_uploads_tmp VALUES('2010','1','','1552551611');
INSERT INTO olala3w_uploads_tmp VALUES('2009','1','','1552551549');
INSERT INTO olala3w_uploads_tmp VALUES('2008','1','','1552551366');
INSERT INTO olala3w_uploads_tmp VALUES('2007','1','','1552551322');
INSERT INTO olala3w_uploads_tmp VALUES('2006','1','','1552551169');
INSERT INTO olala3w_uploads_tmp VALUES('2005','1','','1552551114');
INSERT INTO olala3w_uploads_tmp VALUES('2004','1','','1552551063');
INSERT INTO olala3w_uploads_tmp VALUES('2003','1','','1552551015');
INSERT INTO olala3w_uploads_tmp VALUES('1993','1','','1552550062');
INSERT INTO olala3w_uploads_tmp VALUES('1994','1','','1552550111');
INSERT INTO olala3w_uploads_tmp VALUES('1995','1','','1552550198');
INSERT INTO olala3w_uploads_tmp VALUES('1996','1','','1552550238');
INSERT INTO olala3w_uploads_tmp VALUES('1997','1','','1552550314');
INSERT INTO olala3w_uploads_tmp VALUES('1998','1','','1552550363');
INSERT INTO olala3w_uploads_tmp VALUES('1999','1','','1552550409');
INSERT INTO olala3w_uploads_tmp VALUES('2000','1','','1552550453');
INSERT INTO olala3w_uploads_tmp VALUES('2001','1','','1552550936');
INSERT INTO olala3w_uploads_tmp VALUES('2002','1','','1552550974');
INSERT INTO olala3w_uploads_tmp VALUES('1991','1','','1552548834');
INSERT INTO olala3w_uploads_tmp VALUES('1979','1','','1552403636');
INSERT INTO olala3w_uploads_tmp VALUES('1980','1','','1552464615');
INSERT INTO olala3w_uploads_tmp VALUES('1985','1','','1552548072');
INSERT INTO olala3w_uploads_tmp VALUES('1984','1','','1552547699');
INSERT INTO olala3w_uploads_tmp VALUES('1992','1','','1552549976');
INSERT INTO olala3w_uploads_tmp VALUES('1986','1','','1552548137');
INSERT INTO olala3w_uploads_tmp VALUES('1987','1','','1552548357');
INSERT INTO olala3w_uploads_tmp VALUES('1988','1','','1552548462');
INSERT INTO olala3w_uploads_tmp VALUES('1989','1','','1552548545');
INSERT INTO olala3w_uploads_tmp VALUES('1990','1','','1552548622');
INSERT INTO olala3w_uploads_tmp VALUES('1978','1','','1552403623');
INSERT INTO olala3w_uploads_tmp VALUES('1977','1','','1552403601');
INSERT INTO olala3w_uploads_tmp VALUES('1976','1','','1552403578');
INSERT INTO olala3w_uploads_tmp VALUES('2026','0','','1554267537');
INSERT INTO olala3w_uploads_tmp VALUES('2027','0','','1554267657');
INSERT INTO olala3w_uploads_tmp VALUES('2032','1','','1554973458');
INSERT INTO olala3w_uploads_tmp VALUES('2033','1','','1554973747');
INSERT INTO olala3w_uploads_tmp VALUES('2034','1','','1554974103');
INSERT INTO olala3w_uploads_tmp VALUES('2035','1','','1554974594');
INSERT INTO olala3w_uploads_tmp VALUES('2036','1','','1554975398');
INSERT INTO olala3w_uploads_tmp VALUES('2037','1','','1554975479');
INSERT INTO olala3w_uploads_tmp VALUES('2038','1','','1554975551');
INSERT INTO olala3w_uploads_tmp VALUES('2039','1','','1554975667');
INSERT INTO olala3w_uploads_tmp VALUES('2040','1','','1554975742');
INSERT INTO olala3w_uploads_tmp VALUES('2041','1','','1554975810');
INSERT INTO olala3w_uploads_tmp VALUES('2042','0','','1554976026');
INSERT INTO olala3w_uploads_tmp VALUES('2043','1','','1554976080');
INSERT INTO olala3w_uploads_tmp VALUES('2044','1','','1554976593');
INSERT INTO olala3w_uploads_tmp VALUES('2045','1','','1554976684');
INSERT INTO olala3w_uploads_tmp VALUES('2046','1','','1554976764');
INSERT INTO olala3w_uploads_tmp VALUES('2047','1','','1554976839');
INSERT INTO olala3w_uploads_tmp VALUES('2048','1','','1554976949');
INSERT INTO olala3w_uploads_tmp VALUES('2049','1','','1554978160');
INSERT INTO olala3w_uploads_tmp VALUES('2050','1','','1554978236');
INSERT INTO olala3w_uploads_tmp VALUES('2051','1','','1554978475');
INSERT INTO olala3w_uploads_tmp VALUES('2052','1','','1554978544');
INSERT INTO olala3w_uploads_tmp VALUES('2053','1','','1554978613');
INSERT INTO olala3w_uploads_tmp VALUES('2054','1','1555316395_2054_1113c68d1c933ea5b0b60268e064c267.jpg;1555316397_2054_086973b8881d3f2ded5f2e1a2ce35faa.jpg;1555316399_2054_78a90e3d6c545719369b7cbfad856007.jpg;1555316400_2054_c07c251f3aa7196513ed73ac83276574.jpg;1555316402_2054_af40b3b43ae9a605cc2cd986e8f87e3f.jpg;1555316404_2054_b87e15c47d0ff02027745e2b8f83eb0b.jpg;1555316406_2054_5f7d5302a1cb78b2f5e39fdac2b2e04b.jpg;1555316407_2054_d9bd6458f9f8735db60ffaeacc78a50b.jpg;1555316409_2054_55ec989df2b7affa995b5ead42f4c5e4.jpg;1555316411_2054_4e89c3493a6e16a67b3d210c245ac5c8.jpg;1555316412_2054_573bbe0dd5dec42912af2a9dc772a647.jpg;1555316414_2054_5eedfdda93f39160aada60f3b6a7ba8d.jpg;1555316416_2054_cace83804e43acbc90b0234278fba71c.jpg;1555316418_2054_88e85a2356791df2b7dfa1c2ae3924e4.jpg;1555316420_2054_81053270a960d9ec9b56199b331bad0b.jpg;1555316422_2054_bdcaf848d21b1f011e695f963d88eadb.jpg;','1555316154');
INSERT INTO olala3w_uploads_tmp VALUES('2055','1','','1555472926');
INSERT INTO olala3w_uploads_tmp VALUES('2056','1','','1555472971');
INSERT INTO olala3w_uploads_tmp VALUES('2057','1','','1555484454');
INSERT INTO olala3w_uploads_tmp VALUES('2058','1','','1555485021');
INSERT INTO olala3w_uploads_tmp VALUES('2059','1','','1555485363');
INSERT INTO olala3w_uploads_tmp VALUES('2060','1','','1555485449');
INSERT INTO olala3w_uploads_tmp VALUES('2061','1','','1555485487');
INSERT INTO olala3w_uploads_tmp VALUES('2062','1','','1555485552');
INSERT INTO olala3w_uploads_tmp VALUES('2063','1','','1555485598');
INSERT INTO olala3w_uploads_tmp VALUES('2064','1','','1555485632');
INSERT INTO olala3w_uploads_tmp VALUES('2065','1','','1555486207');
INSERT INTO olala3w_uploads_tmp VALUES('2066','1','','1555486263');
INSERT INTO olala3w_uploads_tmp VALUES('2067','1','','1555486352');
INSERT INTO olala3w_uploads_tmp VALUES('2068','1','','1555487692');
INSERT INTO olala3w_uploads_tmp VALUES('2069','0','','1555487961');
INSERT INTO olala3w_uploads_tmp VALUES('2070','1','','1555487962');
INSERT INTO olala3w_uploads_tmp VALUES('2071','1','','1555488077');
INSERT INTO olala3w_uploads_tmp VALUES('2072','1','','1555488174');
INSERT INTO olala3w_uploads_tmp VALUES('2073','1','','1555488236');
INSERT INTO olala3w_uploads_tmp VALUES('2074','1','','1555489174');
INSERT INTO olala3w_uploads_tmp VALUES('2075','1','','1555489658');
INSERT INTO olala3w_uploads_tmp VALUES('2076','1','','1555490031');
INSERT INTO olala3w_uploads_tmp VALUES('2077','1','','1555491418');
INSERT INTO olala3w_uploads_tmp VALUES('2078','1','','1555491501');
INSERT INTO olala3w_uploads_tmp VALUES('2079','1','','1555491764');
INSERT INTO olala3w_uploads_tmp VALUES('2080','1','','1555491832');
INSERT INTO olala3w_uploads_tmp VALUES('2081','1','','1555491916');
INSERT INTO olala3w_uploads_tmp VALUES('2082','1','','1555491949');
INSERT INTO olala3w_uploads_tmp VALUES('2083','1','','1555492018');
INSERT INTO olala3w_uploads_tmp VALUES('2084','1','','1555492039');
INSERT INTO olala3w_uploads_tmp VALUES('2085','1','','1555492059');
INSERT INTO olala3w_uploads_tmp VALUES('2086','1','','1555492088');
INSERT INTO olala3w_uploads_tmp VALUES('2087','1','','1555492273');
INSERT INTO olala3w_uploads_tmp VALUES('2088','1','','1555492352');
INSERT INTO olala3w_uploads_tmp VALUES('2089','1','','1555492408');
INSERT INTO olala3w_uploads_tmp VALUES('2090','1','','1555492436');
INSERT INTO olala3w_uploads_tmp VALUES('2091','1','','1555492505');
INSERT INTO olala3w_uploads_tmp VALUES('2092','1','','1555492610');
INSERT INTO olala3w_uploads_tmp VALUES('2096','1','1556681243_2096_5af0ac75ee2b27f223bbbd0e567840ff.jpg;1556681244_2096_8809fe4bb2df8264e63874f8dbfc60ad.jpg;1556681245_2096_adcb858ca6cedac28b7e78514baea00a.jpg;1556681246_2096_7808fa9dd18063663bedfacc3689e082.jpg;','1556681219');
INSERT INTO olala3w_uploads_tmp VALUES('2095','0','','1556681176');
INSERT INTO olala3w_uploads_tmp VALUES('2097','1','1556681676_2097_3a24963d82dcbb04db879e89c8423cb2.jpg;1556681677_2097_3281182f21d9cb84d9c7fd2491236b61.jpg;1556681678_2097_8769fc4b2e695416a70d4d8797d77c87.jpg;','1556681541');
INSERT INTO olala3w_uploads_tmp VALUES('2098','1','1557286545_2098_d3e0f531dc6c61a7957648f5e945f123.jpg;1557286547_2098_16e12133bf65573b654dbe7365038157.jpg;1557286549_2098_0b584793cd455b731013661f0b780128.jpg;1557286550_2098_4f5d20addc4b6c6d9027f3e774138e4c.jpg;1557286552_2098_5a90d056a653d958eff56557e3efeb11.jpg;1557286553_2098_c9951c8a7675eb617a8d0d24a6121ba8.jpg;1557286555_2098_ba3dc4ab70f637a33a2c42277d1ccd43.jpg;1557286556_2098_a17be2cb4a0f69e5726d356f8b03dc36.jpg;1557286558_2098_aae73dc21c499051589ebad160066b15.jpg;1557286559_2098_1a610a3511b2ea73a128cf7ec1fdaabe.jpg;1557286561_2098_0d5bab88bcb9f62d90cb66081a68c9e5.jpg;','1557286396');
INSERT INTO olala3w_uploads_tmp VALUES('2099','0','','1557476146');
INSERT INTO olala3w_uploads_tmp VALUES('2101','1','','1557738804');
INSERT INTO olala3w_uploads_tmp VALUES('2102','1','','1559379161');
INSERT INTO olala3w_uploads_tmp VALUES('2103','0','','1559455414');
INSERT INTO olala3w_uploads_tmp VALUES('2104','0','','1559459676');
INSERT INTO olala3w_uploads_tmp VALUES('2105','1','1559461121_2105_07651605a36efb92d8aa723ce060f29b.jpg;1559461124_2105_67d9c261e75951e67e7b42b5ac13932f.jpg;1559461128_2105_9796a2edbabc21f41dbc0c87b46ee78e.jpg;1559461132_2105_f16feda1e08396dfe43ba856a3af98a9.jpg;1559461135_2105_83a4599bfa79fea94f520b0b8169f029.jpg;1559461139_2105_6ac31bde60980ee43ed93fb83db07ca3.jpg;1559461142_2105_a7f545efe72327178f8f4f2400d335da.jpg;1559461146_2105_3e9d8a144919003ae5cf958a2daaeb62.jpg;1559461149_2105_7aad1dee6db0ad8d236d1e0dc29eed72.jpg;1559461152_2105_4a5fe5b5dcab77ce2e46f1e5d128e8c4.jpg;1559461156_2105_0b1794a363822c76e382c073c519a430.jpg;','1559460094');
INSERT INTO olala3w_uploads_tmp VALUES('2112','1','','1559621548');
INSERT INTO olala3w_uploads_tmp VALUES('2108','0','','1559544862');
INSERT INTO olala3w_uploads_tmp VALUES('2109','0','','1559551702');
INSERT INTO olala3w_uploads_tmp VALUES('2110','1','','1559552081');
INSERT INTO olala3w_uploads_tmp VALUES('2111','1','1560744842_2111_a525d4713bbb35c2349377c10c58dd6d.jpg;1560744846_2111_ac7c222e9420c43936dd70fc25d5b2c7.jpg;1560744849_2111_c5201d795ef8dd6eb497a0b5d17a7efe.jpg;1560744852_2111_9606f86240f7edca7b0ec90db8f7b2f0.jpg;1560744856_2111_f8367ce8b164ed951c1a6243b804282f.jpg;1560744863_2111_f80f45be96b80d1423f76192517fdd85.jpg;1560744866_2111_5ea9491727377d56dbb942cf22ce69ee.jpg;1560744870_2111_698eabe4f681cb2673e45562fedf1d38.jpg;1560744873_2111_9125c035cba06c8d8bfc40e3ba7411e1.jpg;1560744877_2111_465f687c68eac94db2b2ba032c71e714.jpg;1560744880_2111_db7116b8bf433f6c08994b1fee14024b.jpg;1560744884_2111_08e9c5958c7cb3509897f0386d759f0e.jpg;1560744887_2111_3e53b903af8424b48ff17f31a79e005f.jpg;1560744891_2111_6153325308f3ef436e665805ecaf0747.jpg;1560744897_2111_bea59dcfc02ed4f8acecf75bd54f2a1a.jpg;1560744901_2111_64bf7e856f81a90df32749e552e6971f.jpg;','1559553508');
INSERT INTO olala3w_uploads_tmp VALUES('2113','1','1559886723_2113_2c835e6d10476ae4aab8d79acbc60968.jpg;1559886726_2113_a0b42d810b358a609dd2bb787b408f2a.jpg;1559886730_2113_dfffe1482013871c9a4355efab34bc68.jpg;1559886734_2113_812550d36be730da62dc5a6b406aebfa.jpg;1559886737_2113_0ac4db201139bce75dca50bc8d9aed77.jpg;1559886741_2113_a85663d6a440ba5befed973120c766c2.jpg;1559886746_2113_3dfd46d1136aa019100a0ec8740074c9.jpg;1559886753_2113_85334e8d8e6b61ccd11e35172c3d7b48.jpg;1559886757_2113_1bbd757109e00cda12189ad6fdca2969.jpg;1559886760_2113_c838d4cfeb1a498870ecb6116bfee3b0.jpg;1559886764_2113_dabc72b70df669b843b67c4a4d1b1ac6.jpg;1559886790_2113_2e12905126048ceb1992fef21af5f5e2.jpg;1559886796_2113_774eba86b6a048c7f53f97703cf2ce9e.jpg;1559886799_2113_ea6aa8bf6b346b1c03cd56e9edd12530.jpg;1559886805_2113_716e230787048099981992055de54ffa.jpg;1559886808_2113_01e1ca4d03d6d57ba878e2e8c9fc9df4.jpg;1559886812_2113_2653a075777a50d733fb5174d11b9876.jpg;1559886815_2113_72e9e9dae38ce052110e9912a90472e0.jpg;1559886818_2113_74e44402f7489a6d786c0b18d9ba37a8.jpg;1559886822_2113_80d130fab2efcbf4605487ec725cdff4.jpg;1559886826_2113_1685fe6ad9c002463adfed153c13d387.jpg;1559886830_2113_1cab01e653120da98785fb10d2fbef2f.jpg;1559886834_2113_cea287bdba8f3eea9cc2e620ca4b6f15.jpg;1559886838_2113_9ce4d83ef3f2205aba7685277e75d90d.jpg;1559886841_2113_b7d8dee6e93ed78b200725fae3e7d3b4.jpg;1559886844_2113_97bd728d485fa2f9992600bc586061c3.jpg;','1559877588');
INSERT INTO olala3w_uploads_tmp VALUES('2114','0','','1560330352');
INSERT INTO olala3w_uploads_tmp VALUES('2115','1','1560343866_2115_40a8b73b3146df70be0a3f7dbfc9b47f.jpg;1560343938_2115_267e10f565c3189d000edc691a4aa517.jpg;1560343941_2115_4f3821079a1720a1beecceb9e7bb2953.jpg;1560343945_2115_b3ac857cab667a56d8881bcda93db9d4.jpg;1560343948_2115_f6a85166fd96af80461182782d556530.jpg;1560343954_2115_d12aca4f35d33c8841a75e36485bb196.jpg;1560343958_2115_695cbf5165f84eec76f922eda8036045.jpg;1560343961_2115_0649f6d01138fafc092c813d1b5559b9.jpg;1560343965_2115_13aa65576c3709ea70a0680e78f62292.jpg;1560343969_2115_5111f3276d6ed13de597e1e2836493aa.jpg;1560343975_2115_2eacd4f1975fa2812800418be30b6938.jpg;1560344065_2115_b9c6e451da7bf4332f8056f91946637c.jpg;1560344066_2115_2f5f1d8e99f186d99bd03e002125c7d7.jpg;1560344066_2115_b06089a6ab9a3dad6f85e610ebd8cc04.jpg;','1560343830');
INSERT INTO olala3w_uploads_tmp VALUES('2116','1','1560745309_2116_853041ff85c4b9fb258e24f15f401457.jpg;1560745321_2116_9a516d98219d1250de9c120e28ad98d8.jpg;1560745335_2116_aca5921ac7f55efc35e7fb6dcc7f1123.jpg;','1560745177');
INSERT INTO olala3w_uploads_tmp VALUES('2117','1','1561349657_2117_52b10f207d89df7b881262603ece576a.jpg;1561349659_2117_8cf7dd5250a8e7c0744dbffcf381f2e5.jpg;1561349662_2117_ec27f8bc3ef24ef919ecbe6680d5bff1.jpg;1561350171_2117_d0eacf3ab6ccdd19300445ea5cca1ef6.jpg;','1561349492');
INSERT INTO olala3w_uploads_tmp VALUES('2118','1','','1563788897');
INSERT INTO olala3w_uploads_tmp VALUES('2119','0','','1563788927');
INSERT INTO olala3w_uploads_tmp VALUES('2120','0','','1563789456');
INSERT INTO olala3w_uploads_tmp VALUES('2121','0','','1563939471');
INSERT INTO olala3w_uploads_tmp VALUES('2122','1','1565582000_2122_8f2407fff399dab8d239fbbe0b092da6.jpg;1565582017_2122_20e41ad22efb1650ed129422cea9bab3.jpg;1565582022_2122_ba14e917a15700ff58ff3527b0eef5b4.jpg;1565582031_2122_4369efb5e6e6ff6a6cbcafb529e7fec4.jpg;1565582035_2122_96cc43830e3cdcd1140136779777bd61.jpg;1565582046_2122_920f6e8c618f71159a7e28ebef1dcd9b.jpg;1565582052_2122_f719296a788b4bbf23a4da4c472cd326.jpg;1565582057_2122_4e33054d78622e8f56e050d3b64534e5.jpg;1565582061_2122_1118c28a17f48e46746db4ed808a5726.jpg;1565582066_2122_6d23a531228d16c7e1cffe5cc39e6ef6.jpg;1565582070_2122_330389949ea24d0b0a25f01042e83cd9.jpg;1565582075_2122_f2b18b5c80bbf26e0ffdebc128d3348f.jpg;1565582080_2122_62807d3ccdec7b64d85670fc3fe173ed.jpg;1565582087_2122_fee782594b908f10a78be758d6668477.jpg;1565582093_2122_163e404566b15aa3711a57ebf5c118f8.jpg;1565582098_2122_8b888dd0a1bfc6e63f43cbb2c3ffb8f2.jpg;','1565581361');
INSERT INTO olala3w_uploads_tmp VALUES('2123','1','','1567847834');
INSERT INTO olala3w_uploads_tmp VALUES('2124','0','','1568602168');
INSERT INTO olala3w_uploads_tmp VALUES('2125','1','','1568603057');
INSERT INTO olala3w_uploads_tmp VALUES('2126','0','','1568603187');
INSERT INTO olala3w_uploads_tmp VALUES('2127','1','','1568603254');
INSERT INTO olala3w_uploads_tmp VALUES('2128','1','','1568603305');
INSERT INTO olala3w_uploads_tmp VALUES('2129','1','','1568603368');
INSERT INTO olala3w_uploads_tmp VALUES('2130','1','','1568603432');
INSERT INTO olala3w_uploads_tmp VALUES('2131','0','','1568604836');
INSERT INTO olala3w_uploads_tmp VALUES('2132','1','','1568604946');
INSERT INTO olala3w_uploads_tmp VALUES('2133','1','','1568606019');
INSERT INTO olala3w_uploads_tmp VALUES('2134','1','','1568606085');
INSERT INTO olala3w_uploads_tmp VALUES('2135','1','','1568606118');
INSERT INTO olala3w_uploads_tmp VALUES('2136','1','','1568606160');
INSERT INTO olala3w_uploads_tmp VALUES('2137','1','','1568606433');
INSERT INTO olala3w_uploads_tmp VALUES('2138','1','','1568607207');
INSERT INTO olala3w_uploads_tmp VALUES('2139','1','','1568607250');
INSERT INTO olala3w_uploads_tmp VALUES('2140','1','','1568607614');
INSERT INTO olala3w_uploads_tmp VALUES('2141','1','','1568607645');
INSERT INTO olala3w_uploads_tmp VALUES('2142','1','','1568607699');
INSERT INTO olala3w_uploads_tmp VALUES('2143','1','','1568607837');
INSERT INTO olala3w_uploads_tmp VALUES('2144','1','','1568607878');
INSERT INTO olala3w_uploads_tmp VALUES('2145','1','','1568607989');
INSERT INTO olala3w_uploads_tmp VALUES('2146','0','','1568629104');
INSERT INTO olala3w_uploads_tmp VALUES('2147','1','','1568629442');
INSERT INTO olala3w_uploads_tmp VALUES('2148','0','','1568629505');
INSERT INTO olala3w_uploads_tmp VALUES('2149','1','','1568629513');

-- --------------------------------------------------------

CREATE TABLE `olala3w_vote` (
  `vote_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `vote` int(1) NOT NULL DEFAULT 0,
  `created_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

